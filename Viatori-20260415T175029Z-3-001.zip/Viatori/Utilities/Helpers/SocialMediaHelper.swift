//
//  SocialMediaHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 12/01/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import TwitterKit
import Marshal
import FBSDKCoreKit
import FBSDKLoginKit
import FBSDKShareKit
import MessageUI
import AFNetworking

struct SocialMediaObject {
    var userId:String?
    var email:String?
    var phoneNumber:String?
    var fullName:String?
    var userName:String?
    var profilePictureUrl:String?
    var birthday:String?
    var gender:Int?
    var facebookToken : String?
    var twitterAuthToken : String?
    var twitterAuthTokenSecret : String?
}

class SocialMediaHelper : NSObject {
    
    internal var completionBlock : ((_ success:Bool,_ result:SocialMediaObject?)->())?
    internal weak var target : UIViewController?

    func loginWithTwitter(target:UIViewController,completion: @escaping (_ success:Bool,_ result:SocialMediaObject?)->()) {
        
        Twitter.sharedInstance().logIn(withMethods: .webBased) { (session, error) in
            if error == nil {
                let client = TWTRAPIClient.withCurrentUser()
                let request = client.urlRequest(withMethod: "GET", url: "https://api.twitter.com/1.1/account/verify_credentials.json", parameters: ["include_email": "true", "skip_status": "true"], error: nil)
                client.sendTwitterRequest(request, completion: { (response, data, connectionError) in
                    
                    if connectionError == nil, let userData = data {
                        do {
                            let results = try JSONSerialization.jsonObject(with: userData, options: .allowFragments)
                            let parsedResult = VTTwitterBaseResponse.init(object: results as! MarshaledObject)
                            completion(true,SocialMediaObject(userId: parsedResult.idStr, email: parsedResult.email, phoneNumber: nil, fullName: parsedResult.name, userName: parsedResult.screenName, profilePictureUrl: parsedResult.profileImageUrl,birthday:nil,gender:nil,facebookToken:nil,twitterAuthToken:session?.authToken,twitterAuthTokenSecret:session?.authTokenSecret))
                        } catch {
                            self.showAlert(target: target, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(),completion: completion)
                        }
                    } else {
                        self.showAlert(target: target, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(),completion: completion)
                    }
                })
            } else {
                if let error = error as NSError?, error.domain == TWTRLogInErrorDomain && error.code == TWTRLogInErrorCode.canceled.rawValue {
                    completion(false,nil)
                } else {
                    self.showAlert(target: target, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(),completion: completion)
                }
            }
        }
    }
    
    func loginWithFacebook(target:UIViewController,completion: @escaping (_ success:Bool,_ result:SocialMediaObject?)->()) {
        
        let manager = FBSDKLoginManager()
        manager.loginBehavior = .systemAccount
        manager.logIn(withReadPermissions: ["public_profile", "user_birthday", "email", "user_friends"], from: target) { [unowned self] (result, error) in
            if error != nil {
                self.showAlert(target: target, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(), completion: completion)
            } else if (result?.isCancelled)! {
                self.showAlert(target: target, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(), completion: completion)
            } else {
                let token = result?.token.tokenString
                FBSDKGraphRequest.init(graphPath: "me", parameters: ["fields":"id,name,birthday,gender,email,picture.width(512).height(512)"]).start(completionHandler: { [unowned self] (connection, result, error) in
                    if error == nil, let result = result {
                        let parsedResult = VTFacebookBaseResponse.init(object: result as! MarshaledObject)
                        completion(true,SocialMediaObject(userId: parsedResult.id, email: parsedResult.email, phoneNumber: nil, fullName: parsedResult.name, userName: nil, profilePictureUrl: parsedResult.picture?.data?.url, birthday: self.parseBirthday(birthday: parsedResult.birthday), gender: self.parseGender(gender: parsedResult.gender),facebookToken:token,twitterAuthToken:nil,twitterAuthTokenSecret:nil))
                    } else {
                        self.showAlert(target: target, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(), completion: completion)
                    }
                })
            }
        }
    }
    
    func loginWithGoogle(target:UIViewController,completion: @escaping (_ success:Bool,_ result:SocialMediaObject?)->()) {
        self.completionBlock = completion
        self.target = target
        let signIn = GIDSignIn.sharedInstance()
        signIn!.shouldFetchBasicProfile = true
        signIn!.delegate = self
        signIn!.uiDelegate = self
        signIn!.signIn()
    }
    
    func showAlert(target:UIViewController, title:String?=nil ,message:String?, completion:((_ success:Bool,_ result:SocialMediaObject?)->())? = nil) {
        
        completion?(false,nil)
        if let message = message {
            VTAlertManager.sharedManager.show(title ?? "TXT_COMMON_COMMON_WARNING".localized(), message: message, buttons: ["TXT_COMMON_COMMON_DONE".localized()], tapBlock: nil)
        }
    }
}

extension SocialMediaHelper : GIDSignInDelegate,GIDSignInUIDelegate {
    
    //MARK: Google SignIn Protocols
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if error == nil {
            var imageUrl : String?
            if user.profile.hasImage {
                imageUrl = user.profile.imageURL(withDimension: UInt(VTConstants.Constants.ProfileImage_Size)).absoluteString
            }
            self.completionBlock!(true,SocialMediaObject(userId: user.userID, email: user.profile.email, phoneNumber: nil, fullName: user.profile.name, userName: nil, profilePictureUrl: imageUrl, birthday: nil, gender: nil,facebookToken:nil,twitterAuthToken:nil,twitterAuthTokenSecret:nil))
        } else {
            self.showAlert(target: self.target!, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(), completion: self.completionBlock)
        }
    }
    
    func sign(inWillDispatch signIn: GIDSignIn!, error: Error!) {
        if error != nil {
            self.showAlert(target: self.target!, message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(), completion: self.completionBlock)
        }
    }
    
    // Present a view that prompts the user to sign in with Google
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
        self.target!.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
        viewController.dismiss(animated: true, completion: nil)
    }
}

internal extension SocialMediaHelper {
    
    //MARK: Utilities
    
    func parseGender(gender:String?) -> Int? {
        if let genderWrapped = gender {
            return genderWrapped == "female" ? 1 : genderWrapped == "male" ? 2 : nil
        }
        return nil
    }
    
    func parseBirthday(birthday:String?) -> String? {
        if let birthdayWrapped = birthday {
            if !birthdayWrapped.isEmpty {
                let components = birthdayWrapped.components(separatedBy: "/")
                if components.count == 3 {
                    return "\(components[1]).\(components[0]).\(components[2])"
                }
            }
        }
        return nil
    }
}

extension SocialMediaHelper {
    
    //MARK: Share
    func shareOnFacebook(feedObject:VTFeedObject?, target:UIViewController?) {
        guard let target = target, let postObject = feedObject?.postObject, let shareUrl = postObject.shareURL else {return}
        
        let content = FBSDKShareLinkContent()
        content.contentURL = URL.init(string: shareUrl)!
        content.contentTitle = "Viatori"
        if let postText = postObject.postText {
            content.contentDescription = postText
        }
        if postObject.mediaType == .photo {
            content.imageURL = URL.init(string: postObject.photoURLArray![0])
        } else if postObject.mediaType == .video && postObject.hasThumbnail {
            content.imageURL = URL.init(string: postObject.videoThumbnailURL!)
        }
        
        let dialog = FBSDKShareDialog()
        dialog.fromViewController = target
        dialog.shareContent = content
        dialog.mode = .native
        if !dialog.canShow() {
            dialog.delegate = self
            dialog.mode = .automatic
        }
        dialog.show()
    }
    
    func shareOnTwitter(feedObject:VTFeedObject?, target:UIViewController?) {
        guard let target = target, let postObject = feedObject?.postObject, let shareUrl = postObject.shareURL else {return}
        let composer = TWTRComposer()
        composer.setURL(URL.init(string: shareUrl))
        if let postText = postObject.postText {
            composer.setText(postText)
        }
        
        // Called from a UIViewController
        composer.show(from: target) { [weak self] result in
            if (result == .cancelled) {
                //self?.showAlert(target: target, title:"TXT_COMMON_COMMON_WARNING".localized(), message: "TXT_SOCIAL_FEED_SHARE_TWITTER_ERROR".localized())
            }
            else {
                self?.showAlert(target: target, title:"TXT_COMMON_COMMON_INFO".localized(), message: "TXT_SOCIAL_FEED_SHARE_TWITTER_SUCCESS".localized())
            }
        }
    }
    
    func shareOnTwitter(urlStr:String, target:UIViewController?) {
        guard let target = target else { return }
        let composer = TWTRComposer()
        composer.setURL(URL.init(string: urlStr))
        composer.show(from: target) { [weak self] (result) in
            if (result == .cancelled) {
                //self?.showAlert(target: target, title:"TXT_COMMON_COMMON_WARNING".localized(), message: "TXT_SOCIAL_FEED_SHARE_TWITTER_ERROR".localized())
            }
            else {
                self?.showAlert(target: target, title:"TXT_COMMON_COMMON_INFO".localized(), message: "TXT_SOCIAL_FEED_SHARE_TWITTER_SUCCESS".localized())
            }
        }
    }
    
    func copyClipboard(feedObject:VTFeedObject?, target:UIViewController?) {
        guard let target = target, let postObject = feedObject?.postObject, let shareUrl = postObject.shareURL else {return}
        UIPasteboard.general.string = shareUrl
        self.showAlert(target: target, title:"TXT_COMMON_COMMON_INFO".localized(), message: "TXT_COMMON_COMMON_COPY_LINK_POPUP".localized())
    }
    
    func shareOnActivity(feedObject:VTFeedObject?, target:UIViewController?) {
        guard let target = target, let postObject = feedObject?.postObject, let shareUrl = postObject.shareURL else {return}
        let activityController = UIActivityViewController.init(activityItems: [URL.init(string: shareUrl)!], applicationActivities: nil)
        activityController.completionWithItemsHandler = { (type,completed,items,error) in
            
            // Return if cancelled
            if (completed) {
                /*if ((error) != nil) {
                    self?.showAlert(target: target, message: "TXT_SOCIAL_FEED_SHARE_PROCESS_ERROR".localized())
                } else {
                    self?.showAlert(target: target, title:"TXT_COMMON_COMMON_INFO".localized() ,message: "TXT_SOCIAL_FEED_SHARE_PROCESS_SUCCESS".localized())
                }*/
            }
        }
        target.present(activityController, animated: true, completion: nil)
    }
    
    func shareWithSMS(feedObject:VTFeedObject?, target:UIViewController?) {
        guard let target = target, let postObject = feedObject?.postObject, let shareUrl = postObject.shareURL else {return}
//        self.target = target
//        if MFMessageComposeViewController.canSendText() {
//           let smsVC = MFMessageComposeViewController()
//            smsVC.body = shareUrl
//            smsVC.messageComposeDelegate = self
//            target.present(smsVC, animated: true, completion: nil)
//        }
        let controller = UIViewController.controller(for: .messages, controllerIdentifier: .messageFriendList) as! MessageFriendListViewController
        controller.feedid = (feedObject?.feedID)!
        
//        target.present(controller, animated: true, completion: nil)
        target.navigationController?.pushViewController(controller, animated: true)
        target.navigationController?.pushViewController(controller, animated: true)

    }
}

extension SocialMediaHelper : MFMessageComposeViewControllerDelegate {
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        target?.dismiss(animated: true, completion: nil)
    }
}

extension SocialMediaHelper : FBSDKSharingDelegate {
    
    func sharer(_ sharer: FBSDKSharing!, didCompleteWithResults results: [AnyHashable : Any]!) {
        if let results = results, results.count > 0 {
            guard let target = target else {return}
            self.showAlert(target: target, title: "TXT_COMMON_COMMON_INFO".localized(), message: "TXT_SOCIAL_FEED_SHARE_FACEBOOK_SUCCESS".localized())
        }
        debugPrint("didCompleteWithResults : \(results)")
    }
    
    func sharer(_ sharer: FBSDKSharing!, didFailWithError error: Error!) {
        if error != nil {
            guard let target = target else {return}
            self.showAlert(target: target, message: "TXT_SOCIAL_FEED_SHARE_FACEBOOK_ERROR".localized())
        }
        debugPrint("didFailWithError : \(error)")
        
    }
    func sharerDidCancel(_ sharer: FBSDKSharing!) {
        debugPrint("sharerDidCancel")
    }
}

extension SocialMediaHelper {
    
    //MARK: Also Share On
    
    func checkIfAlsoShareOnFacebook() -> Bool {
        if let fbSDKAccessToken = FBSDKAccessToken.current(), let _ = fbSDKAccessToken.tokenString, fbSDKAccessToken.permissions.contains("publish_actions"), VTSingleton.shared.alsoShareOnFacebook  {
            return true
        }
        return false
    }
    
    func checkIfAlsoShareOnTwitter() -> Bool {
        let session = Twitter.sharedInstance().sessionStore.session()
        if let _ = session?.authToken, let _ = session?.authTokenSecret, VTSingleton.shared.alsoShareOnTwitter {
            return true
        }
        return false
    }
    
    func setUserAlsoShareOnFacebook(completion:@escaping (Bool)->()) {
        if let fbSDKAccessToken = FBSDKAccessToken.current(), let _ = fbSDKAccessToken.tokenString, fbSDKAccessToken.permissions.contains("publish_actions") {
            VTSingleton.shared.alsoShareOnFacebook = true
            completion(true)
        } else {
            let manager = FBSDKLoginManager()
            manager.loginBehavior = .systemAccount
            manager.logIn(withPublishPermissions: ["publish_actions"], from: target, handler: { (result, error) in
                if error != nil {
                    completion(false)
                } else if (result?.isCancelled)! {
                    completion(false)
                } else {
                    if let result = result, result.grantedPermissions.contains("publish_actions") {
                        VTSingleton.shared.alsoShareOnFacebook = true
                        completion(true)
                    } else {
                        completion(false)
                    }
                }
            })
        }
    }
    
    func setUserAlsoShareOnTwitter(completion:@escaping (Bool)->()) {
        let session = Twitter.sharedInstance().sessionStore.session()
        if let _ = session?.authToken, let _ = session?.authTokenSecret {
            VTSingleton.shared.alsoShareOnTwitter = true
            completion(true)
        } else {
            Twitter.sharedInstance().logIn(withMethods: .all) { (session, error) in
                if error == nil {
                    VTSingleton.shared.alsoShareOnTwitter = true
                    completion(true)
                } else {
                    completion(false)
                }
            }
        }
    }
    
    func shareFeedObjectIfNeccessary(feedObject : VTFeedObject?) {
        if checkIfAlsoShareOnFacebook() {
            guard let shareUrl = feedObject?.postObject?.shareURL, !shareUrl.isEmpty, let faceId = FBSDKAccessToken.current().userID, let faceToken =  FBSDKAccessToken.current().tokenString else {return}
            let manager = AFHTTPSessionManager.init(baseURL: URL.init(string: "https://graph.facebook.com/"))
            var contentTypes = Array(manager.responseSerializer.acceptableContentTypes!)
            contentTypes.append("text/html")
            manager.responseSerializer.acceptableContentTypes = NSSet(array:contentTypes) as? Set<String>
            manager.post("\(faceId)/feed?", parameters: nil, constructingBodyWith: { (formData) in
                formData.appendPart(withForm: shareUrl.data(using: .utf8)!, name: "link")
                formData.appendPart(withForm: faceToken.data(using: .utf8)!, name: "access_token")
            }, progress: nil, success: { (task, response) in
                debugPrint(response ?? "")
            }, failure: { (task, error) in
                debugPrint(error)
            })
            
        }
        
        if checkIfAlsoShareOnTwitter() {
            let session = Twitter.sharedInstance().sessionStore.session()
            guard let shareUrl = feedObject?.postObject?.shareURL, !shareUrl.isEmpty, let twitterId = session?.userID else {return}
            let endPoint = "https://api.twitter.com/1.1/statuses/update.json"
            let params : [String:String] = ["status":shareUrl]
            let client = TWTRAPIClient.init(userID: twitterId)
            let request = client.urlRequest(withMethod: "POST", url: endPoint, parameters: params, error: nil)
            client.sendTwitterRequest(request, completion: { (response, data, error) in
                if let _ = error {
                    debugPrint("twitter paylaşımı yapılamadı.")
                } else {
                    debugPrint("twitter paylaşımı başarılı.")
                }
            })
        }
    }
}

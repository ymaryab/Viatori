//
//  FriendHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 4.04.2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import TwitterKit
import FBSDKCoreKit
import FBSDKLoginKit
import FBSDKShareKit
import Contacts

class FriendHelper: NSObject {

}

extension FriendHelper {
    
    //MARK: Facebook Friends
    func findFacebookFriends(from target:UIViewController, forced:Bool, completion:@escaping ([VTUserObject])->()) {
        
        if let facebookFriends = VTSingleton.shared.facebookFriends, facebookFriends.count > 0 {
            completion(facebookFriends)
        } else {
            if let fbSDKAccessToken = FBSDKAccessToken.current(), let accessToken = fbSDKAccessToken.tokenString {
                self.getFacebookFriends(with: accessToken, completion: completion)
            } else if forced {
                let manager = FBSDKLoginManager()
                manager.loginBehavior = .systemAccount
                manager.logIn(withReadPermissions: ["user_friends"], from: target) { [weak self] (result, error) in
                    if error != nil {
                        VTAlertManager.sharedManager.show("TXT_COMMON_COMMON_WARNING".localized(), message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(), buttons: ["TXT_COMMON_COMMON_DONE".localized()], tapBlock: nil)
                    } else {
                        if let token = result?.token?.tokenString {
                            self?.getFacebookFriends(with: token, completion: completion)
                        }
                    }
                }
            }
        }
    }
    private func getFacebookFriends(with accessToken:String, completion:@escaping ([VTUserObject])->()) {
        VTWebService.getFacebookFriends(facebookToken: accessToken, success: { (task, response) in
            if let response = response, response.statusCode == .success, let friends = VTFriendResponse.init(object: response.responseData).userobject {
                completion(friends)
                VTSingleton.shared.facebookFriends = friends
            } else {
                completion([])
            }
        }) { (task, response, error) in
            completion([])
        }
    }
}

extension FriendHelper {
    
    //MARK: Twitter Friends
    
    func findTwitterFriends(from target:UIViewController, forced:Bool, completion:@escaping ([VTUserObject])->()) {
        
        if let twitterFriends = VTSingleton.shared.twitterFriends, twitterFriends.count > 0 {
            completion(twitterFriends)
        } else {
            let session = Twitter.sharedInstance().sessionStore.session()
            if let accessToken = session?.authToken, let authSecret = session?.authTokenSecret {
                self.getTwitterFriends(with: accessToken, tokenSecret: authSecret, completion: completion)
            } else if forced {
                Twitter.sharedInstance().logIn(withMethods: .all, completion: { [weak self] (session, error) in
                    if error != nil {
                        if let error = error as NSError?, error.domain == TWTRLogInErrorDomain && error.code == TWTRLogInErrorCode.canceled.rawValue {
                            //cancelled, no error
                        } else {
                            VTAlertManager.sharedManager.show("TXT_COMMON_COMMON_WARNING".localized(), message: "TXT_COMMON_SOCIAL_MEDIA_ERROR".localized(), buttons: ["TXT_COMMON_COMMON_DONE".localized()], tapBlock: nil)
                        }
                    } else {
                        if let accessToken = session?.authToken, let tokenSecret = session?.authTokenSecret {
                            self?.getTwitterFriends(with: accessToken, tokenSecret: tokenSecret, completion: completion)
                        }
                    }
                })
            }
        }
    }
    
    private func getTwitterFriends(with accessToken:String, tokenSecret:String, completion:@escaping ([VTUserObject])->()) {
        VTWebService.getTwitterFriends(twitterToken: accessToken, twitterSecret: tokenSecret, success: { (task, response) in
            if let response = response, response.statusCode == .success, let friends = VTFriendResponse.init(object: response.responseData).userobject {
                completion(friends)
                VTSingleton.shared.twitterFriends = friends
            } else {
                completion([])
            }
        }) { (task, response, error) in
            completion([])
        }
    }
}

extension FriendHelper {
    
    func findContactFriends(completion:@escaping ([VTUserObject])->()) {
        
        let contactStroe = CNContactStore()
        let keysToFetch : [CNKeyDescriptor] = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName),CNContactEmailAddressesKey as CNKeyDescriptor,CNContactPhoneNumbersKey as CNKeyDescriptor]
        
        contactStroe.requestAccess(for: .contacts, completionHandler: { [weak self] (granted, error) -> Void in
            if granted {
                let predicate = CNContact.predicateForContactsInContainer(withIdentifier: contactStroe.defaultContainerIdentifier())
                var contacts: [CNContact] = []
                do {
                    contacts = try contactStroe.unifiedContacts(matching: predicate, keysToFetch: keysToFetch)// [CNContact]
                }catch {
                    
                }
                var phoneString = ""
                var emailString = ""
                for contact in contacts {
                    if contact.phoneNumbers.count > 0 {
                        for number in contact.phoneNumbers {
                            let normalizedNumber = number.value.stringValue.normalizePhone()
                            if !normalizedNumber.isEmpty {
                                phoneString = phoneString.isEmpty ? normalizedNumber : "\(phoneString)|\(normalizedNumber)"
                            }
                        }
                    }
                    if contact.emailAddresses.count > 0 {
                        for email in contact.emailAddresses {
                            let emailStr = String(email.value)
                            if !emailStr.isEmpty {
                                emailString = "\(emailString)'\(emailStr)',"
                            }
                        }
                    }
                }
                if !emailString.isEmpty && emailString[emailString.length - 1] == "," {
                    emailString = String(emailString.characters.dropLast())
                }
                self?.getContactFriends(with: phoneString, emailString: emailString, completion: completion)
            }
        })
    }
    
    private func getContactFriends(with phoneString:String, emailString:String, completion:@escaping ([VTUserObject])->()) {
        VTWebService.getContactFriends(phoneStr: phoneString, emailStr: emailString, success: { (task, response) in
            if let response = response, response.statusCode == .success, let friends = VTFriendResponse.init(object: response.responseData).userobject {
                completion(friends)
                
            } else {
                completion([])
            }
        }) { (task, response, error) in
            completion([])
        }
    }
    
}

extension String {
    
    func normalizePhone() -> String {
        var normalized = self
        normalized = normalized.replacingOccurrences(of: " ", with: "")
        normalized = normalized.replacingOccurrences(of: "-", with: "")
        normalized = normalized.replacingOccurrences(of: "(", with: "")
        normalized = normalized.replacingOccurrences(of: ")", with: "")
        normalized = normalized.replacingOccurrences(of: "+", with: "")
        normalized = normalized.components(separatedBy: .whitespaces).joined()
        return normalized
    }
}

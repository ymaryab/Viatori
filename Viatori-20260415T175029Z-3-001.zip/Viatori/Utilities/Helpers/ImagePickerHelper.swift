//
//  ImagePickerHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 05/01/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class ImagePickerHelper: NSObject {
    
    internal var completionClosure : ((_ selectedImage:UIImage?,_ videoURL:String?,_ tempURL:URL?) -> ())!
    internal var newMedia = false

    @discardableResult
    func startMediaBrowser(from viewController:UIViewController, completion:@escaping (UIImage?,String?,URL?) -> () ) -> Bool {
        if !UIImagePickerController.isSourceTypeAvailable(.camera) && !UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            return false
        }
        
        self.completionClosure = completion
        
        let alertController = UIAlertController.init(title: nil, message: nil, preferredStyle: .actionSheet)
        /*alertController.addAction(UIAlertAction.init(title: "TXT_LOGIN_SIGNUP_FULLNAME_PHOTO_GALLERY".localized(), style: .default, handler: { [unowned self] (alertAction) in
            self.showImagePicker(controller: viewController, sourceType: .camera, mediaTypes:[])
        }))*/
        
        alertController.addAction(UIAlertAction.init(title: "TXT_SOCIAL_ADDPOST_TEXT_ACTIONBAR_VIDEO_CAM".localized(), style: .default, handler: { [unowned self] (alertAction) in
            self.newMedia = true
            self.showImagePicker(controller: viewController, sourceType:.camera, mediaTypes:[kUTTypeMovie as String])
        }))
        
        alertController.addAction(UIAlertAction.init(title: "TXT_SOCIAL_ADDPOST_TEXT_ACTIONBAR_GALLERY".localized(), style: .default, handler: { [unowned self] (alertAction) in
            self.newMedia = false
            self.showImagePicker(controller: viewController, sourceType:UIImagePickerControllerSourceType(rawValue:UIImagePickerControllerSourceType.photoLibrary.rawValue|UIImagePickerControllerSourceType.savedPhotosAlbum.rawValue)!, mediaTypes:[kUTTypeMovie as String])
        }))
        
        alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_CANCEL".localized(), style: .cancel, handler: { (alertAction) in
            
        }))
        
        viewController.present(alertController, animated: true, completion: nil)
        
        return true
    }
    
    func showImagePicker(controller:UIViewController, sourceType:UIImagePickerControllerSourceType, mediaTypes:[String]) {
        
        let mediaUI = UIImagePickerController()
        mediaUI.sourceType = sourceType
        mediaUI.mediaTypes = mediaTypes
        mediaUI.delegate = self
        mediaUI.videoQuality = .typeMedium
        mediaUI.videoMaximumDuration = 60
        controller.present(mediaUI, animated: true, completion: nil)
    }
}

extension ImagePickerHelper : UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let mediaType = info[UIImagePickerControllerMediaType] as! String
        
        if mediaType == (kUTTypeImage as String) {
            
            let image = info[UIImagePickerControllerOriginalImage] as? UIImage
            self.completionClosure(image,nil,nil)
            
        } else if mediaType == (kUTTypeMovie as String) {
            let movieURL = info[UIImagePickerControllerMediaURL] as! URL
            let moviePath = movieURL.path
            let generatedImage = UIImage.getThumbNail(path: moviePath)
            
            if newMedia {
                let assetLibrary = ALAssetsLibrary()
                if assetLibrary.videoAtPathIs(compatibleWithSavedPhotosAlbum: movieURL) {
                    assetLibrary.writeVideoAtPath(toSavedPhotosAlbum: movieURL, completionBlock: { (assetURL, error) in
                        if let assetURL = assetURL, error == nil {
                            self.completionClosure(generatedImage,assetURL.absoluteString,movieURL)
                        }
                    })
                }
                UISaveVideoAtPathToSavedPhotosAlbum(moviePath, self, #selector(video(_:didFinishSavingWithError:contextInfo:)), nil)
            } else {
                let assetPath = (info[UIImagePickerControllerReferenceURL] as! URL).absoluteString
                self.completionClosure(generatedImage,assetPath,movieURL)
            }
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    func video(_ video: String, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        debugPrint(video)
    }
}

extension UIImage {
    
    static func getThumbNail(path:String?) -> UIImage? {
        var image : UIImage?
        if let path = path {
            let url = URL.init(fileURLWithPath: path)
            let asset = AVURLAsset.init(url: url)
            let generator = AVAssetImageGenerator.init(asset: asset)
            generator.appliesPreferredTrackTransform = true
            let time = CMTimeMake(0, 1)
            let imageRef = try? generator.copyCGImage(at: time, actualTime: nil)
            if let imageRef = imageRef {
                image = UIImage.init(cgImage: imageRef)
            }
        }
        return image
    }
}

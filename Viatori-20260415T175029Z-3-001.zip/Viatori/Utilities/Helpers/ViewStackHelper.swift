//
//  ViewStackHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 01/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

enum VTApplicationViewModule {
    case splash,walkthrough,socialMedia,orders
}

class ViewStackHelper: NSObject {

    static func changeTopRootViewController(for controller:UIViewController?) {
        self.getRootViewController().topViewController = controller
    }
    
    static func changeLeftViewController(for controller:UIViewController) {
        
    }
    
    static func changeRightViewController(for controller:UIViewController) {
        
    }
    
    static func bringLeftVCToFront(animated:Bool) {
        
    }
    
    static func bringRightVCToFront(animated:Bool) {
        
    }
    
    static func getRootViewController() -> VTRootViewController {
        return VTSingleton.shared.rootViewController
    }
    
    static func getTopViewController() -> UIViewController? {
        return self.getRootViewController().topViewController
    }
    
    static func getControllerToShowAlert() -> UIViewController {
        
        let rootController = self.getRootViewController()
        
        if rootController.presentedViewController != nil {
            return rootController.presentedViewController!
        }
        
        return rootController
    }
    
    static func logout(forced:Bool = true) {
        if forced {
            self.changeTopRootViewController(for: UINavigationController.controller(for: .beforeLogin, controllerIdentifier: .walkthroughNav))
        } else {
            VTAlertManager.sharedManager.show("TXT_COMMON_COMMON_INFO".localized(), message: "TXT_SOCIAL_SETTINGS_EXIT_POPUP_DESC".localized(), buttons: ["TXT_SOCIAL_SETTINGS_EXIT_POPUP_YES".localized(),"TXT_SOCIAL_SETTINGS_EXIT_POPUP_NO".localized()], tapBlock: { (action, index) in
                if index == 0 {
                    ViewStackHelper.changeTopRootViewController(for: UINavigationController.controller(for: .beforeLogin, controllerIdentifier: .walkthroughNav))
                }
            })
        }
        VTSingleton.shared.clearUser()
    }
    
}

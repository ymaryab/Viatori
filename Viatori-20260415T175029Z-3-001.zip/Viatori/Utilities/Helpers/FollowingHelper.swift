//
//  FollowingHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 14.03.2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

public enum FollowStatus : Int {
    case none = 0
    case follow, following, answer, waiting
    
    var buttonTitle : String {
        switch self {
        case .none: return ""
        case .follow: return "TXT_SOCIAL_OTHERS_PROFILE_FOLLOW_BTN".localized()
        case .following: return "TXT_SOCIAL_OTHERS_PROFILE_FOLLOWING_BTN".localized()
        case .answer: return "TXT_SOCIAL_OTHERS_PROFILE_FOLLOW_REQUEST".localized()
        case .waiting: return "TXT_SOCIAL_OTHERS_PROFILE_REQUESTED_BTN".localized()
        }
    }
    
    var buttonBorderColor : CGColor {
        switch self {
        case .none: return UIColor.clear.cgColor
        case .follow,.answer: return UIColor.vtBlueColor.cgColor
        case .following,.waiting: return UIColor.vtGrayColor.cgColor
        }
    }
    
    var buttonBackgroundColor : UIColor {
        switch self {
        case .none: return UIColor.clear
        case .follow,.answer: return UIColor.vtBlueColor
        case .following,.waiting: return UIColor.white
        }
    }
    
    var buttonTitleColor : UIColor {
        switch self {
        case .none: return UIColor.clear
        case .follow,.answer: return UIColor.white
        case .following,.waiting: return UIColor.vtGrayColor
        }
    }
    
    var buttonImage : UIImage? {
        switch self {
        case .none: return nil
        case .follow: return #imageLiteral(resourceName: "btnFollowMini")
        case .following: return #imageLiteral(resourceName: "btnFollowingMini")
        case .answer: return #imageLiteral(resourceName: "btnRequestedBlue")
        case .waiting: return #imageLiteral(resourceName: "btnRequested")
        }
    }
}

protocol FollowingHelperDelegate : class {
    func followStatusChanged(for user:VTUserObject?, at indexPath:IndexPath?)
}

protocol FollowStatusChangeProtocol {
    func followStatusChanged(for user:VTUserObject?, oldStatus:FollowStatus?)
}

class FollowingHelper: NSObject {
    
    weak var delegate : FollowingHelperDelegate?
    var arrIndexPath : [IndexPath] = []
    weak var tableView : UITableView?
    
    func setup(tableView:UITableView?, delegate:FollowingHelperDelegate?) {
        self.tableView = tableView
        self.delegate = delegate
    }
    
    func handleFollowButton(userDetailObject:VTUserDetailObject?, button:UIButton?) {
        guard let userObject = userDetailObject, let button = button else { return }
        button.setTitleWithoutAnimation(title: userObject.followStatus.buttonTitle)
        button.setTitleColor(userObject.followStatus.buttonTitleColor, for: .normal)
        button.layer.borderColor = userObject.followStatus.buttonBorderColor
        button.backgroundColor = userObject.followStatus.buttonBackgroundColor
    }
    
    func handleFollowButton(peopleProtocol:PeopleCellProtocol) {
        guard let button = peopleProtocol.btnFollowRequest else {return}
        if let _ = indexOfIndexPathIfAlive(indexPath: peopleProtocol.indexPath) {
            button.setImage(nil, for: .normal)
            peopleProtocol.viewMultipleChoiseRequest?.isHidden = true
            let indicator = self.getActivityIndicator()
            button.addSubview(indicator)
            indicator.autoCenterInSuperview()
        } else {
            for subview in button.subviews where subview.isKind(of: UIActivityIndicatorView.self) {
                subview.removeFromSuperview()
            }
            self.handleSmallFollowButton(peopleProtocol:peopleProtocol)
        }
    }
    
    func handleSmallFollowButton(peopleProtocol:PeopleCellProtocol) {
        guard let userObject = peopleProtocol.user else { return }
        if userObject.followStatus == .answer {
            if peopleProtocol.useMultipleView {
                peopleProtocol.btnFollowRequest?.setImage(nil, for: .normal)
                peopleProtocol.viewMultipleChoiseRequest?.isHidden = false
            } else {
                peopleProtocol.viewMultipleChoiseRequest?.isHidden = true
                peopleProtocol.btnFollowRequest?.setImage(userObject.followStatus.buttonImage, for: .normal)
            }
        } else {
            peopleProtocol.viewMultipleChoiseRequest?.isHidden = true
            peopleProtocol.btnFollowRequest?.setImage(userObject.followStatus.buttonImage, for: .normal)
        }
    }
    
    func changeFollowStatus(for user:VTUserDetailObject?, button:UIButton, completion:@escaping (_ oldStatus:Int,_ newStatus:Int)->()) {
        guard let userId = user?.userID, let followStatus = user?.addFriend else {return}
        self.showAlertIfNeccesary(followStatus: followStatus) { (answerValue) in
            VTWebService.changeFollowStatus(friendId: userId, followStatus: followStatus, answerValue: answerValue, showInfo: true, onStart: {
            }, success: { [weak self] (task, response) in
                if let response = response, response.statusCode == .success || response.statusCode == .warningWithMessage, let follow = VTFollowResponse.init(object:response.responseData).addFriend {
                    let oldStatus = user?.followStatus
                    user?.addFriend = follow
                    self?.handleFollowButton(userDetailObject: user, button: button)
                    completion(followStatus,follow)
                    self?.fireFollowStatusChangedProtocol(for: user?.userObject, oldStatus: oldStatus)
                }
            }, failure: { (task, response, error) in })
        }
    }
}

extension FollowingHelper: PeopleTableCellDelegate {
    
    func peopleCellWillRequestFollowAction(peopleCell: PeopleCellProtocol,answerValue:Bool?) {
        let indexPath = peopleCell.indexPath
        let user = peopleCell.user
        guard let userId = user?.userID, let followStatus = user?.addFriend else {return}
        
        self.showAlertIfNeccesary(followStatus: followStatus, answerValue: answerValue) { (answerValue) in
            VTWebService.changeFollowStatus(friendId: userId, followStatus: followStatus, answerValue: answerValue, showInfo: false, onStart: { [weak self] in
                self?.addIndexPath(indexPath: indexPath)
                self?.handleFollowButton(peopleProtocol:peopleCell)
            }, success: { [weak self] (task, response) in
                if let response = response, response.statusCode == .success || response.statusCode == .warningWithMessage, let follow = VTFollowResponse.init(object:response.responseData).addFriend {
                    let oldStatus = user?.followStatus
                    user?.addFriend = follow
                    self?.delegate?.followStatusChanged(for: user, at: indexPath)
                    self?.fireFollowStatusChangedProtocol(for: user, oldStatus: oldStatus)
                }
                self?.removeIndexPath(indexPath: indexPath)
                if let indexPath = indexPath, var cell = self?.tableView?.cellForRow(at: indexPath) as? PeopleCellProtocol {
                    cell.user = user
                    self?.handleFollowButton(peopleProtocol:cell)
                }
            }, failure: { [weak self] (task, response, error) in
                self?.removeIndexPath(indexPath: indexPath)
                if let indexPath = indexPath, let cell = self?.tableView?.cellForRow(at: indexPath) as? PeopleCellProtocol {
                    self?.handleFollowButton(peopleProtocol:cell)
                }
            })
        }
    }
    
    func peopleCellNeedHandlingFollowButton(peopleCell: PeopleCellProtocol) {
        self.handleFollowButton(peopleProtocol:peopleCell)
    }
}

internal extension FollowingHelper {
    
    // MARK: Utilities
    
    func fireFollowStatusChangedProtocol(for user:VTUserObject?, oldStatus:FollowStatus?) {
        guard let tabbar = VTSingleton.shared.tabbarSocialMedia, let currentNavcon = tabbar.viewControllers?[tabbar.selectedIndex] as? UINavigationController else {return}
        if tabbar.selectedIndex != 0 {
            tabbar.feedVC.followStatusChanged(for: user, oldStatus: oldStatus)
        }
        for index in 0..<currentNavcon.viewControllers.count {
            let viewController = currentNavcon.viewControllers[index]
            if let delegate = delegate, delegate === viewController {
                continue
            }
            if viewController is FollowStatusChangeProtocol {
                (viewController as! FollowStatusChangeProtocol).followStatusChanged(for: user, oldStatus: oldStatus)
            }
        }
    }
    
    func getActivityIndicator() -> UIActivityIndicatorView {
        let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
        activityIndicator.hidesWhenStopped = true
        activityIndicator.color = UIColor.vtBlueColor
        activityIndicator.startAnimating()
        return activityIndicator
    }
    
    func addIndexPath(indexPath:IndexPath?) {
        guard let indexPath = indexPath else { return }
        arrIndexPath.append(indexPath)
    }
    
    func removeIndexPath(indexPath:IndexPath?) {
        guard let index = indexOfIndexPathIfAlive(indexPath: indexPath) else { return }
        arrIndexPath.remove(at: index)
    }
    
    @discardableResult
    func indexOfIndexPathIfAlive(indexPath:IndexPath?) -> Int? {
        guard let indexPath = indexPath else { return nil }
        for index in 0..<arrIndexPath.count {
            let item = arrIndexPath[index]
            if item.section == indexPath.section && item.row == indexPath.row {
                return index
            }
        }
        return nil
    }
    
    func showAlertIfNeccesary(followStatus:Int,answerValue:Bool? = nil, completion:@escaping (_ answerValue:Bool?)->()) {
        if let answerValue = answerValue {
            completion(answerValue)
        } else {
            switch FollowStatus(rawValue:followStatus)! {
            case .follow:
                completion(nil)
                break
            case .following:
                VTAlertManager.sharedManager.show("TXT_COMMON_COMMON_WARNING".localized(), message: "TXT_SOCIAL_FOLLOW_REQUEST_CANCEL".localized(), buttons: ["TXT_COMMON_COMMON_YES".localized(),"TXT_COMMON_COMMON_CANCEL".localized()], tapBlock: { (action, index) in
                    if index == 0 {
                        completion(nil)
                    }
                })
                break
            case .answer:
                VTAlertManager.sharedManager.show("TXT_COMMON_COMMON_WARNING".localized(), message: "TXT_SOCIAL_FOLLOW_REQUEST_ANSWER".localized(), buttons: ["TXT_COMMON_COMMON_YES".localized(),"TXT_COMMON_COMMON_NO".localized(),"TXT_COMMON_COMMON_CANCEL".localized()], tapBlock: { (action, index) in
                    if index == 0 {
                        completion(true)
                    } else if index == 1 {
                        completion(false)
                    }
                })
                break
            case .waiting:
                VTAlertManager.sharedManager.show("TXT_COMMON_COMMON_WARNING".localized(), message: "TXT_SOCIAL_FOLLOW_REQUEST_WAITING".localized(), buttons: ["TXT_COMMON_COMMON_YES".localized(),"TXT_COMMON_COMMON_CANCEL".localized()], tapBlock: { (action, index) in
                    if index == 0 {
                        completion(nil)
                    }
                })
                break
            default:
                break
            }
        }
    }
}

//
//  OrderHelper.swift
//  Viatori
//
//  Created by Nermin Sarifakioglu on 21/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class OrderHelper: NSObject {

    static func getPriceText(price:Float?) -> String {
        if let value = price, let currency=VTOrderManager.sharedInstance.currency?.description {
            if ( Float(Int(value)) == value) {
                return String(format: "%d %@", Int(value), currency)

            } else {
            
                return String(format: "%.2f %@", value, currency)
            }
        }
        return ""
    }

    static func getPriceText(price:String?) -> String{
        if let value = price, let currency=VTOrderManager.sharedInstance.currency?.description {
            return String(format: "%@ %@", value, currency)
        }
        return ""
    }
    static func getPriceTextWithSeperator(price:Float?) -> String {
        if let value=price {
            if ( value==0){
                return ""
            } else {
                let priceText = getPriceText(price: value)
                return String ( format:"· %@  ",priceText)
            }
        }
         return ""
    }

    static func getOptionPriceText(price:Float?) -> String {
        if let value=price {
            if ( value==0){
                return ""
            } else {
                let priceText = getPriceText(price: value)
                return String ( format:" + %@  ",priceText)
            }
        }
        return ""
    }
    
    static func getOptionText( optionDetail: VTMenuDetailList ) -> String {
        var price:Float? = optionDetail.price
        if ( price == nil) {price = 0}
        
        if let name=optionDetail.name {
            return String( format:"%@%@",name, OrderHelper.getOptionPriceText(price: price!))
        }
        return ""
    }
}

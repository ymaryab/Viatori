//
//  SignupHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 06/01/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

enum SignupType : Int {
    case email = 4
    case phone = 5
    case facebook = 1
    case twitter = 2
    case googlePlus = 3
    //case email,phone,facebook = 1,twitter = 2,googlePlus=3
}

class SignupHelper: NSObject {

    var signupType : SignupType = .email
    var signupEmail : String?
    var signupPhone : String?
    var signupCountryCode : String?
    var signupFullname : String?
    var signupPassword : String?
    var signupProfileImage : UIImage?
    var signupToken : String?
    var signupUserId : String?
    var isFromForgotPassword = false
    var isForUpdate = false
    var signupSuggestedUsers : [VTUserObject]?
    
    var signupSocialMedia : SocialMediaObject?
    
    weak var currentViewController : SignupBaseVC?
}

extension SignupHelper {
    
    // MARK: Signup Service Method Helpers
    
    func checkMailOrPhoneIsValid(input:String,countryCode:String = "",completion:@escaping (Bool,String)->()) {
        
        self.signupEmail = nil
        self.signupCountryCode = nil
        self.signupPhone = nil
        
        if self.signupType == .email {
            self.signupEmail = input
            VTWebService.checkMail(mail: input,isFromForgotPassword: self.isFromForgotPassword, onStart: { [weak self] in
                self?.handleIndicator(isStarting: true)
                }, success: { [weak self] (task, response) in
                    _ = self?.handleDefaultResponse(response: response, completion: completion)
                }, failure: { [weak self] (task, response, error) in
                    self?.handleDefaultError()
            })
            
        } else if self.signupType == .phone {
            self.signupPhone = input
            self.signupCountryCode = countryCode
            VTWebService.checkPhone(countryCode: countryCode, phone: input, isFromForgotPassword: self.isFromForgotPassword, onStart: { [weak self] in
                self?.handleIndicator(isStarting: true)
                }, success: { [weak self] (task, response) in
                    _ = self?.handleDefaultResponse(response: response, completion: completion)
                }, failure: { [weak self] (task, response, error) in
                    self?.handleDefaultError()
            })
        }
    }
    
    func checkActivationCode(activationCode:String,completion:@escaping (Bool,String)->()) {
        
        VTWebService.checkActivationCode(activationCode: activationCode,input:self.getInput(),countryCode:self.signupCountryCode, isForForgotPassword:self.isFromForgotPassword, forUpdate:self.isForUpdate,onStart: { [unowned self] in
            self.handleIndicator(isStarting: true)
            }, success: { [weak self] (task, response) in
                guard let weakSelf = self else {return}
                if let response = response, response.statusCode == .success || response.statusCode == .warningWithMessage  {
                    if weakSelf.isFromForgotPassword {
                        if response.statusCode == .success {
                            let forgotPasswordResponse = VTForgotPasswordResponse.init(object: (response.responseData)!)
                            weakSelf.signupToken = forgotPasswordResponse.token
                            weakSelf.signupUserId = forgotPasswordResponse.userId
                        }
                    } else if weakSelf.isForUpdate {
                        response.statusCode = .success
                        if let user = VTSingleton.shared.user {
                            if weakSelf.signupType == .email {
                                user.userEmail = weakSelf.getInput()
                            } else if weakSelf.signupType == .phone {
                                user.countryCode = weakSelf.signupCountryCode
                                user.userTelephone = weakSelf.getInput()
                            }
                        }
                    }
                }
                weakSelf.handleDefaultResponse(response: response, completion: completion)
            }, failure: { [weak self] (task, response, error) in
                self?.handleDefaultError()
        })
    }
    
    func checkPassword(password:String,completion:@escaping (Bool,String)->()) {
        
        self.signupPassword = password
        VTWebService.checkPassword(password: password, onStart: { [unowned self] in
            self.handleIndicator(isStarting: true)
            }, success: { [weak self] (task, response) in
                _ = self?.handleDefaultResponse(response: response, completion: completion)
            }, failure: { [weak self] (task, resposne, error) in
                self?.handleDefaultError()
        })
    }
    func sendActivationCode() {
        self.handleIndicator(isStarting: true)
        
        VTWebService.sendActivationCode(type: self.getType(), input: self.getInput(), countryCode: self.signupCountryCode, isForForgotPassword:self.isFromForgotPassword ,success: { [weak self] (task, response) in
            self?.handleIndicator(isStarting: false)
        }) { [weak self] (task, response, error) in
            self?.handleDefaultError()
        }
    }
    
    func register(with username:String,completion:@escaping (Bool,String)->()) {
        
        var phone : String?
        if let signupPhone = self.signupPhone, let signupCountryCode = self.signupCountryCode {
            phone = "\(signupCountryCode)\(signupPhone)"
        }
        
        VTWebService.register(email: self.signupEmail,
                              phone: phone,
                              password: self.signupPassword,
                              username: username,
                              fullName: self.signupFullname!,
                              socialMediaKey:self.getSocialMediaKey(),
                              socialMediaId:self.signupSocialMedia?.userId,
                              facebookToken:self.signupSocialMedia?.facebookToken,
                              twitterAuthToken:self.signupSocialMedia?.twitterAuthToken,
                              twitterAuthSecret:self.signupSocialMedia?.twitterAuthTokenSecret,
                              onStart: { [weak self] in
                                self?.handleIndicator(isStarting: true)
            }, success: { [weak self] (task, response) in
                let responseData = self?.handleDefaultResponse(response: response, completion: completion)
                if let responseData = responseData {
                    _ = self?.handleRegisterResponse(response: VTRegisterResponse.init(object: responseData))
                }
            }, failure: { [weak self] (task, response, error) in
                self?.handleDefaultError()
        })
    }
    
    func updateUser(gender:String?,birthday:String?,completion:@escaping ()->()) {
        
        VTWebService.updateUser(token: self.signupToken!, userId: self.signupUserId!, gender: gender, birthday: birthday, onStart: { [weak self] in
            self?.handleIndicator(isStarting: true)
            }, success: { [weak self] (task, response) in
                self?.handleIndicator(isStarting: false)
                if let response = response {
                    if response.statusCode == .success {
                        completion()
                    }
                }
            }, failure: { [weak self] (task, response, error) in
                self?.handleDefaultError()
        })
    }
}

extension SignupHelper {
    
    // MARK: Login Service Method Helpers
    
    func login(email:String?,phone:String?,password:String,completion:@escaping ()->()) {
        
        self.handleIndicator(isStarting: true)
        VTWebService.login(email: email, phone: phone, password: password, onStart: { [weak self] in
                self?.handleIndicator(isStarting: true)
            }, success: { [weak self] (task, response) in
                self?.handleIndicator(isStarting: false)
                if let response = response {
                    if response.statusCode == .success {
                        _ = self?.handleLoginResponse(response: VTRegisterResponse.init(object: response.responseData))
                        completion()
                    }
                }
            }, failure: { [weak self] (task, response, error) in
                self?.handleDefaultError()
            })
    }
    
    func updatePassword(password:String,completion:@escaping ()->()) {
        
        VTWebService.updatePassword(token: self.signupToken!, userId: self.signupUserId!, password: password, onStart: { [weak self] in
            self?.handleIndicator(isStarting: true)
            }, success: { [weak self] (task, response) in
                self?.handleIndicator(isStarting: false)
                if let response = response {
                    if response.statusCode == .success {
                        VTSingleton.shared.userId = self?.signupUserId
                        VTSingleton.shared.userToken = self?.signupToken
                        completion()
                    }
                }
            }, failure: { [weak self] (task, response, error) in
                self?.handleDefaultError()
        })
    }
}

internal extension SignupHelper {
    
    // MARK: Internal Helper Methods
    
    internal func getType() -> String {
        if self.signupType == .email {
            return "1"
        } else if (self.signupType == .phone) {
            return "0"
        } else {
            return ""
        }
    }
    
    internal func getInput() -> String {
        if self.signupType == .email {
            return self.signupEmail!
        } else if (self.signupType == .phone) {
            return self.signupPhone!
        } else {
            return ""
        }
    }
    
    internal func getSocialMediaKey() -> String? {
        switch self.signupType {
        case .facebook:
            return "facebook_id"
        case .twitter:
            return "twitter_id"
        case .googlePlus:
            return "google_id"
        default:
            return nil
        }
    }
    
    @discardableResult
    internal func handleDefaultResponse(response:VIAResponse?,completion: (Bool,String)->()) -> [AnyHashable:Any]? {
        self.handleIndicator(isStarting: false)
        if let response = response {
            if response.statusCode == .success {
                completion(true,"")
                if let responseData = response.responseData {
                    return responseData
                }
            } else if response.statusCode == .warning {
                completion(false,response.message)
            }
        }
        return nil
    }
    
    internal func handleRegisterResponse(response:VTRegisterResponse) {
        self.signupToken = response.token
        self.signupUserId = response.userId
        self.signupSuggestedUsers = response.suggestedUsers
        VTSingleton.shared.userId = response.userId
        VTSingleton.shared.userToken = response.token
        self.uploadProfilePictureToAmazon()
    }
    
    internal func handleLoginResponse(response:VTRegisterResponse) {
        self.signupToken = response.token
        self.signupUserId = response.userId
        VTSingleton.shared.userId = response.userId
        VTSingleton.shared.userToken = response.token
    }
    
    internal func handleDefaultError() {
        self.handleIndicator(isStarting: false)
    }
    
    internal func handleIndicator(isStarting:Bool) {
        guard let currentVC = currentViewController else {return}
        if isStarting {
            currentVC.serviceOperationStarted()
        } else {
            currentVC.serviceOperationFinished()
        }
    }
    
    internal func uploadProfilePictureToAmazon() {
        if let userId = self.signupUserId, let profileImage = self.signupProfileImage {
            VTAmazonManager.sharedManager.uploadProfilePictureToAmazon(image: profileImage, userId: userId)
        }
    }
}

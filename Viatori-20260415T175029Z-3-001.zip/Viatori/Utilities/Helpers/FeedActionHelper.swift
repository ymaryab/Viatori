//
//  FeedActionHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 22.03.2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class FeedActionHelper: NSObject, SharePopoverDelegate {
    
    private var repostClosure : (()->())?
    private weak var target : UIViewController?
    private lazy var socialMediaHelper = SocialMediaHelper()

    func handleFeedBottomAction(target:UIViewController?, feedObject:VTFeedObject?, action:FeedBottomAction, repostClosure:(()->())?) {
        guard let target = target, let feedObject = feedObject else {return}
        self.repostClosure = repostClosure
        self.target = target
        
        switch action {
        case .share(let sender):
            let popover = UIViewController.controller(for: .socialMediaOther, controllerIdentifier: .sharePopover)! as! SharePopoverController
            popover.feedObject = feedObject
            popover.delegate = self
            target.presentPopover(popover: popover, from: sender, preferredContentSize: CGSize(width: VTConstants.Device.isSmallDevice ? 300 : 350, height: 200))
            break
        case .like:
            if let feedId = feedObject.feedID?.actualId, let postObject = feedObject.postObject ,let liked = postObject.isLiked  {
                VTWebService.likePost(timelineId: feedId, isFollow: !liked, success: { (task, response) in
                    if let response = response, response.statusCode == .success {
                        if let count = feedObject.postLikeCount?.toInt() {
                            feedObject.postLikeCount = liked ? "\(count - 1)" : "\(count + 1)"
                        }
                        postObject.isLiked!.toggle()
                        VTFeedManager.manager.addFeedsToDatasource(feedArray: [feedObject])
                    }
                }, failure: { (task, response, error) in
                    
                })
            }
            break
        case .comment,.commentCount:
            if let feedId = feedObject.feedID {
                if target.isPostDetail {
                    _ = target.extractGallery
                } else {
                    let postDetail = PostDetailViewController.create(with: feedId)
                    target.extractGallery?.navigationController?.pushViewController(postDetail, animated: true)
                }
            }
            break
        case .likeCount:
            if let feedId = feedObject.feedID {
                target.extractGallery?.openPeopleListVC(type: .likes(feedId))
            }
            break
        case .shareCount:
            if let feedId = feedObject.feedID?.actualId {
                target.extractGallery?.openPeopleListVC(type: .reposted(feedId, false))
            }
            break
        }
    }
    
    func sharePopover(sharePopover: SharePopoverController, didSelectedItemWith type: SharePopoverType, feedObject:VTFeedObject?) {
        guard let feedObject = feedObject else { return }
        
        switch type {
        case .repost:
            VTWebService.repost(timelineId: feedObject.actualId!, isReposted: false, success: { [weak self] (task, response) in
                if let response = response, response.statusCode == .success || response.statusCode == .warningWithMessage {
                    self?.repostClosure?()
                }
            }, failure: { (task, response, error) in
                
            })
            break
        case .message:
            guard let subSliding = target?.vtSubSlidingMenu(), let messageNav = subSliding.rightViewController as? UINavigationController else {return}
            messageNav.popToRootViewController(animated: false)
            let friendList = UIViewController.controller(for: .messages, controllerIdentifier: .messageFriendList) as! MessageFriendListViewController
            friendList.feedid = feedObject.feedID!
            messageNav.pushViewController(friendList, animated: false)
            target?.vtSubSlidingMenu()?.menuState = .right
            
            break
        case .facebook:
            socialMediaHelper.shareOnFacebook(feedObject: feedObject, target: target)
            break
        case .twitter:
            socialMediaHelper.shareOnTwitter(feedObject: feedObject, target: target)
            break
        case .copyLink:
            socialMediaHelper.copyClipboard(feedObject: feedObject, target: target)
            break
        case .more:
            socialMediaHelper.shareOnActivity(feedObject: feedObject, target: target)
            break
        }
    }
    
    deinit {
        debugPrint("FeedActionHelper deinitialized")
    }
}

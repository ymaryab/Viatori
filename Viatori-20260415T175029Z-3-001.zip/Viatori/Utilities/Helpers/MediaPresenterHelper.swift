//
//  MediaPresenterHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 17/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class MediaPresenterHelper: NSObject {

    @discardableResult
    func showFeedMediaPresenter(targetVC:UIViewController, feedObjects:[VTFeedObject], presentingFrom:UIImageView?, presentationIndex : Int = 0 ,customCallBack:Bool = false) -> MHGalleryController? {
        guard let gallery = MHGalleryController.init(presentationStyle: .imageViewerNavigationBarHidden) else {return nil}
        gallery.galleryItems = []
        gallery.fromVC = targetVC
        
        for feed in feedObjects {
            if let postObject = feed.postObject, postObject.mediaType == .video || postObject.mediaType == .photo {
                if postObject.mediaType == .video {
                    handleViewCount(feedObject: feed)
                    if let item = MHGalleryItem.init(url: postObject.videoURL, galleryType: .video) {
                        item.thumbnailURL = postObject.hasThumbnail ? postObject.videoThumbnailURL : nil
                        item.feedObject = feed
                        gallery.galleryItems.append(item)
                    }
                } else {
                    if let item = MHGalleryItem.init(url: postObject.photoURLArray?[0], galleryType: .image) {
                        item.feedObject = feed
                        gallery.galleryItems.append(item)
                    }
                }
            }
        }
        
        if gallery.galleryItems.count > 0 {
            gallery.presentingFromImageView = presentingFrom
            gallery.presentationIndex = presentationIndex
            gallery.uiCustomization.showOverView = false
            weak var blockGal = gallery
            
            if !customCallBack {
                gallery.finishedCallback = { [weak blockGal] currentIndex, image, interactiveTransition, viewMode in
                    DispatchQueue.main.async(execute: { [weak blockGal] in
                        blockGal?.dismiss(animated: true, dismiss: presentingFrom, completion: nil)
                    })
                }
            }
            
            ViewStackHelper.getControllerToShowAlert().present(with: gallery, animated: true, completion: nil)
            return gallery
        }
        return nil
    }
    
    func showDefaultMediaPresenter(medias:[MHGalleryType:Any], presentingFrom:UIImageView?, targetVC:UIViewController? = nil) {
        
        guard let gallery = MHGalleryController.init(presentationStyle: .imageViewerNavigationBarHidden) else {return}
        gallery.galleryItems = []
        for (type,media) in medias {
            var item : MHGalleryItem?
            if let media = media as? UIImage {
                item = MHGalleryItem.init(image: media)
            } else if let media = media as? String {
                item = MHGalleryItem.init(url: media, galleryType: type)
            }
            if let item = item {
                gallery.galleryItems.append(item)
            }
        }
        
        if gallery.galleryItems.count > 0 {
            gallery.presentingFromImageView = presentingFrom
            gallery.presentationIndex = 0
            gallery.uiCustomization.showOverView = false
            weak var blockGal = gallery
            
            gallery.finishedCallback = { [weak blockGal] currentIndex, image, interactiveTransition, viewMode in
                DispatchQueue.main.async(execute: { [weak blockGal] in
                    blockGal?.dismiss(animated: true, dismiss: presentingFrom, completion: nil)
                })
            }
            
            ViewStackHelper.getControllerToShowAlert().present(with: gallery, animated: true, completion: nil)
        }
    }
}

private extension MediaPresenterHelper {
    
    func handleViewCount(feedObject:VTFeedObject) {
        guard let feedId = feedObject.actualId else { return }
        
        VTWebService.updateVideoViewCount(timelineId: feedId, success: { [weak self] (task, response) in
            if let response = response, response.statusCode == .success,
                let responseData = response.responseData,
                let viewCount:String =  try? responseData.value(for: "ViewCount") {
                feedObject.viewCount = viewCount
            }
        }) { (task, response, error) in
        }
        
    }
}

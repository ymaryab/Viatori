//
//  FeedArrowMenuHelper.swift
//  Viatori
//
//  Created by ProAegean on 05/05/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class FeedArrowMenuHelper: NSObject {
    
    private weak var targetVC : UIViewController?
    
    internal func showMoreButtonAction(with feedObject : VTFeedObject?, indexPath:IndexPath?, targetVC:UIViewController) {
        guard let feedObject = feedObject else { return }
        
        self.targetVC = targetVC
        let alertController = UIAlertController.init(title: nil, message: nil, preferredStyle: .actionSheet)
        
        if feedObject.isMyPost {
            if feedObject.isRepostedByMe {
                self.addUndoRepostAction(to: alertController,feedObject: feedObject)
            } else {
                self.addDeleteAction(to: alertController,feedObject: feedObject)
                self.addEditAction(to: alertController,feedObject: feedObject)
            }
        } else {
            if feedObject.isRepostedByMe {
                self.addReportAction(to: alertController,feedObject: feedObject)
                self.addUndoRepostAction(to: alertController,feedObject: feedObject)
            } else {
                self.addReportAction(to: alertController,feedObject: feedObject)
                self.addTagAction(to: alertController,feedObject: feedObject)
            }
        }
        
        alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_CANCEL".localized(), style: .cancel, handler: { (alertAction) in
            
        }))
        
        targetVC.present(alertController, animated: true, completion: nil)
    }
    
    func addDeleteAction(to alertController:UIAlertController,feedObject:VTFeedObject) {
        alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_DELETE".localized(), style: .default, handler: { [unowned self] (alertAction) in
            VTWebService.deletePost(timelineId: feedObject.feedID!, success: { (task, response) in
                if let response = response, response.statusCode == .success {
                    NotificationCenter.default.post(name: .deletedPost, object: feedObject.feedID)
                    if let target = self.targetVC?.extractGallery {
                        if target.isPostDetail {
                            target.popVC()
                        } else if let vcBaseFeed = target as? FeedBaseViewController, let index = vcBaseFeed.feedArray.findIndexOfFeed(feed: feedObject) {

                            vcBaseFeed.feedArray.remove(at: index)
                            
                            innerloop: for (key,value) in vcBaseFeed.feedDict {
                                for (index, element) in value.enumerated() {
                                    if element == feedObject.feedID {
                                        vcBaseFeed.feedDict[key]?.remove(at: index)
                                        continue innerloop
                                    }
                                }
                            }
                            
                            if (vcBaseFeed.feedContentType == .media) {
                                vcBaseFeed.collectionView?.deleteItems(at: [IndexPath.init(row: index, section: vcBaseFeed.sectionOfFeeds())])
                            } else {
                                vcBaseFeed.tableView?.beginUpdates()
                                vcBaseFeed.tableView?.deleteRows(at: [IndexPath.init(row: index, section: vcBaseFeed.sectionOfFeeds())], with: .automatic)
                                vcBaseFeed.tableView?.endUpdates()
                            }
                            
                            
                        }
                    }
                }
            }, failure: { (task, response, error) in
                
            })
        }))
    }
    
    func addReportAction(to alertController:UIAlertController,feedObject:VTFeedObject) {
        guard let userId = feedObject.userObject?.userID, let feedId = feedObject.feedID else {return}
        
        alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_REPORT".localized(), style: .default, handler: { [weak self] (alertAction) in
            guard let weakSelf = self else {return}
            weakSelf.targetVC?.extractGallery?.openReportVC(type: .post(feedId,userId), successCompletion: { [weak weakSelf] (alsoBlocked) in
                //feedObject.postObject?.notReported?.toggle()
                //VTFeedManager.manager.addFeedsToDatasource(feedArray: [feedObject])
                //weakSelf?.tableView?.reloadData()
            })
        }))
        
        alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_LESS_SEEN".localized(), style: .default, handler: { [weak self] (alertAction) in
            if let feedId = feedObject.actualId {
                VTWebService.filterSimilarContent(timelineId: feedId, success: { (task, response) in
                
                }, failure: { (task, response, error) in
                
                })
            }
            
        }))
        
    }
    
    func addEditAction(to alertController:UIAlertController,feedObject:VTFeedObject) {
        alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_EDIT".localized(), style: .default, handler: { (alertAction) in
            if let vc = self.targetVC {
                UpdateStatusViewController.present(from: vc, type: .default, feedObject:feedObject)
            }
        }))
    }
    
    func addUndoRepostAction(to alertController:UIAlertController,feedObject:VTFeedObject) {
        guard let feedId = feedObject.actualId else {return}
        alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_POST_UNDO".localized(), style: .default, handler: {(alertAction) in
            VTWebService.repost(timelineId: feedId, isReposted: true, success: { (task, response) in
                
            }, failure: { (task, response, error) in })
        }))
    }
    
    func addTagAction(to alertController:UIAlertController,feedObject:VTFeedObject) {
        if feedObject.tagStatus == .tagged {
            alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_TAG_REMOVE".localized(), style: .default, handler: { [unowned self] (alertAction) in
                guard let feedId = feedObject.actualId else {return}
                VTWebService.removeTag(timelineId: feedId, success: { [weak self] (task, response) in
                    if let response = response, response.statusCode == .success || response.statusCode == .warningWithMessage {
                        if let feed = VTFeedTagResponse.init(object: response.responseData).postDetail {
                            VTFeedManager.manager.addFeedToDatasource(feed: feed)
                            VTSingleton.shared.tabbarSocialMedia?.profileVC.deletePost(with: feed.feedID)
                            if let vc = self?.targetVC {
                                if vc is FeedBaseViewController && !(vc is ProfileViewController) {
                                    if let vcBaseFeed = vc as? FeedBaseViewController {
                                        vcBaseFeed.tableView?.reloadData()
                                    }
                                }
                            }
                        }
                    }
                    }, failure: { (task, response, error) in })
            }))
        } else if feedObject.tagStatus == .haveTagRequest {
            alertController.addAction(UIAlertAction.init(title: "TXT_COMMON_COMMON_TAG_CONFIRM".localized(), style: .default, handler: { [weak self] (alertAction) in
                guard let feedId = feedObject.actualId else {return}
                self?.targetVC?.openPostDetailVC(feedId: feedId)
            }))
        }
    }
    
}

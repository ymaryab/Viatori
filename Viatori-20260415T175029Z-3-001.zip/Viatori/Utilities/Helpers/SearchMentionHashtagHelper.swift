//
//  SearchMentionHashtagHelper.swift
//  Viatori
//
//  Created by Serkut Yegin on 21/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

enum SearchMentionHashtagType {
    case none, mention,mentionPopular , hashtag ,hashtagPopular
}

protocol SearchMentionHashtagHelperDelegate : class {
    func searchHelper(searchHelper:SearchMentionHashtagHelper, didPaste text:String, with type:SearchMentionHashtagType)
}

class SearchMentionHashtagHelper: NSObject {

    weak var delegate : SearchMentionHashtagHelperDelegate?
    internal var collectionView : UICollectionView
    internal var textView : UITextView
    internal var heightConst : NSLayoutConstraint
    internal var containerView : UIView
    internal var popularMentions : [VTUserObject] = []
    internal var mentions : [VTUserObject] = []
    internal var popularHashtags : [VTHashtagObject] = []
    internal var hashtags : [VTHashtagObject] = []
    internal var operation : VIAOperation?
    internal var searchType : SearchMentionHashtagType = .none {
        didSet {
            self.collectionView.reloadData()
            collectionView.collectionViewLayout.invalidateLayout()
        }
    }
    
    init(collectionView:UICollectionView,textView:UITextView,heightConstraint:NSLayoutConstraint,container:UIView) {
        self.collectionView = collectionView
        self.textView = textView
        self.heightConst = heightConstraint
        self.containerView = container
        super.init()
        self.collectionView.register(MentionCollectionCell.self, forCellWithReuseIdentifier: MentionCollectionCell.className)
        self.collectionView.register(HashtagCollectionCell.self, forCellWithReuseIdentifier: HashtagCollectionCell.className)
        self.collectionView.register(UINib.init(nibName: MentionCollectionCell.className, bundle: nil), forCellWithReuseIdentifier: MentionCollectionCell.className)
        self.collectionView.register(UINib.init(nibName: HashtagCollectionCell.className, bundle: nil), forCellWithReuseIdentifier: HashtagCollectionCell.className)
        setup()
    }
    
    private func setup() {
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        (self.collectionView.collectionViewLayout as! UICollectionViewFlowLayout).estimatedItemSize = CGSize.init(width: 100, height: 50)
    }
    
    func textViewDidChange(_ sender:UITextView) {
        RunLoop.cancelPreviousPerformRequests(withTarget: self, selector: #selector(search), object: nil)
        self.perform(#selector(search), with: nil, afterDelay: 0.8)
    }
    
    func search() {
        
        if let mention = self.find(in :textView.text!,type:.mention) {
            
            if mention == "" {
                if self.popularMentions.count == 0 {
                    self.callServiceForAllMentions()
                } else {
                    self.handleMentionResponse(isPopular: true)
                }
            } else {
                self.callServiceForMention(mention: mention)
            }
            
        } else if let hashtag = self.find(in: textView.text!,type:.hashtag){
            
            if hashtag == "" {
                if self.popularHashtags.count == 0 {
                    self.callServiceForAllHashtags()
                } else {
                    self.handleHashtagResponse(isPopular: true)
                }
            } else {
                self.callServiceForHashtag(hashtag: hashtag)
            }
            
        } else {
            self.closeView()
        }
    }
    
    func closeView() {
        self.cancelOperation()
        searchType = .none
        self.openCloseView(open: false)
    }
}

extension SearchMentionHashtagHelper {
    
    func paste(to text:String?,type:SearchMentionHashtagType) {
        guard let pasteText = text, !pasteText.isEmpty else {return}
        let textViewContent = self.textView.text ?? ""
        if let currentMentionHashtagString = self.find(in: textViewContent, type: type) {
            if currentMentionHashtagString.isEmpty {
                self.textView.text = "\(textViewContent)\(pasteText) "
                self.delegate?.searchHelper(searchHelper: self, didPaste: pasteText, with: type)
            } else {
                let text = textViewContent
                let range = self.getRange(mention: text, type: type)
                if let rangeNew = text.range(from: range), range.location != NSNotFound {
                    let stringToPaste = text.replacingCharacters(in: rangeNew, with: pasteText)
                    self.textView.text = "\(stringToPaste) "
                    self.delegate?.searchHelper(searchHelper: self, didPaste: pasteText, with: type)
                }
            }
        }
        self.closeView()
    }
    
    func find(in text:String,type:SearchMentionHashtagType) -> String? {
        var mention : String?
        if !text.isEmpty {
            let lastItem = text[text.length - 1]
            if (type == .mention && lastItem == "@") || (type == .hashtag && lastItem == "#") {
                mention = ""
            } else {
                let range = self.getRange(mention: text,type:type)
                if let rangeNew = text.range(from: range), range.location != NSNotFound {
                    mention = text.substring(with: rangeNew)
                }
            }
        }
        return mention
    }
    
    func getRange(mention:String,type:SearchMentionHashtagType) -> NSRange {
        var range = NSRange.init(location: NSNotFound, length: NSNotFound)
        do {
            let pattern = type == .mention ? "@([\\w\\.\\-\\_]+)" : "#([\\w]+)"
            let regex = try NSRegularExpression.init(pattern: pattern, options: NSRegularExpression.Options.init(rawValue: 0))
            let matches = regex.matches(in: mention, options: NSRegularExpression.MatchingOptions.init(rawValue: 0), range: NSRange.init(location: 0, length: mention.length))
            if matches.count > 0 {
                if let result = matches.last, result.range.location != NSNotFound {
                    let rangeOfTag = result.range
                    let rangeOfText = NSRange.init(location: rangeOfTag.location + 1, length: rangeOfTag.length - 1)
                    let fromMention = mention.substring(from: rangeOfTag.location)
                    if !fromMention.contains(" ") && ((type == .mention && !fromMention.contains("#")) || (type == .hashtag && !fromMention.contains("@"))) {
                        range = rangeOfText
                    }
                }
            }
        } catch {
            return range
        }
        return range
    }
}

extension SearchMentionHashtagHelper : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch searchType {
        case .none:
            return UICollectionViewCell()
        case .mention:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MentionCollectionCell.className, for: indexPath) as! MentionCollectionCell
            cell.setup(user: mentions[indexPath.row])
            return cell
        case .mentionPopular:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MentionCollectionCell.className, for: indexPath) as! MentionCollectionCell
            cell.setup(user: popularMentions[indexPath.row])
            return cell
        case .hashtag:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HashtagCollectionCell.className, for: indexPath) as! HashtagCollectionCell
            cell.setup(hashtag: hashtags[indexPath.row])
            return cell
        case .hashtagPopular:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HashtagCollectionCell.className, for: indexPath) as! HashtagCollectionCell
            cell.setup(hashtag: popularHashtags[indexPath.row])
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch searchType {
        case .none: return 0
        case .mention: return mentions.count
        case .hashtag: return hashtags.count
        case .mentionPopular: return popularMentions.count
        case .hashtagPopular: return popularHashtags.count
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: 50, height: collectionView.bounds.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        switch searchType {
        case .hashtag,.hashtagPopular:
            let cell = collectionView.cellForItem(at: indexPath) as! HashtagCollectionCell
            self.paste(to: cell.hashtag, type: .hashtag)
            break
        case .mention,.mentionPopular:
            let cell = collectionView.cellForItem(at: indexPath) as! MentionCollectionCell
            self.paste(to: cell.userName, type: .mention)
            break
        default:
            break
        }
    }
}

internal extension SearchMentionHashtagHelper {
    
    func callServiceForAllHashtags() {
        self.cancelOperation()
        self.operation = VTWebService.searchAllHashtag(success: { [weak self] (task, response) in
            if let response = response, response.statusCode == .success, let hashtagArray = VTHashtagResponse.init(object: response.responseData).hashtagObject {
                self?.popularHashtags = hashtagArray
            } else {
                self?.popularHashtags = []
            }
            self?.handleHashtagResponse(isPopular: true)
        }) { [weak self] (task, response, error) in
            if ((error as NSError?) != nil), (error! as NSError).code != NSURLErrorCancelled {
                
            } else {
                self?.popularHashtags = []
                self?.handleHashtagResponse(isPopular: true)
            }
        }
    }
    
    func callServiceForHashtag(hashtag:String) {
        self.cancelOperation()
        self.operation = VTWebService.searchHashtag(hashtag: hashtag, success: { [weak self] (task, response) in
            if let response = response, response.statusCode == .success, let hashtagArray = VTHashtagResponse.init(object: response.responseData).hashtagObject {
                self?.hashtags = hashtagArray
            } else {
                self?.hashtags = []
            }
            self?.handleHashtagResponse(isPopular: false)
        }, failure: { [weak self] (task, response, error) in
            if ((error as NSError?) != nil), (error! as NSError).code != NSURLErrorCancelled {
                
            } else {
                self?.hashtags = []
                self?.handleHashtagResponse(isPopular: false)
            }
        })
    }
    
    func callServiceForAllMentions() {
        self.cancelOperation()
        self.operation = VTWebService.searchMention(mention: "", success: { [weak self] (task, response) in
            if let response = response, response.statusCode == .success, let friendArray = VTFriendResponse.init(object: response.responseData).userobject {
                self?.popularMentions = friendArray
            } else {
                self?.popularMentions = []
            }
            self?.handleMentionResponse(isPopular: true)
        }) { [weak self] (task, response, error) in
            if ((error as NSError?) != nil), (error! as NSError).code != NSURLErrorCancelled {
                
            } else {
                self?.popularMentions = []
                self?.handleMentionResponse(isPopular: true)
            }
        }
    }
    
    func callServiceForMention(mention:String) {
        self.cancelOperation()
        self.operation = VTWebService.searchMention(mention: mention, success: { [weak self] (task, response) in
            if let response = response, response.statusCode == .success, let friendArray = VTFriendResponse.init(object: response.responseData).userobject {
                self?.mentions = friendArray
            } else {
                self?.mentions = []
            }
            self?.handleMentionResponse(isPopular: false)
        }) { [weak self] (task, response, error) in
            if ((error as NSError?) != nil), (error! as NSError).code != NSURLErrorCancelled {
                
            } else {
                self?.mentions = []
                self?.handleMentionResponse(isPopular: true)
            }
        }
    }
    
    func handleMentionResponse(isPopular:Bool) {
        self.searchType = isPopular ? .mentionPopular : .mention
        if searchType == .mention {
            if mentions.count == 0 {
                self.openCloseView(open: false)
            } else {
                self.openCloseView(open: true)
            }
        } else {
            if popularMentions.count == 0 {
                self.openCloseView(open: false)
            } else {
                self.openCloseView(open: true)
            }
        }
    }
    
    func handleHashtagResponse(isPopular:Bool) {
        self.searchType = isPopular ? .hashtagPopular : .hashtag
        if searchType == .hashtag {
            if hashtags.count == 0 {
                self.openCloseView(open: false)
            } else {
                self.openCloseView(open: true)
            }
        } else {
            if popularHashtags.count == 0 {
                self.openCloseView(open: false)
            } else {
                self.openCloseView(open: true)
            }
        }
    }
    
    func cancelOperation() {
        if let operation = self.operation {
            (VIAServiceHandler.sharedHandler() as! VIAServiceHandler).cancel(operation, forceCancel: true)
        }
        self.operation = nil
    }
    
    func openCloseView(open:Bool) {
        self.containerView.layoutIfNeeded()
        UIView.animate(withDuration: 0.2) { 
            self.heightConst.constant = open ? 51 : 0
            self.containerView.layoutIfNeeded()
        }
    }
}

extension String {
    
    func range(from nsRange: NSRange) -> Range<String.Index>? {
        guard
            let from16 = utf16.index(utf16.startIndex, offsetBy: nsRange.location, limitedBy: utf16.endIndex),
            let to16 = utf16.index(from16, offsetBy: nsRange.length, limitedBy: utf16.endIndex),
            let from = from16.samePosition(in: self),
            let to = to16.samePosition(in: self)
            else { return nil }
        return from ..< to
    }
}

//
//  VTConstants.swift
//  Viatori
//
//  Created by Serkut Yegin on 23/12/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

struct VTConstants {
    
    struct Constants {
        static let ProfileImage_Size : CGFloat = 512
        static let CoverPhoto_Size : CGFloat = 1024
        static let MediaImage_Size : CGFloat = 512
        static let CharacterCount : Int = 175
        static let CharacterControlCount : Int = 275
        static let MessageCharacterCount : Int = 500
    }
    
    struct NotificationKey {
        
    }
    
    struct Path {
        static let Documents = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        static let Temp = NSTemporaryDirectory()
        static func databasePath(_ name: String) -> String {
            return "\(self.Documents)/\(name)"
        }
    }
    
    struct Device {
        
        static let PreferredLanguage = Locale.preferredLanguages[0]
        static let LanguageDict = Locale.components(fromIdentifier:Device.PreferredLanguage)
        static let PreferredLanguageCode = Device.LanguageDict["kCFLocaleLanguageCodeKey"]
        
        static let Idiom = UIDevice.current.userInterfaceIdiom
        static let releaseVersionNumber = Bundle.main.releaseVersionNumber
        static let buildVersionNumber = Bundle.main.buildVersionNumber
        
        static let Width = UIApplication.shared.keyWindow!.w
        static var isSmallDevice : Bool {
            return self.Width <= 320
        }
        
        static var isIpad : Bool {
            return self.Idiom == .pad
        }
    }
    
    struct UserPreference {
        static let languageCode = "VTCONSTANTS_LANGUAGE_CODE"
        static let preferredLanguageCode = "VTCONSTANTS_PREFERRED_LANGUAGE_CODE"
        static let useOfflineMode = "VTCONSTANTS_SHOULD_USE_OFFLINE_MODE"
        
        static let profileImageFileName = "VTCONSTANTS_PROFILE_IMAGE_FILE_NAME"
        static let profileImageFileUrl = "VTCONSTANTS_PROFILE_IMAGE_FILE_URL"
        static let profileImageUploadStarted = "VTCONSTANTS_PROFILE_IMAGE_UPLOAD_STARTED"
        
        static let mediaPhotoFileName = "VTCONSTANTS_MEDIA_PHOTO_FILE_NAME"
        static let mediaPhotoFileUrl = "VTCONSTANTS_MEDIA_PHOTO_FILE_URL"
        static let mediaPhotoFileUploadStarted = "VTCONSTANTS_MEDIA_PHOTO_UPLOAD_STARTED"
        
        static let userId = "VTCONSTANTS_USER_ID"
        static let userToken = "VTCONSTANTS_USER_TOKEN"
        
        static let alsoShareOnFacebook = "VTCONSTANTS_ALSO_SHARE_ON_FACEBOOK"
        static let alsoShareOnTwitter = "VTCONSTANTS_ALSO_SHARE_ON_TWITTER"
    }
    
    struct Strings {
        static let dbNameUpdateStatus = "updateStatusDB"
        
        static let facebookAppId = "fb328220484190202"
        static let allowedCharsForUsername = "ABCDEFGHIJKLMNOPQRSTUVWYXZ1234567890abcdefghijklmnopqrstuvwxyz._-"
        static let S3BucketName = "viatori-s3"
        static let AmazonBaseUrl = "https://s3.eu-central-1.amazonaws.com/"
        static let AmazonUrl = "\(AmazonBaseUrl)\(S3BucketName)/"
        static let AmazonProfileImageBaseURL = "\(AmazonUrl)ProfileImages/"
        static let AmazonCoverPhotoBaseURL = "\(AmazonUrl)CoverPhotos/"
        
        static func profilImageUrl(userId:String) -> String {
            return "\(AmazonUrl)\(userId)/profile_image.png"
        }
        
        static func amazonProfileImageUrl(userId:String, fileName:String) -> String {
            return "ProfileImages/\(userId)/\(fileName).png"
        }
        
        static func amazonProfileImageFullUrl(fileName:String?) -> String? {
            guard let userId = VTSingleton.shared.user?.userID, let fileName = fileName else {return nil}
            return "\(AmazonProfileImageBaseURL)\(userId)/\(fileName).png"
        }
        
        static func amazonCoverPhotoUrl(userId:String, fileName:String) -> String {
            return "CoverPhotos/\(userId)/\(fileName).png"
        }
        
        static func amazonCoverFullUrl(fileName:String?) -> String? {
            guard let userId = VTSingleton.shared.user?.userID, let fileName = fileName else {return nil}
            return "\(AmazonCoverPhotoBaseURL)\(userId)/\(fileName).png"
        }
        
        static func amazonProfilImageUrl(userId:String) -> String {
            return "ProfileImages/\(userId)/profileImage.png"
        }
        
        static func amazonMediaImageUrl(userId:String,fileName:String) -> String {
            return "Content/Timeline/\(userId)/\(fileName).png"
        }
        
        static func amazonMessageMediaImageUrl(userId:String,fileName:String,roomId:String) -> String {
            return "Message/\(roomId)/\(userId)/\(fileName).png"
        }

        
        static func amazonMediaVideoUrl(userId:String,fileName:String) -> String {
            return "Content/Timeline/\(userId)/\(fileName).mp4"
        }
        
        static func amazonPhotoFullUrl(fileName:String?) -> String? {
            guard let userId = VTSingleton.shared.user?.userID, let fileName = fileName else {return nil}
            if fileName.contains(VTConstants.Strings.AmazonUrl) {
                return fileName
            }
            return "\(AmazonUrl)Content/Timeline/\(userId)/\(fileName).png"
        }
        
        static func amazonVideoFullUrl(fileName:String?) -> String? {
            guard let userId = VTSingleton.shared.user?.userID, let fileName = fileName else {return nil}
            if fileName.contains(VTConstants.Strings.AmazonUrl) {
                return fileName
            }
            return "\(AmazonUrl)Content/Timeline/\(userId)/\(fileName).mp4"
        }
        
        static func amazonMessageImageFullUrl(fileName:String?) -> String? {
            guard let userId = VTSingleton.shared.user?.userID, let fileName = fileName else {return nil}
            if fileName.contains(VTConstants.Strings.AmazonUrl) {
                return fileName
            }
            return "\(AmazonUrl)Content/Message/\(userId)/\(fileName).png"
        }
        
    }
}

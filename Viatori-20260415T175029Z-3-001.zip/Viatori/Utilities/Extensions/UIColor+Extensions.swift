//
//  UIColor+Extensions.swift
//  Viatori
//
//  Created by Serkut Yegin on 22/12/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

extension UIColor {
    
    class var vtSocialTabbarBg : UIColor {
        return UIColor(r: 247, g: 247, b: 247) //F7F7F7
    }

    class var vtSearchBarBg: UIColor {
        return UIColor(r:234, g:238, b:242)
    }

    class var vtLightBlackColor : UIColor {
        return UIColor(r: 24, g: 29, b: 36)
    }
    
    class var vtDarkGrayColor : UIColor {
        return UIColor(r: 51, g: 51, b: 51) //333333
    }

    class var vtDarkGrayColor2 : UIColor {
        return UIColor(r: 69, g: 78, b: 91)
    }

    class var vtDarkGrayColor3 : UIColor {
        return UIColor(r: 96, g: 107, b: 122)
    }
    
    class var vtGrayColor : UIColor {
        return UIColor(r: 130, g: 143, b: 161) //828FA1
    }
    
    class var vtGrayColor2 : UIColor {
        return UIColor(r: 163, g: 165, b: 167) //828FA1
    }

    class var vtGrayColor3 : UIColor {
        return UIColor(r: 157, g: 157, b: 157)
    }

    class var vtGrayColor4 : UIColor {
        return UIColor(r: 187, g: 197, b: 211)
    }
    
    class var vtLightGrayColor : UIColor {
        return UIColor(r: 200, g: 200, b: 200) //C8C8C8
    }
    
    class var vtBlueColor : UIColor {
        return UIColor(r: 69, g: 145, b: 255)
    }
    
    class var vtRedColor : UIColor {
        return UIColor(r: 238, g: 69, b: 69)
    }
    
    class var vtGreenColor : UIColor {
        return UIColor(r: 62, g: 187, b: 0)
    }
    
    class var vtPinkColor : UIColor {
        return UIColor(r: 255, g: 78, b: 107)
    }
    

    class var vtWhiteColor1 : UIColor {
        return UIColor(r: 249, g: 251, b: 253)
    }
    
     class var vtOrangeColor : UIColor {
        return UIColor(r: 255, g: 160, b: 67)

    }
    
}

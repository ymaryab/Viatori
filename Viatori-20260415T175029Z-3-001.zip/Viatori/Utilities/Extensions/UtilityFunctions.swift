//
//  UtilityFunctions.swift
//  Viatori
//
//  Created by Serkut Yegin on 03/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import RealmSwift

public class UtilityFunctions {

    public func convertToUserIdString(userObjects:[VTUserObject]) -> String {
        var string = ""
        for index in 0..<userObjects.count {
            let item = userObjects[index]
            if index == userObjects.count - 1 {
                string = "\(string)\(item.userID!)"
            } else {
                string = "\(string)\(item.userID!),"
            }
        }
        if !string.isEmpty && string[string.length - 1] == "," {
            string = String(string.characters.dropLast())
        }
        return string
    }
    
    public func converToDBTagArray(dbArray:[DBUserObject]?) -> [VTUserObject]? {
        guard let dbArray = dbArray, dbArray.count > 0 else {return nil}
        var convertedArray : [VTUserObject] = []
        for item in dbArray {
            convertedArray.append(item.convertToVTUser())
        }
        return convertedArray
    }
    
    public var phoneNoFormat = [String : String]()
    public var localCountryCode: String? = "+44"
    
    public func initInternationalPhoneFormats()
    {
        if phoneNoFormat.count == 0
        {
            phoneNoFormat["0"] = "+44 #### ######" //local no (UK)
            phoneNoFormat["02"] = "+44 ## #### #####" //local no (UK) London
            
            phoneNoFormat["+1"] = "+# (###) ###-####" //US and Canada
            
            phoneNoFormat["+234"] = "+## # ### ####" //Nigeria
            phoneNoFormat["+2348"] = "+## ### ### ####" //Nigeria Mobile
            
            phoneNoFormat["+31"] = "+## ### ## ## ##" //Netherlands
            phoneNoFormat["+316"] = "+## # ## ## ## ##" //Netherlands Mobile
            phoneNoFormat["+33"] = "+## # ## ## ## ##" //France
            phoneNoFormat["+39"] = "+## ## ########" //Italy
            phoneNoFormat["+392"] = "+## #### #####" //Italy
            phoneNoFormat["+393"] = "+## ### #######" //Italy
            
            phoneNoFormat["+44"] = "+## #### ######" //United Kingdom
            phoneNoFormat["+442"] = "+## ## #### #####" //United Kingdom London
            
            phoneNoFormat["+51"] = "+## # ### ####" //Peru
            phoneNoFormat["+519"] = "+## ### ### ###" //Peru Mobile
            phoneNoFormat["+54"] = "+## ### ### ####" //Argentina
            phoneNoFormat["+541"] = "+## ## #### ####" //Argentina
            phoneNoFormat["+549"] = "+## # ### ### ####" //Argentina
            phoneNoFormat["+55"] = "+## (##) ####-####" //Brazil
            phoneNoFormat["+551"] = "+## (##) ####-###" //Brazil Mobile?
            
            phoneNoFormat["+60"] = "+## # #### ####" //Malaysia
            phoneNoFormat["+6012"] = "+## ## ### ####" //Malaysia Mobile
            phoneNoFormat["+607"] = "+## # ### ####" //Malaysia?
            phoneNoFormat["+61"] = "+## # #### ####" //Australia
            phoneNoFormat["+614"] = "+## ### ### ###" //Australia Mobile
            phoneNoFormat["+62"] = "+## ## #######" //Indonesia
            phoneNoFormat["+628"] = "+## ### ######" //Indonesia Mobile
            phoneNoFormat["+65"] = "+## #### ####" //Singapore
            
            phoneNoFormat["+90"] = "+## (###) ### ## ##" //Turkey
        }
    }
    
    public func getDiallingCode(phoneNo: String) -> String
    {
        var countryCode = phoneNo
        while countryCode.characters.count > 0 && phoneNoFormat[countryCode] == nil
        {
            countryCode = String(countryCode.characters.dropLast())
        }
        if countryCode == "0"
        {
            return localCountryCode!
        }
        return countryCode
    }
    
    
    public func formatInternationalPhoneNo(fullPhoneNo: String, localisePhoneNo: Bool = true) -> String
    {
        if fullPhoneNo == ""
        {
            return ""
        }
        initInternationalPhoneFormats()
        
        let diallingCode = getDiallingCode(phoneNo: fullPhoneNo)
        
        let localPhoneNo = fullPhoneNo.replacingOccurrences(of: diallingCode, with: "", options: .literal, range: nil)
        
        var filteredPhoneNo = (localPhoneNo.characters.filter{["0","1","2","3","4","5","6","7","8","9"].contains($0)})
        if filteredPhoneNo[0] == "0"
        {
            filteredPhoneNo.removeFirst()
        }
        
        let phoneNo:String = String (format:"%@%@",diallingCode, String(filteredPhoneNo))
        
        if let format = phoneNoFormat[diallingCode]
        {
            let formatLength = format.characters.count
            var formattedPhoneNo = [Character]()
            var formatPos = 0
            for char in phoneNo.characters
            {
                while formatPos < formatLength && format[formatPos] != "#" && format[formatPos] != "+"
                {
                    formattedPhoneNo.append(format[formatPos])
                    formatPos += 1
                }
                
                if formatPos < formatLength
                {
                    formattedPhoneNo.append(char)
                    formatPos += 1
                }
                else
                {
                    break
                }
            }
            if localisePhoneNo,
                let localCode = localCountryCode
            {
                return String(formattedPhoneNo).replacingOccurrences(of: String(format:"%@ ",localCode), with: "0", options: .literal, range: nil) //US users need to remove the extra 0
            }
            return String(formattedPhoneNo)
        }
        return String(filteredPhoneNo)
    }
}

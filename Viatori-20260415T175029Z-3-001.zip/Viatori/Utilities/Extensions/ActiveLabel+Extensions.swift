//
//  ActiveLabel+Extensions.swift
//  Viatori
//
//  Created by Serkut Yegin on 15.04.2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

extension ActiveLabel {
    
    func addFullText(fullText:VTFullTextObject?, closure:@escaping (VTBoldTextArray)->()) {
        
        self.highlightFontName = LabelTypeBoldName
        self.highlightFontSize = 14
        self.enabledTypes = []
        self.text = ""
        
        if let fullTextObject = fullText {
            if let fullText = fullTextObject.fullText {
                if let arrBoldTexts = fullTextObject.boldTextArray {
                    for boldText in arrBoldTexts {
                        if let text = boldText.text {
                            let customType = ActiveType.custom(pattern: text)
                            self.enabledTypes.append(customType)
                            self.customColor[customType] = self.textColor
                            self.handleCustomTap(for: customType, handler: { (element) in
                                closure(boldText)
                            })
                        }
                    }
                }
                self.text = fullText
            }
        }
    }
    
    func handleComment(comment:String?,mentionObject:[VTUserObject]?) {
        
        self.mentionObject = mentionObject
        self.handleMentionTap { [weak self] (mention) in
            self?.parentViewController?.openProfileVC(friendId:mention.userID)
        }
        self.handleHashtagTap { [weak self] (hashtag) in
            self?.parentViewController?.openHashtagVC(with: hashtag)
        }
        self.handleURLTap { (url) in
            url.open()
        }
        self.text = comment
    }
    
    func customizeForPostAndComment() {
        self.font = UIFont.init(name: LabelTypeRegularName, size: 14.0)
        self.hashtagColor = VTThemeManager.sharedManager.family.colorHashtag
        self.mentionColor = VTThemeManager.sharedManager.family.colorMention
        self.URLColor = VTThemeManager.sharedManager.family.colorUrl
        self.highlightFontName = LabelTypeBoldName
        self.highlightFontSize = 14
    }
    
}

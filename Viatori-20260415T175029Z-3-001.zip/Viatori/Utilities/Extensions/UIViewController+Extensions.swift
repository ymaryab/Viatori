//
//  UIViewController+Extensions.swift
//  Viatori
//
//  Created by Serkut Yegin on 22/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

public enum Storyboards {
    
    public enum StoryboardName : String {
        case main = "Main"
        case beforeLogin = "BeforeLogin"
        case socialMedia = "SocialMedia"
        case socialMediaOther = "SocialMediaOther"
        case order = "Order"
        case messages = "Messages"
    }
    
    public enum NavControllerIdentifier : String {
        case walkthroughNav = "walkthroughNavCon"
        case signupNav = "signupNavCon"
        case loginNav = "loginNavCon"
        case feedNav = "feedNavCon"
        case trendingNav = "trendingNavCon"
        case activityNav = "activityNavCon"
        case profileNav = "profileNavCon"
        case messageNav = "messageNavCon"
        case updateStatusNav = "updateStatusNavCon"
    }
    
    public enum ViewControllerIdentifier : String {
        
        case sharePopover = "sharePopoverVC"
        case ratePopover = "ratePopoverVC"
        case invitePopover = "invitePopoverVC"
        
        case tabbarSocial = "socialMediaTabCon"
        case tabbarOrder = "orderTabCon"
        case vtSlidingMenu = "vtSlidingMenuController"
        case vtSubSlidingMenu = "vtSubSlidingMenuController"
        case splash = "splashVC"
        
        //Walkthrough
        case walkthrough = "walkthroughVC"
        case walkthroughSignup = "walkthroughSignupVC"
        case walkthroughLogin = "walkthroughLoginVC"
        case signupWithEmail = "signupWithEmailVC"
        case signupDefinePassword = "signupDefinePasswordVC"
        case signupFullName = "signupFullnameVC"
        case signupUsername = "signupUsernameVC"
        case signupOptionalInfo = "signupOptionalInfoVC"
        case signupSuggestedPeople = "signupSuggestedPeopleVC"
        case signupEnterPincode = "signupEnterPincodeVC"
        case loginWithEmail = "loginWithEmailVC"
        case loginForgotPassword = "loginForgotPasswordVC"
        
        //Social Media
        case feed = "feedVC"
        case trending = "trendingVC"
        case activity = "activityVC"
        case profile = "profileVC"
        
        //Social Media Other
        case updateStatus = "updateStatusVC"
        case postDetail = "postDetailVC"
        case tagFriend = "tagFriendVC"
        case fenomens = "fenomensVC"
        case search = "searchVC"
        case hashtag = "hashtagVC"
        case venueDetail = "venueDetailVC"
        case settings = "settingsVC"
        case editProfile = "editProfileVC"
        case changePassword = "changePasswordVC"
        case searchOnMaps = "searchOnMapsVC"
        case addNewPlace = "addNewPlaceVC"
        case peopleList = "peopleListVC"
        case friendRequests = "friendRequestsVC"
        case viaToriPoint = "viaToriPointVC"
        case category = "categoryVC"
        case checkin = "checkinVC"
        case reportList = "reportListVC"
        case reportDetail = "reportDetailVC"
        case accountSettings = "accountSettingsVC"
        case notificationSettings = "notificationSettingsVC"
        case blockedUsers = "blockedUsersVC"
        case discover = "discoverVC"
        case freezeOrDelete = "freezeOrDeleteVC"
        case viatoriPointEarned = "viaPoint"
        
        // ORDER 
        case venueBeforeQR = "venueBeforeQR"
        case venueAfterQR = "venueAfterQR"
        case gpsGif = "gpsGif"
        case orderSettings = "orderSettings"
        case menuSubcategoryVC = "menuSubcategoryVC"
        
        //Message
        case messages = "messagesVC"
        case newMessage = "newMessageVC"
        case messageFriendList = "messageFriendListVC"
    }
}

extension UIViewController : UIPopoverPresentationControllerDelegate {
    
    open class func controller(for storyboardName:Storyboards.StoryboardName, controllerIdentifier:Storyboards.ViewControllerIdentifier) -> UIViewController? {
        let storyboard : UIStoryboard? = UIStoryboard.init(name: storyboardName.rawValue, bundle: nil)
        if let storyboard = storyboard {
            return storyboard.instantiateViewController(withIdentifier: controllerIdentifier.rawValue)
        }
        return nil
    }
    
    public func addControlller(toParent controller:UIViewController,toView:UIView) {
        controller.addChildViewController(self)
        toView.addSubview(self.view)
        self.view.autoPinEdgesToSuperviewEdges()
        self.didMove(toParentViewController: controller)
    }
    
    public func removeControllerFromParent() {
        self.willMove(toParentViewController: nil)
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    public func presentPopover(popover:UIViewController, from view:UIView, preferredContentSize:CGSize? = nil, direction:UIPopoverArrowDirection = .any) {
        popover.modalPresentationStyle = .popover
        if preferredContentSize != nil {
            popover.preferredContentSize = preferredContentSize!
        }
        let controller = popover.popoverPresentationController
        controller?.backgroundColor = UIColor.white
        controller?.delegate = self
        controller?.sourceView = view
        controller?.sourceRect = CGRect(x: view.w/2, y: 1, w: 1, h: view.h)
        controller?.permittedArrowDirections = direction
        self.present(popover, animated: true, completion: nil)
    }
    
    public func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
}

extension UINavigationController {
    
    open class func controller(for storyboardName:Storyboards.StoryboardName, controllerIdentifier:Storyboards.NavControllerIdentifier) -> UINavigationController? {
        let storyboard : UIStoryboard? = UIStoryboard.init(name: storyboardName.rawValue, bundle: nil)
        if let storyboard = storyboard {
            let vc : UIViewController? = storyboard.instantiateViewController(withIdentifier: controllerIdentifier.rawValue)
            
            if let viewController = vc {
                if viewController.isKind(of: UINavigationController.classForCoder()) {
                    return (viewController as! UINavigationController)
                }
            }
            return nil
        }
        return nil
    }
    
    func goLeft(by index:Int) {
        if self.viewControllers.count > index {
            self.setViewControllers(Array(self.viewControllers[0..<self.viewControllers.count - index]), animated: true)
        }
    }
}

extension UIViewController {
    
    //MARK: Common Controllers
    
    func openProfileVC(friendId:String?=nil) {
        guard let friendId = friendId else {return}
        if self.checkUserIfMe(friendId: friendId) {
            UIView.animate(withDuration: 0.1, animations: {
                self.navigationController?.view.x = 20
            }, completion: { (finished) in
                if finished {
                    UIView.animate(withDuration: 0.1, animations: {
                        self.navigationController?.view.x = 0
                    })
                }
            })
        } else if self.checkIfInTabbar() && friendId.checkUserIfMe() {
            VTSingleton.shared.tabbarSocialMedia?.selectedIndex = 3
        } else {
            if let index = self.findUserProfileInStack(friendId: friendId) {
                let slice : ArraySlice<UIViewController> = self.navigationController!.viewControllers[0..<index+1]
                let splitted : [UIViewController] = Array(slice)
                self.navigationController?.setViewControllers(splitted, animated: true)
            } else {
                let profileVC = UIViewController.controller(for: .socialMedia, controllerIdentifier: .profile) as! ProfileViewController
                profileVC.friendId = friendId
                self.navigationController?.pushViewController(profileVC, animated: true)
            }
        }
    }
    
    func findUserProfileInStack(friendId:String) -> Int? {
        guard let navCon = self.navigationController else {return nil}
        for index in 0..<navCon.viewControllers.count {
            if navCon.viewControllers[index].checkUserIfMe(friendId:friendId) && index != navCon.viewControllers.count - 1 {
                return index
            }
        }
        return nil
    }
    
    func checkUserIfMe(friendId:String) -> Bool {
        if self.isKind(of: ProfileViewController.classForCoder()) && (self as! ProfileViewController).userDetailObject?.userID != nil && (self as! ProfileViewController).userDetailObject?.userID == friendId {
            return true
        }
        return false
    }
    
    func openHashtagVC(with hashtag:String?) {
        let hashtagVC = UIViewController.controller(for: .socialMediaOther, controllerIdentifier: .hashtag) as! HashtagViewController
        hashtagVC.hashtag = hashtag
        self.navigationController?.pushViewController(hashtagVC, animated: true)
    }
    
    func openVenueDetailVC(poiId:Int? = nil) {
        guard let venueDetail = VenueDetailViewController.venueDetail(with: poiId) else {return}
        self.navigationController?.pushViewController(venueDetail, animated: true)
    }
    
    func openSearchOnMapsVC(onlyBranches:Bool = false) {
        let searchVC = UIViewController.controller(for: .socialMediaOther, controllerIdentifier: .searchOnMaps) as! SearchOnMapsViewController
        searchVC.showOnlyBranches = onlyBranches
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    @discardableResult
    func openAddNewPlaceVC(placeName:String?) -> AddNewPlaceViewController {
        let addNewPlaceVC = UIViewController.controller(for: .socialMediaOther, controllerIdentifier: .addNewPlace) as! AddNewPlaceViewController
        addNewPlaceVC.placeName = placeName
        self.navigationController?.pushViewController(addNewPlaceVC, animated: true)
        return addNewPlaceVC
    }
    
    func openPeopleListVC(type:PeopleListType) {
        let peopleListVC = UIViewController.controller(for: .socialMediaOther, controllerIdentifier: .peopleList) as! PeopleListViewController
        peopleListVC.setup(with: type)
        self.navigationController?.pushViewController(peopleListVC, animated: true)
    }
    
    func openReportVC(type:ReportType,successCompletion:((_ alsoBlocked:Bool)->())? = nil) {
        let reportListVC = UIViewController.controller(for: .socialMediaOther, controllerIdentifier: .reportList) as! ReportListViewController
        reportListVC.reportType = type
        reportListVC.successCompletion = successCompletion
        self.navigationController?.pushViewController(reportListVC, animated: true)
    }
    
    func openPostDetailVC(feedId:String,needUpdate:Bool = false) {
        let postDetail = PostDetailViewController.create(with: feedId.actualId, needUpdate: needUpdate)
        self.navigationController?.pushViewController(postDetail, animated: true)
    }
    
    var extractGallery : UIViewController? {
        if self.navigationController is MHGalleryController {
            self.dismiss(animated: false, completion: nil)
            MHStatusBar().alpha = 1
            return (self.navigationController as! MHGalleryController).fromVC
        } else {
            return self
        }
    }
    
    var isPostDetail : Bool {
        if self.navigationController is MHGalleryController {
            return (self.navigationController as! MHGalleryController).fromVC is PostDetailViewController
        } else {
            return self is PostDetailViewController
        }
    }
}


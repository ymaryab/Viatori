//
//  UIScrollView+Extensions.swift
//  Viatori
//
//  Created by Nermin Sarifakioglu on 10/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//


import UIKit

extension UIScrollView {

    func isEndOfScroll(distanceToEnd:CGFloat) -> Bool {
        let scrolledY : CGFloat = contentOffset.y + bounds.size.height - contentInset.bottom;
        let totalHeight = contentSize.height;
        
        if( scrolledY > totalHeight - distanceToEnd) {
            return true
        } else {
            return false
        }
    }

}

//
//  UIView+Extensions.swift
//  Viatori
//
//  Created by Serkut Yegin on 15/12/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

extension UIView {
    
    open class func create() -> UIView {
        return UIView.create(with: self.className)
    }
    
    open class func create(with nibName:String) -> UIView {
        return Bundle.main.loadNibNamed(nibName, owner: nil, options: nil)?.first as! UIView
    }
    
    public func roundCorners() {
        self.layer.cornerRadius = self.frame.size.height/2;
        self.clipsToBounds = true;
    }
    
    public func roundCornersFixed(value:CGFloat = 5) {
        self.layer.cornerRadius = value
        self.clipsToBounds = true
    }
    
    public func updateSubviewConstraints(for size:CGSize) {
        for view in self.subviews {
            if view.isKind(of: VTBasePageView.classForCoder()) {
                (view as! VTBasePageView).updateConstraints(for: size)
            }
        }
    }
    
    public func showAnimated(duration:TimeInterval = 0.2) {
        self.alpha = 0
        self.isHidden = false
        UIView.animate(withDuration: duration) { [unowned self] in
            self.alpha = 1
        }
    }
    
    public func hideAnimated(duration:TimeInterval = 0.2, completion:(()->())? = nil) {
        self.alpha = 1
        UIView.animate(withDuration: duration, animations: { [unowned self] in
            self.alpha = 0
        }) { [unowned self] (finished) in
            if finished {
                self.isHidden = true
                completion?()
            }
        }
    }
    
    public func removeAnimated(duration:TimeInterval = 0.2) {
        self.alpha = 1
        UIView.animate(withDuration: duration, animations: { [unowned self] in
            self.alpha = 0
        }) { [unowned self] (finished) in
            if finished {
                self.removeFromSuperview()
            }
        }
    }
}


extension UIView {
    
    public func removeAllGestures() {
        if gestureRecognizers != nil {
            for item in gestureRecognizers! {
                removeGestureRecognizer(item)
            }
        }
    }
    
    var parentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder!.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
}


extension VTBasePageView {
    
    public func addViewForPaging(contentView:UIView,scrollView:UIScrollView,index:Int) {
        contentView.addSubview(self)
        self.pageIndex = index
        self.autoPinEdge(toSuperviewEdge:.top)
        self.autoPinEdge(toSuperviewEdge:.bottom)
        self.constraintWidht = self.autoSetDimension(.width, toSize: scrollView.frame.size.width)
        self.constraintLeading = self.autoPinEdge(.leading, to: .leading, of: contentView, withOffset: CGFloat(index) * (scrollView.frame.size.width))
    }
    
    public func updateConstraints(for size:CGSize) {
        if self.constraintWidht != nil && self.constraintLeading != nil {
            self.constraintWidht!.constant = size.width
            self.constraintLeading!.constant = size.width * CGFloat(self.pageIndex)
        }
    }
}

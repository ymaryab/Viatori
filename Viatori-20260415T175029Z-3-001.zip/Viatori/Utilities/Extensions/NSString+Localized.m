//
//  NSString+Localized.m
//  Viatori
//
//  Created by ProAegean on 06/05/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

#import "NSString+Localized.h"
#import "Viatori-Swift.h"

@implementation NSString (Localized)

-(NSString *)localized {
    return [[VTLanguageManager sharedManager] getLocalizedStringWithKey:self];
}

@end

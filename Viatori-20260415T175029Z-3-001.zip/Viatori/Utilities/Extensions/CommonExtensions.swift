//
//  CommonExtensions.swift
//  Viatori
//
//  Created by Serkut Yegin on 21/12/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

extension NSLayoutConstraint {
    /**
     Change multiplier constraint
     
     - parameter multiplier: CGFloat
     - returns: NSLayoutConstraint
     */
    func setMultiplier(multiplier:CGFloat) -> NSLayoutConstraint {
        
        let newConstraint = NSLayoutConstraint(
            item: firstItem,
            attribute: firstAttribute,
            relatedBy: relation,
            toItem: secondItem,
            attribute: secondAttribute,
            multiplier: multiplier,
            constant: constant)
        
        newConstraint.priority = priority
        newConstraint.shouldBeArchived = self.shouldBeArchived
        newConstraint.identifier = self.identifier
        newConstraint.isActive = true
        
        NSLayoutConstraint.deactivate([self])
        NSLayoutConstraint.activate([newConstraint])
        return newConstraint
    }
}

extension Bundle {
    var releaseVersionNumber: String? {
        return infoDictionary?["CFBundleShortVersionString"] as? String
    }
    var buildVersionNumber: String? {
        return infoDictionary?["CFBundleVersion"] as? String
    }
}

extension URL {
    func open() {
        if UIApplication.shared.canOpenURL(self) {
            self.openURL()
        } else {
            let urlStr = self.absoluteString.addHttpIfNeeded()
            URL.init(string: urlStr)?.openURL()
        }
    }
    
    private func openURL() {
        
        if #available(iOS 10, *) {
            UIApplication.shared.open(self, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(self)
        }
    }
}

extension Locale {
    
    static func vtCurrentLocale() -> Locale {
        let languageCode = VTLanguageManager.sharedManager.currentLanguage
        if !languageCode.isEmpty {
            return Locale.init(identifier: languageCode)
        } else {
            return Locale.current
        }
    }
}

extension Bool {
    
    public var toString: String { return self ? "true" : "false" }
}

extension UISearchBar {
    
    func changeInsideBackgroundColor(color:UIColor) {
        
        for subview in self.subviews {
            for innerSubview in subview.subviews {
                if innerSubview is UITextField {
                    innerSubview.backgroundColor = color
                }
            }
        }
    }
}

extension UIImageView : UIGestureRecognizerDelegate {
    
    func setUserImage(user:VTUserObject?, directToUser:Bool=true) {
        self.image = #imageLiteral(resourceName: "profilepicS")
        self.removeAllGestures()
        if let userId = user?.userID {
            if directToUser {
                self.addProfileGesture(userId: userId)
            }
            if let userImage = user?.userImage, !userImage.isEmpty {
                self.sd_setImage(with: URL(string: userImage), completed: { [weak self] (image, error, cacheType, url) in
                    if error != nil {
                        self?.image = #imageLiteral(resourceName: "profilepicS")
                    }
                })
            }
        }
    }
    
    func addProfileGesture(userId : String?) {
        guard let userId = userId, userId.length > 0 else {return}
        self.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer.init(target: self, action: #selector(gestureViewProfileRecognized(_:)))
        gesture.accessibilityLabel = userId
        gesture.cancelsTouchesInView = true
        gesture.delegate = self
        self.addGestureRecognizer(gesture)
    }
    
    func gestureViewProfileRecognized(_ sender : UITapGestureRecognizer) {
        if let userId = sender.accessibilityLabel {
            self.parentViewController?.extractGallery?.openProfileVC(friendId: userId)
        }
    }
    
    public func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return false
    }
}

extension UIButton {
    
    func setTitleWithoutAnimation(title:String) {
        UIView.performWithoutAnimation {
            self.setTitle(title, for: .normal)
            self.setTitle(title, for: .highlighted)
            self.setTitle(title, for: .disabled)
            self.setTitle(title, for: .focused)
            self.setTitle(title, for: .selected)
            self.layoutIfNeeded()
        }
    }
    
    func setTitleColorWithoutAnimation(color:UIColor) {
        UIView.performWithoutAnimation {
            self.setTitleColor(color, for: .normal)
            self.setTitleColor(color, for: .highlighted)
            self.setTitleColor(color, for: .disabled)
            self.setTitleColor(color, for: .focused)
            self.setTitleColor(color, for: .selected)
            self.layoutIfNeeded()
        }
    }
}

protocol _StringType {}
extension String: _StringType {}
extension Array where Element : _StringType {
    
    func findIndexOfFeed(feed:VTFeedObject?) -> Int? {
        guard let feedId = feed?.feedID else {return nil}
        for index in 0..<self.count {
            if (self[index] as! String) == feedId {
                return index
            }
        }
        return nil
    }
}

extension UILabel {
    
    func setLineHeight(lineHeight: CGFloat) {
        if let text = self.text {
            let attributeString = NSMutableAttributedString(string: text)
            let style = NSMutableParagraphStyle()
            style.lineSpacing = lineHeight
            attributeString.addAttribute(NSParagraphStyleAttributeName,
                                         value: style,
                                         range: NSMakeRange(0, text.characters.count))
            self.attributedText = attributeString
        }
    }
}

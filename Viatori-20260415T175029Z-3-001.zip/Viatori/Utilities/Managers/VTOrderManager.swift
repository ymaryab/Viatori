//
//  VTOrderManager.swift
//  Viatori
//
//  Created by Nermin Sarifakioglu on 15/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit


class VTOrderManager: NSObject {
    
    var tableOperationId : Int?

    var branchId : Int?
    var currency : VT_Currency?
    
    private var _tableStatus : OrderTabBarItem = .venue
    public var tableStatus : OrderTabBarItem {
        set (newStatus){
            _tableStatus = newStatus
        }
        get {
            return _tableStatus
        }
    }
    
    static let sharedInstance : VTOrderManager = {
        let instance = VTOrderManager()
        return instance
    }()
    
    override init() {
        super.init()

    }
    
    func setup() {
        //VTSingleton.shared.user = VTUserDetailObject()
        //VTSingleton.shared.user?.userID = "5"
        //VTSingleton.shared.user?.token = VTSingleton.shared.user?.userID
        //VTSingleton.shared.user?.userviaPuan = "60"
        //VTSingleton.shared.user?.usertoriPuan = "800"
    }
    
    func openTable (data:VTOpenTableResponse) {
        tableOperationId = data.tableOperationId
        if let status = data.tableStatus {
            showBadgeAndPopupIfNeeded(newTableStatus: status, popupItem:.menu)
        }
        self.branchId = data.branchId
        self.currency = data.branchCurrencyType
    }
    
    func productAddedToCart(totalCount:Int, totalPrice:Float) {
        
      if let tabbarController = VTSingleton.shared.tabbarOrder {
        
        if ( tableStatus.rawValue < OrderTabBarItem.cart.rawValue ) {
            self.tableStatus = .cart
            tabbarController.orderTabbar.setEnableTabItem(toIndex: .cart , animated: true)
        }
        
        let strProductCount = String ( format:"TXT_ORDER_MENU_CART_POPUP".localized(), totalCount)
        let strPopup = String(format:"%@, %@", strProductCount, OrderHelper.getPriceText(price: totalPrice))
        tabbarController.showInfoPopup (toItem: .cart , withText: strPopup )
        tabbarController.showBadge (toItem: .cart )
      }
    }
    
    func cartSubmitted() {

        showBadgeAndPopupIfNeeded(newTableStatus: .checkout, popupItem:.checkout)
        
    }

    func showBadgeAndPopupIfNeeded(newTableStatus:OrderTabBarItem, popupItem:OrderTabBarItem) {
        
        if tableStatus != newTableStatus  && newTableStatus.rawValue > tableStatus.rawValue {
            if let tabbarController = VTSingleton.shared.tabbarOrder {
                tabbarController.orderTabbar.setEnableTabItem(toIndex: newTableStatus , animated: true)
                for item in tableStatus.rawValue...newTableStatus.rawValue {
                    tabbarController.showBadge (toItem: OrderTabBarItem(rawValue:item)!)
                }
            }
        }
        showPopup(toItem: popupItem)
        tableStatus = newTableStatus
    }

    func showPopup(toItem:OrderTabBarItem) {
        if let tabbarController = VTSingleton.shared.tabbarOrder {
            let strPopup = toItem.description
            tabbarController.showInfoPopup (toItem: toItem, withText: strPopup )
            tabbarController.showBadge (toItem: toItem)
        }
    }
    
    public func quitTable() {
        if let vc = UIViewController.controller(for: Storyboards.StoryboardName.order, controllerIdentifier: Storyboards.ViewControllerIdentifier.venueBeforeQR),
            let tabbarController = VTSingleton.shared.tabbarOrder {
            
            if let navCon = tabbarController.viewControllers?[0] as? UINavigationController {
                    navCon.setViewControllers([vc], animated: false)
                }
            tabbarController.orderTabbar.select(item:.venue)
            tabbarController.orderTabbar.setEnableTabItem(toIndex: .venue , animated: true)

            self.tableStatus = .venue
            self.tableOperationId = nil

            tabbarController.setNeedsUpdateForAllChilds()

        }
    }
    
    
    public func tableStatusRefreshedFromServer(newStatus:OrderTabBarItem? ) {
        
        if let newStatus = newStatus {
            if newStatus != tableStatus  {
                if let tabbarController = VTSingleton.shared.tabbarOrder {
                    if (newStatus.rawValue > tableStatus.rawValue) {
                        // if new status is bigger, show popup but do not change selected tab
                        showPopup(toItem: newStatus)
                    } else {
                        // if new status is smaller do not show popup but change the selected tab because selected tab is disabled now
                        tabbarController.orderTabbar.select(item: newStatus)
                    }
                    tabbarController.orderTabbar.setEnableTabItem(toIndex: newStatus , animated: true)
                }
            }
            tableStatus = newStatus
        }
    }

    func openNotificationForCart() {
        
        if (tableStatus.rawValue >= OrderTabBarItem.cart.rawValue ){
        
        if let state = VTSingleton.shared.rootViewController.vtSlidingMenu()?.menuState {
            if state == MenuState.Left  {
                VTSingleton.shared.rootViewController.vtSlidingMenu()?.menuState = MenuState.Right
            }
        }
        
        
        if let currentIndex = VTSingleton.shared.tabbarOrder?.selectedIndex {
            if let navcon = VTSingleton.shared.tabbarOrder?.viewControllers?[currentIndex] as? UINavigationController
            {
                navcon.popToRootViewController(animated: true)
            }
        }
        VTSingleton.shared.tabbarOrder?.selectedIndex = 2
        }
        
    }

    func openNotificationForCheckout() {
        
        if (tableStatus.rawValue >= OrderTabBarItem.checkout.rawValue ){
                    
        if let state = VTSingleton.shared.rootViewController.vtSlidingMenu()?.menuState {
            if state == MenuState.Left  {
                VTSingleton.shared.rootViewController.vtSlidingMenu()?.menuState = MenuState.Right
            }
        }
        
        
        if let currentIndex = VTSingleton.shared.tabbarOrder?.selectedIndex {
            if let navcon = VTSingleton.shared.tabbarOrder?.viewControllers?[currentIndex] as? UINavigationController
            {
                navcon.popToRootViewController(animated: true)
            }
        }
        VTSingleton.shared.tabbarOrder?.selectedIndex = 3
        }
        
    }
    
    /*func loadData() {
        tableOperationId = UserDefaults.standard.value(forKey: "order.tableOperationId") as? Int
        tableStatus = UserDefaults.standard.value(forKey: "order.tableStatus") as? Int
        if let cur = UserDefaults.standard.value(forKey: "order.currency") as? Int {
            currency = VT_Currency(rawValue: cur)
        }
    }
    
    func saveData() {
        UserDefaults.standard.setValue(tableOperationId, forKey: "order.tableOperationId")
        UserDefaults.standard.setValue(tableStatus, forKey: "order.tableStatus")
        UserDefaults.standard.setValue(currency?.rawValue, forKey: "order.currency")
    }*/
}

//
//  VTAlertManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 26/12/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import EZAlertController

class VTAlertManager {

    static let sharedManager = VTAlertManager()
    
    @discardableResult
    public func show(_ title: String, message: String, buttons:[String], tapBlock:((UIAlertAction,Int) -> Void)?) -> UIAlertController {
        return EZAlertController.alert(title, message: message, buttons: buttons, tapBlock: tapBlock)
    }
    
}

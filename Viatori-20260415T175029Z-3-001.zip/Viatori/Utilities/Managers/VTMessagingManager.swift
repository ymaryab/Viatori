//
//  VTMessagingManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 17/01/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class VTMessagingManager {

    static let sharedManager = VTMessagingManager()
    
    private var _numberOfNewMessages : Int = 0
    var numberOfNewMessages : Int {
        return _numberOfNewMessages
    }
    
}

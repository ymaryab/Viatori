//
//  VTAmazonManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 09/01/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import AWSS3


public enum UpdateImageType {
    case profileImage, coverPhoto
}

class VTAmazonManager {

    static let sharedManager = VTAmazonManager()
    
    func checkProfilePictureUploadNeeded() {
        
        let uncompletedUpload = UserDefaults.standard.bool(forKey: VTConstants.UserPreference.profileImageUploadStarted)
        
        if uncompletedUpload {
            let fileUrl = UserDefaults.standard.url(forKey: VTConstants.UserPreference.profileImageFileUrl)
            let fileName = UserDefaults.standard.string(forKey: VTConstants.UserPreference.profileImageFileName)
            if let fileUrl = fileUrl, let fileName = fileName {
                self.handleProfilePictureUpload(fileUrl: fileUrl, fileName: fileName)
            }
        }
    }
    
    func uploadProfilePictureToAmazon(image:UIImage?,userId:String) {
        
        if let image = image {
            let fileName = ProcessInfo.processInfo.globallyUniqueString.appending(".png")
            let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(fileName)
            if let imageData = UIImagePNGRepresentation(image) {
                do {
                    try imageData.write(to: fileURL, options: .atomic)
                    self.handleProfilePictureUpload(fileUrl: fileURL, fileName: VTConstants.Strings.amazonProfilImageUrl(userId: userId))
                } catch let error as NSError {
                    debugPrint(error)
                }
            }
        }
    }
    
    func handleProfilePictureUpload(fileUrl:URL, fileName:String) {
        
        UserDefaults.standard.set(fileUrl, forKey: VTConstants.UserPreference.profileImageFileUrl)
        UserDefaults.standard.set(fileName, forKey: VTConstants.UserPreference.profileImageFileName)
        
        let uploadRequest = AWSS3TransferManagerUploadRequest()
        uploadRequest?.body = fileUrl
        uploadRequest?.key = fileName
        uploadRequest?.bucket = VTConstants.Strings.S3BucketName
        self.uploadProfilePicture(uploadRequest: uploadRequest!)
    }
    
    func uploadProfilePicture(uploadRequest: AWSS3TransferManagerUploadRequest) {
        
        let transferManager = AWSS3TransferManager.default()
        
        uploadRequest.uploadProgress = { (bytesSent:Int64, totalBytesSent:Int64, totalBytesExpectedToSend:Int64) in
            
            DispatchQueue.main.sync(execute: { () -> Void in
                
            })
        }
        
        UserDefaults.standard.set(true, forKey: VTConstants.UserPreference.profileImageUploadStarted)
        transferManager.upload(uploadRequest).continueWith { (task) -> Any? in
            if let error = task.error as NSError? {
                print("upload() failed: [\(error)]")
            }
            
            /*if let exception = task.exception {
                print("upload() failed: [\(exception)]")
            }*/
            
            if task.result != nil {
                UserDefaults.standard.set(false, forKey: VTConstants.UserPreference.profileImageUploadStarted)
                let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(VTConstants.UserPreference.profileImageFileUrl)
                try? FileManager.default.removeItem(at: fileURL)
                DispatchQueue.main.async(execute: { () -> Void in
                    /*if let index = self.indexOfUploadRequest(self.uploadRequests, uploadRequest: uploadRequest) {
                     self.uploadRequests[index] = nil
                     self.uploadFileURLs[index] = uploadRequest.body
                     
                     let indexPath = NSIndexPath(forRow: index, inSection: 0)
                     self.collectionView.reloadItemsAtIndexPaths([indexPath])
                     }*/
                })
            }
            return nil
        }
    }
}

extension VTAmazonManager {
    
    func updateProfileImages(imageType:UpdateImageType,image:UIImage?,progress:CircleProgressBar?, completion:((_ success:Bool, _ imageUrl:String?)->())?) {
        guard let image = image, let userId = VTSingleton.shared.userId else {return}
        let fileName = ProcessInfo.processInfo.globallyUniqueString
        let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(fileName.appending(".png"))
        if let imageData = UIImagePNGRepresentation(image) {
            do {
                try imageData.write(to: fileURL, options: .atomic)
                let uploadRequest = AWSS3TransferManagerUploadRequest()
                uploadRequest?.body = fileURL
                switch imageType {
                case .coverPhoto:  uploadRequest?.key = VTConstants.Strings.amazonCoverPhotoUrl(userId: userId, fileName: fileName); break
                case .profileImage: uploadRequest?.key = VTConstants.Strings.amazonProfileImageUrl(userId: userId, fileName: fileName); break
                }
                uploadRequest?.bucket = VTConstants.Strings.S3BucketName
                
                let transferManager = AWSS3TransferManager.default()
                
                DispatchQueue.main.async(execute: { () -> Void in
                    progress?.showAnimated()
                    progress?.progressBarTrackColor = UIColor.clear
                    progress?.progressBarProgressColor = UIColor.vtBlueColor
                    progress?.setProgress(0, animated: false)
                })
                uploadRequest!.uploadProgress = { (bytesSent:Int64, totalBytesSent:Int64, totalBytesExpectedToSend:Int64) in
                    DispatchQueue.main.sync(execute: { () -> Void in
                        progress?.setProgress(CGFloat(Double(totalBytesSent)/Double(totalBytesExpectedToSend)), animated: true)
                    })
                }
                transferManager.upload(uploadRequest!).continueWith { (task) -> Any? in
                    if let error = task.error as NSError? {
                        var errorCode = AWSS3TransferManagerErrorType.unknown
                        if error.domain == AWSS3TransferManagerErrorDomain as String {
                            errorCode = AWSS3TransferManagerErrorType(rawValue: error.code)!
                        }
                        if errorCode != AWSS3TransferManagerErrorType.cancelled {
                            
                            DispatchQueue.main.async(execute: { () -> Void in
                                completion?(false,nil)
                                progress?.showAnimated()
                                progress?.progressBarTrackColor = UIColor.vtRedColor
                                progress?.progressBarProgressColor = UIColor.vtRedColor
                                Timer.runThisAfterDelay(seconds: 1.5, after: { [weak progress] in
                                    progress?.hideAnimated(duration: 0.2, completion: { [weak progress] in
                                        progress?.setProgress(0, animated: false)
                                    })
                                })
                            })
                        }
                        print("upload() failed: [\(error)]")
                    }
                    if task.result != nil {
                        
                        try? FileManager.default.removeItem(at: fileURL)
                        DispatchQueue.main.async(execute: { () -> Void in
                            switch imageType {
                            case .coverPhoto:  completion?(true,VTConstants.Strings.amazonCoverFullUrl(fileName: fileName)); break
                            case .profileImage: completion?(true,VTConstants.Strings.amazonProfileImageFullUrl(fileName: fileName)); break
                            }
                            progress?.showAnimated()
                            progress?.progressBarTrackColor = UIColor.vtGreenColor
                            progress?.progressBarProgressColor = UIColor.vtGreenColor
                            Timer.runThisAfterDelay(seconds: 1.5, after: { [weak progress] in
                                progress?.hideAnimated(duration: 0.2, completion: { [weak progress] in
                                    progress?.setProgress(0, animated: false)
                                })
                            })
                        })
                    }
                    return nil
                }
                
            } catch _ {
                completion?(false,nil)
            }
        } else {
            completion?(false,nil)
        }
    }
}

extension VTAmazonManager {
    
    //MARK: Media Upload
    func uploadMediaPhoto(photoName:String?,userId:String?,thumbnail:Bool = false) -> AWSS3TransferManagerUploadRequest? {
        
        if let userId = userId, let photoName = photoName {
            
            let fileName = photoName.appending(".png")
            let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(fileName)
            let uploadPath = VTConstants.Strings.amazonMediaImageUrl(userId: userId, fileName: photoName)
            let uploadRequest = AWSS3TransferManagerUploadRequest()
            uploadRequest?.body = fileURL
            uploadRequest?.key = uploadPath
            uploadRequest?.bucket = VTConstants.Strings.S3BucketName
            
            let transferManager = AWSS3TransferManager.default()
            
            DispatchQueue.main.async(execute: { () -> Void in
                VTSingleton.shared.tabbarSocialMedia?.feedVC.progressView.setProgress(0, animated: false)
            })
            uploadRequest!.uploadProgress = { (bytesSent:Int64, totalBytesSent:Int64, totalBytesExpectedToSend:Int64) in
                DispatchQueue.main.sync(execute: { () -> Void in
                    VTSingleton.shared.tabbarSocialMedia?.feedVC.progressView.setProgress(Float(Double(totalBytesSent)/Double(totalBytesExpectedToSend)), animated: true)
                })
            }
            
            transferManager.upload(uploadRequest!).continueWith { (task) -> Any? in
                if let error = task.error as NSError? {
                    var errorCode = AWSS3TransferManagerErrorType.unknown
                    if error.domain == AWSS3TransferManagerErrorDomain as String {
                        errorCode = AWSS3TransferManagerErrorType(rawValue: error.code)!
                    }
                    if errorCode != AWSS3TransferManagerErrorType.cancelled {
                        VTUpdateStatusManager.manager.photoUploadFinished(success: false, thumbnail: thumbnail)
                    }
                    
                    print("upload() failed: [\(error)]")
                }
                if task.result != nil {
                    VTUpdateStatusManager.manager.photoUploadFinished(success: true, thumbnail: thumbnail)
                    try? FileManager.default.removeItem(at: fileURL)
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                    })
                }
                return nil
            }
            return uploadRequest
        } else {
            VTUpdateStatusManager.manager.photoUploadFinished(success: false, thumbnail: thumbnail)
            return nil
        }
    }
    
    //MARK: Message Media Upload
    func uploadMessageMediaPhoto(photoName:String?,userId:String?,roomId:String?,thumbnail:Bool = false) -> AWSS3TransferManagerUploadRequest? {
        
        if let userId = userId, let photoName = photoName {
            
            let fileName = photoName.appending(".png")
            let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(fileName)
            let uploadPath = VTConstants.Strings.amazonMessageMediaImageUrl(userId: userId, fileName: photoName, roomId: roomId!)
            let uploadRequest = AWSS3TransferManagerUploadRequest()
            uploadRequest?.body = fileURL
            uploadRequest?.key = uploadPath
            uploadRequest?.bucket = VTConstants.Strings.S3BucketName
            
            let transferManager = AWSS3TransferManager.default()
            
            transferManager.upload(uploadRequest!).continueWith { (task) -> Any? in
                if let error = task.error as NSError? {
                    var errorCode = AWSS3TransferManagerErrorType.unknown
                    if error.domain == AWSS3TransferManagerErrorDomain as String {
                        errorCode = AWSS3TransferManagerErrorType(rawValue: error.code)!
                    }
                    if errorCode != AWSS3TransferManagerErrorType.cancelled {
                        VTUpdateStatusManager.manager.photoUploadFinished(success: false, thumbnail: thumbnail)
                    }
                    
                    print("upload() failed: [\(error)]")
                }
                if task.result != nil {
                    VTUpdateStatusManager.manager.photoUploadFinished(success: true, thumbnail: thumbnail)
                    try? FileManager.default.removeItem(at: fileURL)
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                    })
                }
                return nil
            }
            return uploadRequest
        } else {
            VTUpdateStatusManager.manager.photoUploadFinished(success: false, thumbnail: thumbnail)
            return nil
        }
    }
    
    func uploadMediaVideo(videoName:String?,userId:String?) -> AWSS3TransferManagerUploadRequest? {
        
        if let userId = userId, let videoName = videoName {
            
            let fileName = videoName.appending(".mp4")
            let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(fileName)
            let uploadPath = VTConstants.Strings.amazonMediaVideoUrl(userId: userId, fileName: videoName)
            
            let uploadRequest = AWSS3TransferManagerUploadRequest()
            uploadRequest?.body = fileURL
            uploadRequest?.key = uploadPath
            uploadRequest?.bucket = VTConstants.Strings.S3BucketName
            
            let transferManager = AWSS3TransferManager.default()
            
            DispatchQueue.main.async(execute: { () -> Void in
                VTSingleton.shared.tabbarSocialMedia?.feedVC.progressView.setProgress(0, animated: false)
            })
            uploadRequest!.uploadProgress = { (bytesSent:Int64, totalBytesSent:Int64, totalBytesExpectedToSend:Int64) in
                DispatchQueue.main.sync(execute: { () -> Void in
                    VTSingleton.shared.tabbarSocialMedia?.feedVC.progressView.setProgress(Float(Double(totalBytesSent)/Double(totalBytesExpectedToSend)), animated: true)
                })
            }
            
            transferManager.upload(uploadRequest!).continueWith { (task) -> Any? in
                if let error = task.error as NSError? {
                    var errorCode = AWSS3TransferManagerErrorType.unknown
                    if error.domain == AWSS3TransferManagerErrorDomain as String {
                        errorCode = AWSS3TransferManagerErrorType(rawValue: error.code)!
                    }
                    if errorCode != AWSS3TransferManagerErrorType.cancelled {
                        VTUpdateStatusManager.manager.videoUploadFinished(success: false)
                    }
                    print("upload() failed: [\(error)]")
                }
                if task.result != nil {
                    VTUpdateStatusManager.manager.videoUploadFinished(success: true)
                    try? FileManager.default.removeItem(at: fileURL)
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                    })
                }
                return nil
            }
            return uploadRequest
            
        } else {
            VTUpdateStatusManager.manager.videoUploadFinished(success: false)
            return nil
        }
    }
}

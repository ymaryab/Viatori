//
//  VTSingleton.swift
//  Viatori
//
//  Created by Serkut Yegin on 01/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import Marshal
import GGLSignIn
import TwitterKit
import FBSDKCoreKit
import FBSDKLoginKit
import OneSignal
//import TKSwarmAlert
import MIBlurPopup

class VTSingleton : NSObject {
    
    static let shared = VTSingleton()
    
    var reportTypes : [Int:[VTReportCategories]] = [:]
    var rootViewController : VTRootViewController!
    var tabbarSocialMedia : SocialMediaTabbarController?
    var tabbarOrder : OrderTabbarController?
    var user : VTUserDetailObject?
    
    var userId : String? = UserDefaults.standard.string(forKey: VTConstants.UserPreference.userId) {
        didSet {
            UserDefaults.standard.set(userId, forKey: VTConstants.UserPreference.userId)
            setOneSignalUserTag()
        }
    }
    
    var userToken : String? = UserDefaults.standard.string(forKey: VTConstants.UserPreference.userToken) {
        didSet {
            UserDefaults.standard.set(userToken, forKey: VTConstants.UserPreference.userToken)
        }
    }
    
    var useTokenAuthorization = false
    var inAppUrls : VTInAppUrls?
    var signupHelper : SignupHelper?
    var countryCodes : [VTCountryCode] = [VTCountryCode.init(object: ["Country":"Türkiye","CountryCode":"+90","CountryHolder":"(XXX) XXX XX XX"])]
    
    var useOfflineMode = UserDefaults.standard.bool(forKey: VTConstants.UserPreference.useOfflineMode) {
        didSet {
            UserDefaults.standard.set(useOfflineMode, forKey: VTConstants.UserPreference.useOfflineMode)
        }
    }
    
    var appOpenedWithOfflineMode = false
    
    var facebookFriends : [VTUserObject]? {
        didSet {
            if let facebookFriends = facebookFriends, let oldValue = oldValue, facebookFriends.count != oldValue.count {
                NotificationCenter.default.post(name: .facebookFriendsChanged, object: nil)
            } else if (facebookFriends != nil && oldValue == nil) || (oldValue != nil && facebookFriends == nil)  {
                NotificationCenter.default.post(name: .facebookFriendsChanged, object: nil)
            }
        }
    }
    var twitterFriends : [VTUserObject]? {
        didSet {
            if let twitterFriends = twitterFriends, let oldValue = oldValue, twitterFriends.count != oldValue.count {
                NotificationCenter.default.post(name: .twitterFriendsChanged, object: nil)
            } else if (twitterFriends != nil && oldValue == nil) || (oldValue != nil && twitterFriends == nil)  {
                NotificationCenter.default.post(name: .twitterFriendsChanged, object: nil)
            }
        }
    }
    
    var alsoShareOnFacebook : Bool = UserDefaults.standard.bool(forKey: VTConstants.UserPreference.alsoShareOnFacebook) {
        didSet {
            UserDefaults.standard.set(alsoShareOnFacebook, forKey: VTConstants.UserPreference.alsoShareOnFacebook)
        }
    }
    
    var alsoShareOnTwitter : Bool = UserDefaults.standard.bool(forKey: VTConstants.UserPreference.alsoShareOnTwitter) {
        didSet {
            UserDefaults.standard.set(alsoShareOnTwitter, forKey: VTConstants.UserPreference.alsoShareOnTwitter)
        }
    }
    
    func clearUser() {
        (VIAServiceHandler.sharedHandler() as! VIAServiceHandler).cancelAllOperations()
        VTFeedManager.manager.stopAutomatedTimelineRefresh()
        self.userId = nil
        self.userToken = nil
        self.user = nil
        self.tabbarSocialMedia = nil
        self.tabbarOrder = nil
        self.facebookFriends = nil
        self.twitterFriends = nil
        self.alsoShareOnTwitter = false
        self.alsoShareOnFacebook = false
        let signIn = GIDSignIn.sharedInstance()
        signIn?.signOut()
        FBSDKLoginManager().logOut()
        
        OneSignal.deleteTag("userId")
        
        let store = Twitter.sharedInstance().sessionStore
        if let userID = store.session()?.userID {
            store.logOutUserID(userID)
        }
    }
    
    
    static func createAndShow() -> VTLoadingView {
        let loadingView = VTLoadingView.create() as! VTLoadingView
        loadingView.show()
        return loadingView
    }
    
    func refreshNotifications() {
        
        debugPrint("yeniliyor bildirimleri...")
        if UIApplication.shared.applicationState == .active  {
            if let _ = userId,  let _ = userToken {
                VTWebService.getNotificationBadgeCount(success: { (task, response) in
                    if let response = response, response.statusCode == .success,
                        let responseData = response.responseData,
                        let badgeCount:UInt =  try? responseData.value(for: "notificationBadgeCount") {
                        VTSingleton.shared.tabbarSocialMedia?.socialMediaTabbar.setActivityBadge(badgeCount: badgeCount)
                    }

                }) { (task, response, error) in }
                VTSingleton.shared.tabbarSocialMedia?.activityVC.getInitialNotifications()
                VTSingleton.shared.tabbarSocialMedia?.activityVC.getFriendRequestCount()
            }
        }
    }
    
    func openViaToriPointPopup(response:VIAResponse?) {
        
        if let pointObject = response?.pointObject {
            
            let pointData = VTPointObject.init(object: pointObject)
            
            let vc = UIViewController.controller(for: .socialMediaOther, controllerIdentifier: .viatoriPointEarned ) as! ViaToriPointEarnedViewController
            vc.data = pointData
            //VTSingleton.shared.rootViewController.presentVC(vc)
            MIBlurPopup.show(vc, on: VTSingleton.shared.rootViewController)
        }
        
        
    }
    
    func openNotificationForActivity() {
        
        if let state = rootViewController.vtSlidingMenu()?.menuState {
            if state == MenuState.Right  {
                rootViewController.vtSlidingMenu()?.menuState = MenuState.Left
            }
        }
        
        if let state = rootViewController.vtSubSlidingMenu()?.menuState {
            if state == SubMenuState.right  {
                rootViewController.vtSubSlidingMenu()?.menuState = SubMenuState.left
            }
        }
        
        if let currentIndex = self.tabbarSocialMedia?.selectedIndex {
            if let navcon = self.tabbarSocialMedia?.viewControllers?[currentIndex] as? UINavigationController
            {
                navcon.popToRootViewController(animated: true)
            }
        }
        self.tabbarSocialMedia?.selectedIndex = 2
        
    }
    
    func openNotificationForMessage() {
        
        if let state = rootViewController.vtSlidingMenu()?.menuState {
            if state == MenuState.Right  {
                rootViewController.vtSlidingMenu()?.menuState = MenuState.Left
            }
        }
        
        if let state = rootViewController.vtSubSlidingMenu()?.menuState {
            if state == SubMenuState.left  {
                rootViewController.vtSubSlidingMenu()?.menuState = SubMenuState.right
            }
        }
        
        if let currentIndex = self.tabbarSocialMedia?.selectedIndex {
            if let navcon = self.tabbarSocialMedia?.viewControllers?[currentIndex] as? UINavigationController
            {
                navcon.popToRootViewController(animated: true)
            }
        }
        self.tabbarSocialMedia?.selectedIndex = 0
        
    }
    
    func setOneSignalUserTag() {
        if userId != nil {
            OneSignal.sendTags(["userId" : userId ?? ""], onSuccess: { (result) in
                print("success!")
            }) { (error) in
                print("Error sending tags - \(String(describing: error?.localizedDescription))")
            }
        }
    }
}

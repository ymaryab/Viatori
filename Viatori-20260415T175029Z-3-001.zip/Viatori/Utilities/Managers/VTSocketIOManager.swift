//
//  VTSocketIOManager.swift
//  Viatori
//
//  Created by serefercelik on 11.04.2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import SocketIO

class VTSocketIOManager: NSObject{
    static let sharedInstance = VTSocketIOManager()
    
    //var socket2: SocketIOClient = SocketIOClient(socketURL: URL(string: "http://78.135.113.19:4040")!)
    let socket = SocketIOClient(socketURL: URL(string: "http://78.135.113.19:443")!, config: [.log(true), .forcePolling(true)])
    
    let date = Date()
    let calendar = Calendar.current
    


    override init() {
        super.init()
    }
    
    func establishConnection() {
        socket.connect()
        debugPrint("sockete bağlandı bu ")
    }
    
    func startcon(username: String,fullname: String, userId: String){
        socket.on("connect") {data, ack in
            print("socket connected")
            self.socket.emit("set-name",username, userId)
        }
    }
    
    func closeConnection() {
        socket.disconnect()
    }
    
    func closeConn(){
        socket.emit("user left")
        debugPrint("kullanıcı ayrıldı")
    }
    
    func closeConnect() {
        socket.on("disconnect") {data, ack in
            self.socket.emit("user left")
            debugPrint("kullanıcı ayrıldı")
        }
    }
    
    func setJoinRoom(roomid: String,userId: String){
        socket.emit("join-room", roomid, userId)
        debugPrint("Bağlantı sağlanıyor" + " " + roomid + " " + userId)
    }
    func sendMessage(message: String, roomId: String, user2id: String, type: Int) {
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        socket.emit("chat-message", message, roomId, user2id,0,"\(hour):\(minutes)")
    }
    
    func sendImageMessage(message: String, roomId: String, user2id: String, type: Int) {
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        socket.emit("chat-message", message, roomId, user2id,1,"\(hour):\(minutes)")
    }
    func sendVideoMessage(message: String, roomId: String, user2id: String, type: Int) {
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        socket.emit("chat-message", message, roomId, user2id,2,"\(hour):\(minutes)")
    }
    func sendPostMessage(message: String, roomId: String, user2id: String, type: Int) {
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        socket.emit("chat-message", message, roomId, user2id,4,"\(hour):\(minutes)")
    }
    func sendUserMessage(message: String, roomId: String, user2id: String, type: Int) {
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        socket.emit("chat-message", message, roomId, user2id,5,"\(hour):\(minutes)")
    }

    
    func getJoinRoom(roomId: String) {
        socket.on("join") {data, ack in

            self.socket.emit("join", roomId)
            debugPrint("Bağlanıyo la bu ")
        }
    }
    
    func getChatMessage(completionHandler: @escaping (_ messageInfo: [String: AnyObject]) -> Void) {
        socket.on("chat-message") { (dataArray, socketAck) -> Void in
            var messageDictionary = [String: AnyObject]()
            print(dataArray[0])
            let str2 = dataArray[0] as! NSDictionary
            let personName = str2["username"] as! String
            let message = str2["message"] as! String
            //let userfullname = str2["fullname"] as! String
            let userId = str2["userId"] as! String
            let type = str2["type"] as! Int
            let roomid = str2["roomid"] as! String
            let messagedate = str2["messagedate"] as! String
            
            messageDictionary["message"] = message as AnyObject
            messageDictionary["type"] = type as AnyObject
            messageDictionary["roomid"] = roomid as AnyObject
            messageDictionary["messagedate"] = messagedate as AnyObject

            debugPrint(personName + "Kullanıcı şöyle mesaj attı:" + message + ""  + "" + userId)

            //messageDictionary["message"] = dataArray[1] as! String as AnyObject
            //messageDictionary["date"] = dataArray[2] as! String as AnyObject
            
            completionHandler(messageDictionary)
            
        }
    }
        
        
        
    
    func getChatMessageOld(completionHandler: @escaping (_ messageOldInfo: [String: AnyObject]) -> Void) {
        socket.on("old-messages") { (dataArray, socketAck) -> Void in
            var messageDictionaryOld = [String: AnyObject]()
            print(dataArray[0])
            let str2 = dataArray[0] as! NSDictionary
            let personName = str2["username"] as! String
            let message = str2["message"] as! String
            //let userfullname = str2["fullname"] as! String
            let userId = str2["userId"] as! String
            messageDictionaryOld["message"] = message as AnyObject
            messageDictionaryOld["userId"] = userId as AnyObject
            
            debugPrint(personName + "Kullanıcı şöyle mesaj attı:" + message + " "  + " " + userId)
            
            //messageDictionary["message"] = dataArray[1] as! String as AnyObject
            //messageDictionary["date"] = dataArray[2] as! String as AnyObject
            
            completionHandler(messageDictionaryOld)
            
        }
    }
    
    func sendStartTypingMessage(_ nickname: String) {
        socket.emit("startType", nickname)
    }
    
    func sendStopTypingMessage(_ nickname: String) {
        socket.emit("stopType", nickname)
    }

}

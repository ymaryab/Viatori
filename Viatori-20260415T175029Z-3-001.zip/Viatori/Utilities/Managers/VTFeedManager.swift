//
//  VTFeedManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 02/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

enum FeedContentType : Int {
    case media=0,tag,allPost
}

class VTFeedManager {

    internal static let AUTOMATED_REFRESH_INTERVAL : Double = 60
    internal var operationAutomatedRefresh : VIAOperation?
    internal var timerAutomatedRefresh : Timer?
    static let manager = VTFeedManager()
    var feedDatasource : [String:VTFeedObject] = [:]
    var deletedFeeds : [String] = []
    
    @discardableResult
    func addFeedsToDatasource(feedArray:[VTFeedObject]?) -> [String] {
        var retVal : [String] = []
        if let feedArray = feedArray {
            for feedObject in feedArray {
                if let feedId = feedObject.feedID {
                    feedDatasource[feedId] = feedObject
                    retVal.append(feedId)
                }
            }
        }
        return retVal
    }
    
    @discardableResult
    func addFeedToDatasource(feed:VTFeedObject?) -> String? {
        guard let feedId = feed?.feedID else {return nil}
        feedDatasource[feedId] = feed!
        return feedId
    }
    
    func feeds(for feedIds:[String]) -> [VTFeedObject] {
        var feeds = [VTFeedObject]()
        for feed in feedIds {
            if let vtFeed = self.feed(for: feed) {
                feeds.append(vtFeed)
            }
        }
        return feeds
    }
    
    func feed(for feedId:String?) -> VTFeedObject? {
        if let feedId = feedId, !feedId.isEmpty {
            return feedDatasource[feedId]
        }
        return nil
    }
    
    func getFirstCallResponse(completion:@escaping (_ success:Bool , _ response:VTTimelineUserResponse?)->()) {
        
        VTWebService.firstCallService(onStart: {
            
        }, success: { (task, response) in
            if let response = response, response.statusCode == .success {
                let timelineUserResponse = VTTimelineUserResponse.init(object: response.responseData)
                completion(true,timelineUserResponse)
            } else {
                completion(false,nil)
            }
        }) { (task, response, error) in
            completion(false,nil)
        }
    }
    
    func timelineUpdate(lastId:String,firstId:String,identifier:String,friendId:String? = nil,hashtag:String?=nil,postType:Int?=nil,completion:@escaping (_ success:Bool , _ response:[FeedContentType:[String]], _ userObject:VTUserDetailObject?,_ trendUsers : VTTrendUsers?)->()) {
        var lastDate = ""
        var firstDate = ""
        
        if let lastObject = self.feed(for: lastId)?.feedDate { lastDate = lastObject }
        if let firstObject = self.feed(for: firstId)?.feedDate { firstDate = firstObject }
        
        VTWebService.getTimeline(lastDate: lastDate, firstDate: firstDate, identifier: identifier, friendId: friendId, hashtag: hashtag, postType : postType,
                                 success: { (task, response) in
            if let response = response, response.statusCode == .success, let responseData = response.responseData {
                
                var responseDict : [FeedContentType:[String]] = [.media:[],.tag:[],.allPost:[]]
                var userObject : VTUserDetailObject?
                var trendUsers : VTTrendUsers?
                if identifier == VT_TIMELINE || identifier == VT_TIMELINE_HASHTAG {
                    responseDict[.allPost] = self.addFeedsToDatasource(feedArray: VTTimelineResponse.init(object: responseData).mainTimelineObject)
                } else {
                    let userResponse = VTTimelineUserResponse.init(object: responseData)
                    if let profileArray = userResponse.timelineObject {
                        responseDict = profileArray.handleForManager()
                    }
                    userObject = userResponse.myProfileObject
                    trendUsers = userResponse.trendUsers
                }
                
                completion(true,responseDict,userObject,trendUsers)
            } else {
                completion(false,[:],nil,nil)
            }
        }) { (task, response, error) in
            completion(false,[:],nil,nil)
        }
    }
}

extension VTFeedManager {
    
    func startAutomatedTimelineRefresh() {
        
        if self.timerAutomatedRefresh != nil {
            stopAutomatedTimelineRefresh()
        }
        
        Timer.runThisAfterDelay(seconds: VTFeedManager.AUTOMATED_REFRESH_INTERVAL) { [unowned self] in
            self.timerAutomatedRefresh = Timer.runThisEvery(seconds: VTFeedManager.AUTOMATED_REFRESH_INTERVAL) { [unowned self] (timer) in
                self.callTimelineRefresh()
            }
        }
    }
    
    func stopAutomatedTimelineRefresh() {
        timerAutomatedRefresh?.invalidate()
        timerAutomatedRefresh = nil
        if let operation = operationAutomatedRefresh {
            operation.cancel()
        }
    }
    
    private func callTimelineRefresh() {
        guard let feedVC = VTSingleton.shared.tabbarSocialMedia?.feedVC else { stopAutomatedTimelineRefresh(); return }
        if feedVC.feedArray.count > 0 {
            guard let lastDate = self.feed(for: feedVC.feedArray.first)?.feedDate, let serviceName = feedVC.serviceNameForTop() else { return }
            operationAutomatedRefresh = VTWebService.getTimeline(lastDate: lastDate, firstDate: "", identifier: serviceName, friendId: nil, hashtag: nil, automoted:true,success: { (task, response) in
                if let response = response, response.statusCode == .success, let responseData = response.responseData {
                    let arrNewPosts = self.addFeedsToDatasource(feedArray: VTTimelineResponse.init(object: responseData).mainTimelineObject)
                    if arrNewPosts.count > 0 {
                        feedVC.automatedNewPostsArrived(newPosts: arrNewPosts)
                    }
                }
            }, failure: { (task, response, error) in })
        }
    }
}

internal extension VTTimelineObject {
    
    func handleForManager() -> [FeedContentType:[String]] {
        
        var dict : [FeedContentType:[String]] = [.media:[],.tag:[],.allPost:[]]
        
        if let media = self.postTypeMedia {
            dict[.media] = VTFeedManager.manager.addFeedsToDatasource(feedArray: media)
        }
        if let tag = self.postTypeTag {
            dict[.tag] = VTFeedManager.manager.addFeedsToDatasource(feedArray: tag)
        }
        if let allPost = self.postTypeFull {
            dict[.allPost] = VTFeedManager.manager.addFeedsToDatasource(feedArray: allPost)
        }
        return dict
    }
}



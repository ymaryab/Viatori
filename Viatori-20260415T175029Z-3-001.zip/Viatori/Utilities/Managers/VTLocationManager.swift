//
//  VTLocationManager.swift
//  Viatori
//
//  Created by Nermin Sarifakioglu on 25/01/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import CoreLocation

protocol VTLocationManagerDelegate : class {
    func locationManager(manager:VTLocationManager, didUpdateUser location: CLLocation)
    func locationManager(manager:VTLocationManager, didChangeAuthorization status: CLAuthorizationStatus)
}

extension VTLocationManagerDelegate {
    func locationManager(manager:VTLocationManager, didUpdateUser location: CLLocation) {}
    func locationManager(manager:VTLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {}
}

class VTLocationManager: NSObject,  CLLocationManagerDelegate{
    
    var locationManager: CLLocationManager!

    var userLocation: CLLocation?
    
    private var listeners : [VTLocationManagerDelegate?] = [] {
        didSet {
            if (listeners.count == 0) {
                stopUpdatingLocation() // if none of the listeners needs update
            } else {
                startUpdatingLocation()
            }
        }
    }

    
    override init() {
        super.init()
        locationManager = CLLocationManager()
        
        if (CLLocationManager.locationServicesEnabled())
        {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestWhenInUseAuthorization()
        }
    }
    
    static let sharedInstance : VTLocationManager = {
        let instance = VTLocationManager()
        return instance
    }()
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if ( locations.last != nil ){
            userLocation = locations.last
            updateLocation(userLocation!)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        changeAuthorizationStatus(status: status)
        if self.authorizationStatusIsOk() {
            if listeners.count > 0 {
                self.startUpdatingLocation()
            }
            VTPeriodicLocationUpdater.sharedInstance.startPeriodicUpdateIfNeccesary()
        }
    }

    private func startUpdatingLocation() {
        locationManager.startUpdatingLocation()
    }
    
    private func stopUpdatingLocation() {
        locationManager.stopUpdatingLocation()
    }
    
    func subscribe(listener:VTLocationManagerDelegate) {
        weak var weakListener = listener
        
        for index in 0..<listeners.count {
            if let current = listeners[index] {
                if weakListener === current {
                    return  // no need to add
                }
            }
        }
        
        listeners.append(weakListener)
    }

    func unsubscribe(listener:VTLocationManagerDelegate) {
        
        for index in 0..<listeners.count {
            if let current = listeners[index] {
                 if listener === current {
                    self.listeners.remove(at: index)
                 }
            }
        }
        
    }

    func updateLocation(_ location: CLLocation ) {
        userLocation = location
        for listener in listeners {
            listener?.locationManager(manager: self, didUpdateUser: location)
        }
    }
    
    func changeAuthorizationStatus(status: CLAuthorizationStatus) {
        for listener in listeners {
            listener?.locationManager(manager: self, didChangeAuthorization: status)
        }
    }
    
}

extension VTLocationManager {
    
    func authorizationStatusIsDetermined() -> Bool {
        return CLLocationManager.authorizationStatus() != .notDetermined
    }
    
    func authorizationStatusIsOk() -> Bool {
        return CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways
    }
}

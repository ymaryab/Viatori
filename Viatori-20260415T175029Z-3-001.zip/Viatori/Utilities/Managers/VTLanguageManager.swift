//
//  VTLanguageManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 01/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

enum LanguageType {
    
    case languageOne
    case languageTwo
    case languageWithValue(String) // (languageCode,languageVersion)
    
    var languageCode : String {
        switch self {
        case .languageOne: return "one"
        case .languageTwo: return "two"
        case .languageWithValue(let value): return value
        }
    }
    
    var languageCodeResource : String {
        switch self {
        case .languageOne: return ""
        case .languageTwo: return ""
        case .languageWithValue(let value): return "VT_LANGUAGE_CODE_\(value)"
        }
    }
    
    var versionCodeResource : String {
        switch self {
        case .languageOne: return ""
        case .languageTwo: return ""
        case .languageWithValue(let value): return "VT_LANGUAGE_VERSION_\(value)"
        }
    }
}

class VTLanguageManager: NSObject {

    static let sharedManager = VTLanguageManager()
    internal var languageDict : [String:String] = [:]
    internal var currentLanguage : String = ""
    internal var currentVersion : String = ""
    internal var languageType : LanguageType = .languageOne
    
    override init() {
        super.init()
    }
    
    internal func readLanguageDictFromSource(languageType:LanguageType) {
        
        var dictFromSource : [String:String]?
        
        switch languageType {
        case .languageOne,.languageTwo:
            
            let root = NSDictionary(contentsOfFile: Bundle.main.path(forResource: "language_\(languageType.languageCode)", ofType: "plist")!);
            dictFromSource = root?["languageDict"] as? [String:String]
            break;
        case .languageWithValue(_):
            
            let documentsDirectory = VTConstants.Path.Documents
            let path = documentsDirectory.appending("/language_\(languageType.languageCode).plist")
            let fileManager = FileManager.default
            
            if fileManager.fileExists(atPath: path) {
                let root = NSDictionary(contentsOfFile: path)
                dictFromSource = root?["languageDict"] as? [String:String]
            }
            
            break;
        }
        
        if let dictFromSource = dictFromSource {
            self.languageDict = dictFromSource
        }
        
    }
    
    @discardableResult
    internal func saveLanguageDictionary(languageCode:String, languageDictionary:[String:String], languageVersion:String) -> Bool {
        
        let documentsDirectory = VTConstants.Path.Documents
        let path = documentsDirectory.appending("/language_\(languageCode).plist")
        
        let rootDict = NSDictionary.init(object: languageDictionary, forKey: "languageDict" as NSCopying)
        let isWritten = rootDict.write(toFile: path, atomically: true)
        
        return isWritten
    }
    
    public func handleNewLanguageResponse(response:Dictionary<String, Any>) {
        
        let languageObject = VTLanguageResponse.init(object: response)
        
        if let languageCode = languageObject.languageCode, let languageDictionary = languageObject.languageDictionary, let languageVersion = languageObject.languageVersion {
            if self.saveLanguageDictionary(languageCode: languageCode, languageDictionary: languageDictionary, languageVersion: languageVersion) {
                self.languageType = .languageWithValue(languageCode)
                self.currentVersion = languageVersion
                self.currentLanguage = languageCode
                self.languageDict = languageDictionary
                UserDefaults.standard.set(self.currentLanguage, forKey: VTConstants.UserPreference.languageCode)
                UserDefaults.standard.set(self.currentVersion, forKey: self.languageType.versionCodeResource)
                UserDefaults.standard.set(self.currentLanguage, forKey: self.languageType.languageCodeResource)
                UserDefaults.standard.set(VTConstants.Device.PreferredLanguageCode, forKey: VTConstants.UserPreference.preferredLanguageCode)
            }
        }
    }
}

extension VTLanguageManager {
    
    func debugInitialize() {
        self.readLanguageDictFromSource(languageType: .languageOne)
    }
    
    func initialize() {
        
        if let previousPreferredLanguageCode = UserDefaults.standard.string(forKey: VTConstants.UserPreference.preferredLanguageCode),
            let preferredLanguageCode = VTConstants.Device.PreferredLanguageCode {
            if !previousPreferredLanguageCode.isEmpty && !preferredLanguageCode.isEmpty && previousPreferredLanguageCode == preferredLanguageCode {
                if let languageCode = UserDefaults.standard.string(forKey: VTConstants.UserPreference.languageCode) {
                    if !languageCode.isEmpty {
                        self.languageType = .languageWithValue(languageCode)
                        self.currentLanguage = UserDefaults.standard.string(forKey: self.languageType.languageCodeResource)!
                        self.currentVersion = UserDefaults.standard.string(forKey: self.languageType.versionCodeResource)!
                        self.readLanguageDictFromSource(languageType: self.languageType)
                    }
                }
            }
        }
    }
    
    public func getLocalizedString(key:String) -> String {
        
        var returnValue = String(format:"%@",key)
        
        if let valueFromDict = self.languageDict[key] {
            if !valueFromDict.isEmpty {
                returnValue = String(format:"%@",valueFromDict)
            }
        }
        return returnValue
    }
    
    public func getLanguage() -> String {
        
        return VTConstants.Device.PreferredLanguageCode ?? VTConstants.Device.PreferredLanguage
    }
    
    public func getVersion() -> String {
        
        var version = "0"
        
        if let previousPreferredLanguageCode = UserDefaults.standard.string(forKey: VTConstants.UserPreference.preferredLanguageCode),
            let preferredLanguageCode = VTConstants.Device.PreferredLanguageCode {
            if !previousPreferredLanguageCode.isEmpty && !preferredLanguageCode.isEmpty && previousPreferredLanguageCode == preferredLanguageCode {
                if let languageCode = UserDefaults.standard.string(forKey: VTConstants.UserPreference.languageCode) {
                    if !languageCode.isEmpty {
                        version =  UserDefaults.standard.string(forKey: LanguageType.languageWithValue(languageCode).versionCodeResource)!
                    }
                }
            }
        }
        return version
    }
}

extension String {
    
    public func localized() -> String {
        return VTLanguageManager.sharedManager.getLocalizedString(key: self)
    }
}

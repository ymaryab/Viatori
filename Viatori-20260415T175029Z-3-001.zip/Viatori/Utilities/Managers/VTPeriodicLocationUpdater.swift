//
//  VTPeriodicLocationUpdater.swift
//  Viatori
//
//  Created by ProAegean on 05/05/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import CoreLocation

class VTPeriodicLocationUpdater: NSObject, CLLocationManagerDelegate {

    var locationManager: CLLocationManager!
    
    static let sharedInstance : VTPeriodicLocationUpdater = {
        let instance = VTPeriodicLocationUpdater()
        return instance
    }()

    func startPeriodicUpdateIfNeccesary() {
        if (CLLocationManager.locationServicesEnabled() && self.authorizationStatusIsDetermined() && self.authorizationStatusIsOk())
        {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
            // Set a movement threshold for new events.
            locationManager.distanceFilter = 500; // meters
            locationManager.startMonitoringSignificantLocationChanges()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if ( locations.last != nil ){
            if let location = locations.last {
                VTWebService.updateLocationOfUser(lat: location.coordinate.latitude, lon: location.coordinate.longitude,
                                              success: { (task, response) in
                                                
                }) { (task, response, error) in }
            }
        }
    }
}

extension VTPeriodicLocationUpdater {
    
    func authorizationStatusIsDetermined() -> Bool {
        return CLLocationManager.authorizationStatus() != .notDetermined
    }
    
    func authorizationStatusIsOk() -> Bool {
        return CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways
    }
}

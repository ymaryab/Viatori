//
//  VTThemeManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 01/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

extension ColorFamily {
    
    //MARK: Common
    var ocolorTabbarBg : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtLightBlackColor
        case .familyDark: return UIColor.white
        }
    }

    var ocolorTabbarSelectedTextFg : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtBlueColor
        case .familyDark: return UIColor.vtBlueColor
        }
    }
    
    var ocolorTabbarActiveTextFg : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtGrayColor2
        case .familyDark: return UIColor.vtLightGrayColor
        }
    }

    var ocolorTabbarDeactiveTextFg : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtDarkGrayColor3
        case .familyDark: return UIColor.vtGrayColor2
        }
    }
    
    var ocolorTitleText : UIColor {
        switch self {
        case .familyDefault: return UIColor.red
        case .familyDark: return UIColor.white
        }
    }
    
    var ocolorRegularText : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtGrayColor
        case .familyDark: return UIColor.white
        }
    }
    
    var ocolorCommonBg: UIColor {
        switch self {
        case .familyDefault: return UIColor.white
        case .familyDark: return UIColor.vtDarkGrayColor
        }
    }
    
    var ocolorBorder: UIColor {
        switch self {
        case .familyDefault: return UIColor.vtGrayColor3
        case .familyDark: return UIColor.vtGrayColor3
        }
    }
    
    var ocolorQrBg: UIColor {
        switch self {
        case .familyDefault: return UIColor.vtWhiteColor1
        case .familyDark: return UIColor.vtLightBlackColor
        }
    }
    
    
}



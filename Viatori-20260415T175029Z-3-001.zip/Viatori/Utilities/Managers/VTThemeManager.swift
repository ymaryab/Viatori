//
//  VTThemeManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 01/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

enum ColorFamily {
    
    case familyDefault
    case familyDark
    
    //MARK: Common
    var colorDarkText : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtDarkGrayColor
        case .familyDark: return UIColor.white
        }
    }
    
    var colorWhiteText : UIColor {
        switch self {
        case .familyDefault: return UIColor.white
        case .familyDark: return UIColor.vtDarkGrayColor
        }
    }
    
    var colorGrayText : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtGrayColor
        case .familyDark: return UIColor.vtGrayColor
        }
    }
    
    var colorBlue : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtBlueColor
        case .familyDark: return UIColor.vtBlueColor
        }
    }
    
    var colorGray : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtGrayColor
        case .familyDark: return UIColor.vtGrayColor
        }
    }
    
    var colorRed : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtRedColor
        case .familyDark: return UIColor.vtRedColor
        }
    }
    
    var colorOrange : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtOrangeColor
        case .familyDark: return UIColor.vtOrangeColor
        }
    }
    
    var colorLightGray : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtLightGrayColor
        case .familyDark: return UIColor.vtLightGrayColor
        }
    }
    
    //MARK: Walkthrough
    var colorWalkthroughVideoLayer : CGColor {
        switch self {
        case .familyDefault: return UIColor(colorLiteralRed: 0, green: 0, blue: 0, alpha: 0.4).cgColor
        case .familyDark: return UIColor(colorLiteralRed: 1, green: 1, blue: 1, alpha: 0.3).cgColor
        }
    }
    
    var colorWalkthroughWhite : UIColor {
        switch self {
        case .familyDefault: return UIColor.white
        case .familyDark: return UIColor.vtDarkGrayColor
        }
    }
    
    var colorWalkthroughDark : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtDarkGrayColor
        case .familyDark: return UIColor.white
        }
    }
    
    var colorWalktroughNavText : UIColor {
        switch self {
        case .familyDefault: return UIColor.white
        case .familyDark: return UIColor.vtDarkGrayColor
        }
    }
    
    //MARK: Signup & Login
    
    var colorSignupBackground : UIColor {
        switch self {
        case .familyDefault: return UIColor.white
        case .familyDark: return UIColor.vtDarkGrayColor
        }
    }
    
    var colorSignupNavbarTitleColor : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtDarkGrayColor
        case .familyDark: return UIColor.white
        }
    }
    
    var colorSignupBlue : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtBlueColor
        case .familyDark: return UIColor.vtBlueColor
        }
    }
    
    var colorSignupGreen : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtGreenColor
        case .familyDark: return UIColor.vtGreenColor
        }
    }
    
    var colorSignupGray : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtGrayColor
        case .familyDark: return UIColor.vtLightGrayColor
        }
    }
    
    //MARK: SocialMedia
    
    var colorSocialTabbarBg : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtSocialTabbarBg
        case .familyDark: return UIColor.vtSocialTabbarBg
        }
    }
    
    var colorSocialNavbarTint : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtDarkGrayColor
        case .familyDark: return UIColor.vtDarkGrayColor
        }
    }
    
    var colorSearchBarBg : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtSearchBarBg
        case .familyDark: return UIColor.vtSearchBarBg
        }
    }
    
    var colorSocialCommonBg: UIColor {
        switch self {
        case .familyDefault: return UIColor.white
        case .familyDark: return UIColor.white
        }
    }
    
    var colorSocialNavBlue: UIColor {
        switch self {
        case .familyDefault: return UIColor.vtBlueColor
        case .familyDark: return UIColor.vtBlueColor
        }
    }
    
    var colorHashtag : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtBlueColor
        case .familyDark: return UIColor.white
        }
    }
    
    var colorMention : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtBlueColor
        case .familyDark: return UIColor.white
        }
    }
    
    var colorUrl : UIColor {
        switch self {
        case .familyDefault: return UIColor.vtBlueColor
        case .familyDark: return UIColor.white
        }
    }
}

class VTThemeManager: NSObject {

    static let sharedManager = VTThemeManager()
    var family = ColorFamily.familyDefault
    
}



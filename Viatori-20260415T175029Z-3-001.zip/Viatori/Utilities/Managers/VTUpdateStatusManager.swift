//
//  VTUpdateStatusManager.swift
//  Viatori
//
//  Created by Serkut Yegin on 20/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import SugarRecord
import RealmSwift
import AWSS3

class VTUpdateStatusManager: NSObject {

    static let manager = VTUpdateStatusManager()
    private var uploadRequest : AWSS3TransferManagerUploadRequest?
    internal lazy var socialMediaHelper : SocialMediaHelper = {
        return SocialMediaHelper()
    }()
    
    internal var updateStatus : DBUpdateStatusObject? {
        guard let userId = VTSingleton.shared.userId else {return nil}
        let objects = try? db.request(DBUpdateStatusObject.self).filtered(with: "userId", equalTo: userId).fetch()
        if let objects = objects, objects.count > 0 {
            return objects.first
        }
        return nil
    }
    
    internal var taggedUsers : [DBUserObject]? {
        let objects = try? db.request(DBUserObject.self).fetch()
        if let objects = objects {
            return objects
        }
        return nil
    }
    
    var process : UpdateStatusProcess {
        if let updateStatus = self.updateStatus {
            return UpdateStatusProcess(rawValue: updateStatus.process)!
        } else {
            return .none
        }
    }
    
    lazy var db: RealmDefaultStorage = {
        var configuration = Realm.Configuration()
        configuration.fileURL = URL(fileURLWithPath: VTConstants.Path.databasePath(VTConstants.Strings.dbNameUpdateStatus))
        let _storage = RealmDefaultStorage(configuration: configuration)
        return _storage
    }()
    
    func addNewUpdateStatusObject(updateStatus : DBUpdateStatusEntity,image:UIImage? = nil,videoPath:URL?=nil,thumbnail:UIImage?=nil,taggedUser:[VTUserObject]=[]) {
        clearDB()
        do {
            addToDB(updateStatus: updateStatus,taggedUsers:taggedUser)
            let imageURL = try DBUpdateStatusObject.copyImage(image: image)
            let videoURL = try DBUpdateStatusObject.copyVideo(videoPath: videoPath)
            let thumbnailURL = try DBUpdateStatusObject.copyImage(image: thumbnail)
            self.updateDB(photoUrl: imageURL, videoUrl: videoURL, thumbnailUrl: thumbnailURL)
            startUploadProcess()
        } catch let error as NSError {
            debugPrint(error)
        }
    }
    
    private func startUploadProcess() {
        guard let updateStatus = self.updateStatus else { return }
        self.updateProcess(process: .willStartUpload)
        switch updateStatus.amazonUpload {
        case .noAmazonUpload:
            self.callAddPostService()
            break
        case .onlyPhoto:
            self.startImageUpload()
            break
        case .onlyVideo:
            self.startVideoUpload()
            break
        case .videoWithThumbnail:
            self.startImageUpload(thumbnail: true)
            break
        }
    }
    
    func retryUploadProcess() {
        guard let updateStatus = self.updateStatus else { return }
        let process = UpdateStatusProcess(rawValue:updateStatus.process)!
        if process != .postCreated || process != .postEdited {
            switch updateStatus.amazonUpload {
            case .noAmazonUpload:
                self.callAddPostService()
                break
            case .onlyPhoto:
                if process.needUploadMedia {
                    self.startImageUpload()
                } else {
                    self.callAddPostService()
                }
                break
            case .onlyVideo:
                if process.needUploadMedia {
                    self.startVideoUpload()
                } else {
                    self.callAddPostService()
                }
                break
            case .videoWithThumbnail:
                if process.needUploadMedia {
                    if updateStatus.thumbnailUploaded {
                        self.startVideoUpload()
                    } else {
                        self.startImageUpload(thumbnail: true)
                    }
                } else {
                    self.callAddPostService()
                }
                break
            }
        }
    }
    
    func checkInitialProcess() -> UpdateStatusProcess {
        let currentProcess = self.process
        switch currentProcess {
        case .willStartUpload,.isUploading:
            self.updateDB(process: .uploadError)
            return .uploadError
        case .addingPost,.uploadFinished:
            self.updateDB(process: .addPostError)
            return .addPostError
        case .postCreated, .postEdited:
            self.clearDB()
            return .none
        default:
            return currentProcess
        }
    }
    
    func discardUploadProcess() {
        
        if let uploadRequest = self.uploadRequest, !uploadRequest.isCancelled {
            uploadRequest.cancel()
        }
        
        clearDB()
        if let feedVC = VTSingleton.shared.tabbarSocialMedia?.feedVC {
            DispatchQueue.main.async {
                feedVC.handleUpdateStatusProcess(process: .none)
            }
        }
    }
    
    private func startVideoUpload() {
        if let dbStatus = self.updateStatus {
            updateProcess(process: .isUploading)
            uploadRequest = VTAmazonManager.sharedManager.uploadMediaVideo(videoName: dbStatus.videoUrl, userId: dbStatus.userId)
        }
    }
    
    private func startImageUpload(thumbnail:Bool = false) {
        if let dbStatus = self.updateStatus {
            updateProcess(process: .isUploading)
            uploadRequest = VTAmazonManager.sharedManager.uploadMediaPhoto(photoName: thumbnail ? dbStatus.thumbnailUrl : dbStatus.photoUrl , userId: dbStatus.userId, thumbnail: thumbnail)
        }
    }
    
    private func callAddPostService() {
        if let dbStatus = self.updateStatus {
            
            updateProcess(process: .addingPost)
            let isCreateNewPost = dbStatus.feedId == nil
            VTWebService.updateStatus(feedId:dbStatus.feedId ,post: dbStatus.post, photoUrl: VTConstants.Strings.amazonPhotoFullUrl(fileName: dbStatus.photoUrl) ?? dbStatus.defaultPhotoUrl, videoUrl: VTConstants.Strings.amazonVideoFullUrl(fileName: dbStatus.videoUrl) ?? dbStatus.defaultVideoUrl, thumbnailUrl: VTConstants.Strings.amazonPhotoFullUrl(fileName: dbStatus.thumbnailUrl) ?? dbStatus.defaultThumbnailUrl, aspectRatio: dbStatus.aspectRatio, taggedUsers: UtilityFunctions().converToDBTagArray(dbArray: self.taggedUsers), poiId: dbStatus.poiId, poiType:dbStatus.poiType,success: { (task, response) in
                
                if let response = response, response.statusCode == .success || response.statusCode == .via_Tori_Point_Earned {
                    if let timelineResponse = VTFeedDetailResponse.init(object: response.responseData).postDetail {
                        VTFeedManager.manager.addFeedToDatasource(feed: timelineResponse)
                        if isCreateNewPost {
                            self.socialMediaHelper.shareFeedObjectIfNeccessary(feedObject: timelineResponse)
                        }
                    }
                    self.updateProcess(process: isCreateNewPost ? .postCreated : .postEdited)
                    self.clearDB()
                    
                } else {
                    self.updateProcess(process: .addPostError)
                }
            }, failure: { (task, response, error) in
                self.updateProcess(process: .addPostError)
            })
        }
    }
    
    private func updateProcess(process:UpdateStatusProcess) {
        self.updateDB(process: process)
        if let feedVC = VTSingleton.shared.tabbarSocialMedia?.feedVC {
            DispatchQueue.main.async {
                feedVC.handleUpdateStatusProcess(process: process)
            }
        }
    }
    
    func videoUploadFinished(success:Bool) {
        
        if success {
            updateProcess(process: .uploadFinished)
            self.callAddPostService()
        } else {
            updateProcess(process: .uploadError)
        }
        
    }
    
    func photoUploadFinished(success:Bool, thumbnail:Bool = false) {
        
        if let dbStatus = self.updateStatus {
            if success {
                if dbStatus.amazonUpload == .onlyPhoto {
                    updateProcess(process: .uploadFinished)
                    self.callAddPostService()
                } else if dbStatus.amazonUpload == .videoWithThumbnail {
                    self.updateDB(thumbnailUploaded: true)
                    self.startVideoUpload()
                }
            } else {
                updateProcess(process: .uploadError)
            }
        }
    }
}

internal extension VTUpdateStatusManager {
    
    // MARK: Database Functions
    func addToDB(updateStatus : DBUpdateStatusEntity, taggedUsers:[VTUserObject]){
        try! self.db.operation { (context, save) -> Void in
            let _object: DBUpdateStatusObject = try! context.new()
            _object.process = updateStatus.process.rawValue
            _object.userId = updateStatus.userId
            _object.poiId = updateStatus.poiId
            _object.post = updateStatus.post
            _object.photoUrl = updateStatus.photoUrl
            _object.videoUrl = updateStatus.videoUrl
            _object.thumbnailUrl = updateStatus.thumbnailUrl
            _object.aspectRatio = updateStatus.aspectRatio
            _object.feedId = updateStatus.feedId
            _object.defaultThumbnailUrl = updateStatus.defaultThumbnailUrl
            _object.defaultVideoUrl = updateStatus.defaultVideoUrl
            _object.defaultPhotoUrl = updateStatus.defaultPhotoUrl
            if let poiType = updateStatus.poiType {
                _object.poiType = poiType
            }
            try! context.insert(_object)
            
            for user in taggedUsers {
                try! context.insert(user.convertToDBUser())
            }
            
            save()
        }
    }
    
    func updateDB(photoUrl:String?,videoUrl:String?,thumbnailUrl:String?) {
        if let dbStatus = self.updateStatus {
            try! self.db.operation { (context, save) -> Void in
                dbStatus.photoUrl = photoUrl
                dbStatus.videoUrl = videoUrl
                dbStatus.thumbnailUrl = thumbnailUrl
                save()
            }
        }
    }
    
    func updateDB(thumbnailUploaded:Bool) {
        if let dbStatus = self.updateStatus {
            try! self.db.operation { (context, save) -> Void in
                dbStatus.thumbnailUploaded = thumbnailUploaded
                save()
            }
        }
    }
    
    func updateDB(process:UpdateStatusProcess) {
        if let dbStatus = self.updateStatus {
            try! self.db.operation { (context, save) -> Void in
                dbStatus.process = process.rawValue
                save()
            }
        }
    }
    
    func clearDB() {
        try! self.db.operation({ (context, save) -> Void in
            let objects = try! context.request(DBUpdateStatusObject.self).fetch()
            let userObjects = try! context.request(DBUserObject.self).fetch()
            _ = try? context.remove(objects)
            _ = try? context.remove(userObjects)
            save()
        })
    }
}

//
//  DBUpdateStatusEntity.swift
//  Viatori
//
//  Created by Serkut Yegin on 20/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class DBUpdateStatusEntity: NSObject {

    var process : UpdateStatusProcess
    var userId : String
    var poiId : String?
    var poiType : Int?
    var post : String?
    var photoUrl : String?
    var videoUrl : String?
    var thumbnailUrl : String?
    var aspectRatio : Float = 1
    var feedId : String?
    //var taggedUsers : [String] = []
    
    var photo : UIImage?
    var thumbnail : UIImage?
    var videoPath : String?
    
    var defaultPhotoUrl : String?
    var defaultVideoUrl : String?
    var defaultThumbnailUrl : String?
    
    init(object: DBUpdateStatusObject) {
        self.process = UpdateStatusProcess(rawValue: object.process)!
        self.userId = object.userId
        self.poiId = object.poiId
        self.post = object.post
        self.photoUrl = object.photoUrl
        self.videoUrl = object.videoUrl
        self.thumbnailUrl = object.thumbnailUrl
        self.aspectRatio = object.aspectRatio
        self.feedId = object.feedId
        self.defaultPhotoUrl = object.defaultPhotoUrl
        self.defaultVideoUrl = object.defaultVideoUrl
        self.defaultThumbnailUrl = object.defaultThumbnailUrl
        self.poiType = object.poiType
    }
    
    init(userId:String, post:String?, feedId:String?, poi:CheckinStruct?) {
        self.process = .none
        self.userId = userId
        self.post = post
        self.feedId = feedId
        self.poiType = poi?.poiType?.rawValue
        if let poiId = poi?.poiId {
            self.poiId = "\(poiId)"
        }
    }
}

//
//  DBUpdateStatusObject.swift
//  Viatori
//
//  Created by Serkut Yegin on 20/02/2017.
//  Copyright © 2017 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import RealmSwift

public enum UpdateStatusAmazonUpload {
    case noAmazonUpload, onlyPhoto, videoWithThumbnail, onlyVideo
}

public enum UpdateStatusProcess : Int {
    case none = 0,willStartUpload,isUploading,uploadError,uploadFinished,addingPost,addPostError,postCreated,postEdited
    
    var needUploadMedia : Bool {
        switch self {
        case .none,.willStartUpload,.isUploading,.uploadError:
            return true
        default:
            return false
        }
    }
}

class DBUpdateStatusObject : Object {

    dynamic var process : Int = UpdateStatusProcess.willStartUpload.rawValue
    dynamic var userId : String = ""
    dynamic var poiId : String?
    dynamic var poiType : Int = PoiType.none.rawValue
    dynamic var post : String?
    dynamic var photoUrl : String?
    dynamic var videoUrl : String?
    dynamic var thumbnailUrl : String?
    dynamic var aspectRatio : Float = 1
    dynamic var feedId : String?
    dynamic var thumbnailUploaded : Bool = false
    
    dynamic var defaultPhotoUrl : String?
    dynamic var defaultVideoUrl : String?
    dynamic var defaultThumbnailUrl : String?
    
    open class func copyImage(image : UIImage?) throws -> String? {
        if let image = image {
            let uniqueStr = ProcessInfo.processInfo.globallyUniqueString
            let fileName = uniqueStr.appending(".png")
            let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(fileName)
            if let imageData = UIImageJPEGRepresentation(image, 0.5) {
                try imageData.write(to: fileURL, options: .atomic)
                return uniqueStr
            }
        }
        return nil
    }
    
    open class func copyVideo(videoPath: URL?) throws -> String? {
        if let videoPath = videoPath {
            let uniqueStr = ProcessInfo.processInfo.globallyUniqueString
            let fileName = uniqueStr.appending(".mp4")
            let fileURL = URL.init(fileURLWithPath: VTConstants.Path.Documents).appendingPathComponent(fileName)
            let videoData = try Data.init(contentsOf: videoPath)
            try videoData.write(to: fileURL, options: .atomic)
            return uniqueStr
        }
        return nil
    }
    
    internal override class func primaryKey() -> String? {
        return "userId"
    }
}

extension DBUpdateStatusObject {
    
    var amazonUpload : UpdateStatusAmazonUpload {
        
        var uploadStatus = UpdateStatusAmazonUpload.noAmazonUpload
        if let photoUrl = self.photoUrl, !photoUrl.isEmpty {
            uploadStatus = .onlyPhoto
        } else if let videoUrl = self.videoUrl, !videoUrl.isEmpty {
            if let thumbnailUrl = self.thumbnailUrl, !thumbnailUrl.isEmpty {
                uploadStatus = .videoWithThumbnail
            } else {
                uploadStatus = .onlyVideo
            }
        }
        return uploadStatus
    }
}

public class DBUserObject : Object {
    
    dynamic var userIsVerifed: Bool = false
    dynamic var userName: String?
    dynamic var userFullName: String?
    dynamic var userID: String?
    dynamic var userImage: String?
    
}

extension DBUserObject {
    
    func convertToVTUser() -> VTUserObject {
        let object = VTUserObject()
        object.userIsVerifed = self.userIsVerifed
        object.userName = self.userName
        object.userFullName = self.userFullName
        object.userID = self.userID
        object.userImage = self.userImage
        return object
    }
}

extension VTUserObject {
    
    func convertToDBUser() -> DBUserObject {
        let object = DBUserObject()
        if let isVerified = self.userIsVerifed {
            object.userIsVerifed = isVerified
        }
        object.userName = self.userName
        object.userFullName = self.userFullName
        object.userID = self.userID
        object.userImage = self.userImage
        
        return object
    }
}

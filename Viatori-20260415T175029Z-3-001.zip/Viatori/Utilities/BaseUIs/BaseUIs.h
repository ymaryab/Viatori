//
//  BaseUIs.h
//  Project140
//
//  Created by Serkut Yegin on 21.07.2016.
//  Copyright © 2016 Deytek Bilisim. All rights reserved.
//

#ifndef BaseUIs_h
#define BaseUIs_h

#import "BaseUILabel.h"
#import "BaseUILabelRegular.h"
#import "BaseUILabelBold.h"
#import "BaseUILabelLight.h"
#import "BaseUILabelMedium.h"

#import "BaseUITextView.h"
#import "BaseUITextViewBold.h"
#import "BaseUITextViewRegular.h"

#import "BaseUITextField.h"
#import "BaseUITextFieldBold.h"
#import "BaseUITextFieldRegular.h"

#import "BaseUIButton.h"
#import "BaseUIButtonBold.h"
#import "BaseUIButtonRegular.h"
#import "BaseUIButtonLight.h"
#import "BaseUIButtonMedium.h"

#endif /* BaseUIs_h */

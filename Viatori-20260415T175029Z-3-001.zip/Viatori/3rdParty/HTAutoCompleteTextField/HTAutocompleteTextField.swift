//
//  HTAutocompleteTextField.swift
//  HTAutocompleteTextFieldSwift
//
//  Created by crhuber on 1/26/15.
//  Copyright (c) 2015 crhuber. All rights reserved.
//

import UIKit

enum HTAutocompleteType : Int {
    case htAutocompleteTypeEmail = 1, htAutocompleteTypeColor
}

let kHTAutoCompleteButtonWidth:CGFloat = 30
var DefaultAutocompleteDataSource: HTAutocompleteDataSource?

// MARK: - HTAutocompleteDataSource
@objc protocol HTAutocompleteDataSource: NSObjectProtocol {
    func textField(_ textField: HTAutocompleteTextField,completionForPrefix prefix:NSString, ignoreCase: Bool) -> String
}

// MARK: - HTAutocompleteTextFieldDelegate
@objc protocol HTAutocompleteTextFieldDelegate: NSObjectProtocol {
    @objc optional func autoCompleteTextFieldDidAutoComplete(_ autoCompleteField:HTAutocompleteTextField) -> Void
    @objc optional func autocompleteTextField(_ autocompleteTextField:HTAutocompleteTextField,didChangeAutocompleteText autocompleteText:NSString) -> Void
}

class HTAutocompleteTextField: FloatLabelTextField {
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
    // Drawing code
    }
    */
    
    /*
    * Autocomplete behavior
    */
    var autocompleteType:HTAutocompleteType? // Can be used by the dataSource to provide different types of autocomplete behavior
    var autocompleteDisabled:Bool = false
    var ignoreCase:Bool = false
    var needsClearButtonSpace:Bool = false
    var showAutocompleteButton:Bool = false
    var autoCompleteTextFieldDelegate: HTAutocompleteTextFieldDelegate!
    var correctionNew:CGFloat = 0.0
    
    var autocompleteString:String! = "" {
        didSet {
            self.updateAutocompleteButtonAnimated(true)
        }
        
    }
    var autocompleteButton: UIButton! {
        didSet {
            self.updateAutocompleteButtonAnimated(true)
        }
    }
    
    /*
    * Configure text field appearance
    */
    var autocompleteLabel:UILabel!
    var autocompleteTextOffset:CGPoint = CGPoint(x: 0, y: 0)
    
    
    /*
    * Specify a data source responsible for determining autocomplete text.
    */
    var autocompleteDataSource : HTAutocompleteDataSource?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setupAutocompleteTextField()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        correctionNew = 6.0
        self.setupAutocompleteTextField()
    }
    
    func setupAutocompleteTextField() -> Void {
        
        self.autocompleteLabel = UILabel(frame:CGRect.zero)
        self.autocompleteLabel.font = self.font
        self.autocompleteLabel.backgroundColor = UIColor.clear
        self.autocompleteLabel.textColor = UIColor.lightGray
        
        let lineBreakMode: NSLineBreakMode = NSLineBreakMode.byClipping
        
        //        if (checkVersion("6.0.0") == 1){
        //            var lineBreakMode: NSLineBreakMode = NSLineBreakMode.ByClipping
        //        } else {
        //            var lineBreakMode: UILineBreakMode =
        //
        //        }
        self.autocompleteLabel.lineBreakMode = lineBreakMode
        self.autocompleteLabel.isHidden = true
        self.addSubview(autocompleteLabel)
        self.bringSubview(toFront: autocompleteLabel)
        
        self.autocompleteButton = UIButton(type: UIButtonType.custom)
        self.autocompleteButton.addTarget(self, action: #selector(HTAutocompleteTextField.autocompleteText(_:)), for: UIControlEvents.touchUpInside)
        self.autocompleteButton.setImage(UIImage(named: "autocompleteButton"), for:  UIControlState())
        self.addSubview(autocompleteButton)
        self.bringSubview(toFront: autocompleteButton)
        
        self.autocompleteString = ""
        
        self.ignoreCase = true
        
        NotificationCenter.default.addObserver(self, selector: #selector(HTAutocompleteTextField.ht_textDidChange(_:)), name: NSNotification.Name.UITextFieldTextDidChange, object: self)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
//        self.autocompleteButton?.frame = self.frameForAutocompleteButton()
    }
    
    // MARK: - Configuration
    func setDefaultAutocompleteDataSource(_ dataSource:HTAutocompleteDataSource) {
        DefaultAutocompleteDataSource = dataSource;
    }
    
    func changefont(_ font: UIFont) {
        super.font = font
        self.autocompleteLabel.font = font
    }
    
    // MARK: - UIResponder
    
    @discardableResult
    override func becomeFirstResponder() -> Bool {
        // This is necessary because the textfield avoids tapping the autocomplete Button
        // self.bringSubviewToFront(self.autocompleteButton)
        if(!self.autocompleteDisabled) {
            if (self.clearsOnBeginEditing) {
                self.autocompleteLabel.text = ""
            }
            
            self.autocompleteLabel.isHidden = false
        }
        
        return super.becomeFirstResponder()
    }
    
    @discardableResult
    override func resignFirstResponder() -> Bool {
        if(!self.autocompleteDisabled) {
            self.autocompleteLabel.isHidden = true
            
            if(self.commitAutocompleteText()) {
                // Only notify if committing autocomplete actually changed the text.
                // This is necessary because committing the autocomplete text changes the text field's text, but for some reason UITextField doesn't post the UITextFieldTextDidChangeNotification notification on its own
                NotificationCenter.default.post(name: NSNotification.Name.UITextFieldTextDidChange,object:self)
            }
        }
        return super.resignFirstResponder()
    }
    
    // MARK: - Autocomplete Logic
    func autocompleteRectForBounds(_ bounds: CGRect) -> CGRect {
        var returnRect: CGRect = CGRect.zero
        // get bounds for whole text area
        let textRectBounds: CGRect = self.textRect(forBounds: self.bounds)
        
        // get rect for actual text
        let textRange: UITextRange = self.textRange(from: self.beginningOfDocument, to: self.endOfDocument)!
        let textRect: CGRect = self.firstRect(for: textRange).integral
        
        let lineBreakMode: NSLineBreakMode = NSLineBreakMode.byClipping
        //        if (checkVersion(60000) == 1){
        //            var lineBreakMode: NSLineBreakMode = NSLineBreakByCharWrapping
        //        } else {
        //            var lineBreakMode: UILineBreakMode = UILineBreakModeCharacterWrap
        //        }
        var autocompleteTextSize: CGSize!
        if (checkVersion("7.0.0") == 1) {
            let paragraphStyle : NSMutableParagraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineBreakMode =  lineBreakMode
            
            let attributes:Dictionary = [NSFontAttributeName: self.font!, NSParagraphStyleAttributeName:paragraphStyle] as [String : Any]
            
            let _autocompleteString = self.autocompleteString as NSString
            let autocompleteTextRect: CGRect = _autocompleteString.boundingRect(with: textRectBounds.size, options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: attributes, context: nil)
            autocompleteTextSize = autocompleteTextRect.size
            
        } else {

            let paragraphStyle : NSMutableParagraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineBreakMode =  lineBreakMode
            let attributes:Dictionary = [NSFontAttributeName:self.font!, NSParagraphStyleAttributeName:paragraphStyle] as [String : Any]
            
            let _autocompleteString = self.autocompleteString as NSString
            autocompleteTextSize = _autocompleteString.size(attributes: attributes)
        }
        
        var correction :CGFloat = 0.0;
        if (floor(NSFoundationVersionNumber) > NSFoundationVersionNumber_iOS_6_1)
        {
            // there is a slightly different return value for firstRectForRange in iOS7
            correction = 6.0
        }
        correction = correctionNew
        
        returnRect = CGRect(x: (textRect.maxX + correction + self.autocompleteTextOffset.x),
            y: textRectBounds.minY + self.autocompleteTextOffset.y,
            width: autocompleteTextSize.width,
            height: textRectBounds.size.height);
        return returnRect
        
    }
    
    func ht_textDidChange(_ notification: Notification){
        self.refreshAutocompleteText()
    }
    
    func textFieldShouldReturn(_ textField: UITextField!) -> Bool {
        self.endEditing(true)
        return false
    }
    func updateAutocompleteLabel() {
        self.autocompleteLabel.text = self.autocompleteString
        self.autocompleteLabel.sizeToFit()
        self.autocompleteLabel.frame = self.autocompleteRectForBounds(self.bounds)
        self.sendActions(for: UIControlEvents.editingChanged)
        
        //TODO:
        //        if(self.autoCompleteTextFieldDelegate.respondsToSelector("autocompleteTextField:didChangeAutocompleteText:")) {
        //        self.autoCompleteTextFieldDelegate.autocompleteTextField!(self, didChangeAutocompleteText: autocompleteString)
        //        }
    }
    
    func refreshAutocompleteText() {
        if (!self.autocompleteDisabled) {
            var dataSource : HTAutocompleteDataSource?
            
            if((self.autocompleteDataSource?.responds(to: #selector(HTAutocompleteDataSource.textField(_:completionForPrefix:ignoreCase:)))) != nil){
                dataSource = self.autocompleteDataSource!
            } else if(DefaultAutocompleteDataSource?.responds(to: #selector(HTAutocompleteDataSource.textField(_:completionForPrefix:ignoreCase:))) != nil) {
                dataSource = DefaultAutocompleteDataSource!
            }
            
            autocompleteString  = dataSource?.textField(self, completionForPrefix: self.text! as NSString, ignoreCase: self.ignoreCase)
            
            if (autocompleteString.characters.count > 0) {
                let textLength = self.text!.characters.count
                if (textLength == 0 || textLength == 1) {
                    self.updateAutocompleteButtonAnimated(true)
                }
            }
            
            self.updateAutocompleteLabel()
        }
        
    }
    
    @discardableResult
    func commitAutocompleteText() -> Bool {
        let currentText:String = self.text!
        if(self.autocompleteString.characters.count > 0 && self.autocompleteDisabled == false) {
            self.text = self.text! + self.autocompleteString
            self.autocompleteString = "";
            self.updateAutocompleteLabel()
            
            //            if (self.autoCompleteTextFieldDelegate.respondsToSelector("autoCompleteTextFieldDidAutoComplete:")) {
            //                self.autoCompleteTextFieldDelegate.autoCompleteTextFieldDidAutoComplete!(self)
            //            }
        }
        
        return !(currentText == self.text)
    }
    
    func forceRefreshAutocompleteText() {
        self.refreshAutocompleteText()
    }
    
    //    // MARK: - Accessors
    //
    //    func setAutocompleteString(autocompleteString: String) {
    //        self.autocompleteString = autocompleteString
    //        self.updateAutocompleteButtonAnimated(true)
    //    }
    //
    //    func setShowAutocompleteButton(showAutocompleteButton:Bool) {
    //        self.showAutocompleteButton = showAutocompleteButton
    //        self.updateAutocompleteButtonAnimated(true)
    //    }
    
    // MARK: - Private Methods
    
    func frameForAutocompleteButton() -> CGRect {
        var autocompletionButtonRect: CGRect = CGRect.zero
        if (self.clearButtonMode == UITextFieldViewMode.never || self.text?.characters.count == 0) {
            autocompletionButtonRect = CGRect(x: self.bounds.size.width - kHTAutoCompleteButtonWidth, y: (self.bounds.size.height/2) - (self.bounds.size.height-8)/2, width: kHTAutoCompleteButtonWidth, height: self.bounds.size.height-8);
        }
        else {
            autocompletionButtonRect = CGRect(x: self.bounds.size.width - 25 - kHTAutoCompleteButtonWidth, y: (self.bounds.size.height/2) - (self.bounds.size.height-8)/2, width: kHTAutoCompleteButtonWidth, height: self.bounds.size.height-8);
        }
        
        return autocompletionButtonRect
    }
    
    // Method fired by autocompleteButton for multiRecognition
    
    func autocompleteText(_ sender: UIButton) {
        if (!self.autocompleteDisabled)
        {
            self.autocompleteLabel.isHidden = false
            self.commitAutocompleteText()
            // This is necessary because committing the autocomplete text changes the text field's text, but for some reason UITextField doesn't post the UITextFieldTextDidChangeNotification notification on its own
            NotificationCenter.default.post(name: NSNotification.Name.UITextFieldTextDidChange,object:self)
        }
    }
    
    func updateAutocompleteButtonAnimated(_ animated:Bool) {
        if (animated)
        {
            UIView.animate(withDuration: 0.15, animations:{
                let autocompleteStringLength =  self.autocompleteString.characters.count
                if (autocompleteStringLength>0 && self.showAutocompleteButton)
                {
                    self.autocompleteButton.alpha = 1
                    self.autocompleteButton.frame = self.frameForAutocompleteButton()
                }
                else
                {
                    self.autocompleteButton.alpha = 0
                }
            })
        } else
        {
            UIView.animate(withDuration: 0.15, animations:{
                let autocompleteStringLength = self.autocompleteString.characters.count
                if (autocompleteStringLength>0 && self.showAutocompleteButton)
                {
                    self.autocompleteButton.alpha = 1;
                    self.autocompleteButton.frame = self.frameForAutocompleteButton()
                }
                else
                {
                    self.autocompleteButton.alpha = 0;
                }
            })
        }
    }
    
    
    
    func checkVersion(_ ref : String) -> Int {
        let sys = UIDevice.current.systemVersion
        switch sys.compare(ref, options: NSString.CompareOptions.numeric, range: nil, locale: nil) {
        case .orderedAscending:
            return 1 // ("\(ref) is greater than \(sys)")
        case .orderedDescending:
            return 2 // ("\(ref) is less than \(sys)")
        case .orderedSame:
            return 0 //("\(ref) is the same as \(sys)")
        }
    }
    
}

//
//  UITextField+AGi18n.m
//  AGi18n
//
//  Created by Angel Garcia on 3/13/13.
//  Copyright (c) 2013 angelolloqui.com. All rights reserved.
//

#import "UITextField+AGi18n.h"
#import "Viatori-Swift.h"

@implementation UITextField (AGi18n)

- (void)localizeFromNib {    
    //Replace text with localizable version
    if (self.text.length > 0) {
        self.text = [[VTLanguageManager sharedManager] getLocalizedStringWithKey:self.text];
    }
    if (self.placeholder.length > 0) {
        self.placeholder = [[VTLanguageManager sharedManager] getLocalizedStringWithKey:self.placeholder];
    }
}

@end

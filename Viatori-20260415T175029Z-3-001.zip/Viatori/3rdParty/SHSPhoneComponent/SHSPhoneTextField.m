//
//  SHSPhoneTextField.m
//  PhoneComponentExample
//
//  Created by Willy on 18.04.13.
//  Copyright (c) 2013 SHS. All rights reserved.
//

#import "SHSPhoneTextField.h"
#import "SHSPhoneNumberFormatter+UserConfig.h"

@interface SHSPhoneTextField()
@property (nonatomic) BOOL formatterEnable;
@end

@implementation SHSPhoneTextField

-(void) logicInitialization
{
    _formatterEnable = NO;
    
    _formatter = [[SHSPhoneNumberFormatter alloc] init];
    _formatter.textField = self;
    
    logicDelegate = [[SHSPhoneLogic alloc] init];
    
    //[super setDelegate:logicDelegate];
    self.keyboardType = UIKeyboardTypeNumberPad;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self logicInitialization];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self logicInitialization];
    }
    return self;
}

#pragma mark -
#pragma mark Delegates

-(void)setFormatterEnable:(BOOL)formatterEnable withDelegate:(id<UITextFieldDelegate>)delegate{
    
    _formatterEnable = formatterEnable;
    if (formatterEnable) {
        [super setDelegate:logicDelegate];
        self.delegate = delegate;
    }
}

-(void) setDelegate:(id<UITextFieldDelegate>)delegate
{
    if (_formatterEnable) {
        logicDelegate.delegate = delegate;
    } else {
        [super setDelegate:delegate];
    }
}

-(id<UITextFieldDelegate>) delegate
{
    return _formatterEnable ? logicDelegate.delegate : self.delegate;
}

#pragma mark -
#pragma mark Additional Text Setter

-(void) setFormattedText:(NSString *)text
{
    [SHSPhoneLogic applyFormat:self forText:text];
}

-(NSString *) phoneNumber
{
    return [self.formatter digitOnlyString:self.text];
}

-(NSString *)phoneNumberWithoutPrefix
{
    return [self.formatter digitOnlyString:[self.text stringByReplacingOccurrencesOfString:self.formatter.prefix withString:@""]];
}

@end



//
//  VTBaseNavigationController.swift
//  Viatori
//
//  Created by Serkut Yegin on 31/10/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class VTBaseNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setup()
    }
    
    deinit {
        debugPrint("\(NSStringFromClass(self.classForCoder)) deinitialized")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func setup() {
        self.setTexts()
        self.setTheme()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension VTBaseNavigationController {
    
    //Initializers
    
    func setTexts() {
        //fatalError("The method must be overriden")
    }
    
    func setTheme() {
        //fatalError("The method must be overriden")
    }
    
    func setupUI() {
        
    }
    
}

//
//  VTBasePageView.swift
//  Viatori
//
//  Created by Serkut Yegin on 16/12/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class VTBasePageView: VTBaseView {

    var constraintWidht : NSLayoutConstraint?
    var constraintLeading : NSLayoutConstraint?
    var pageIndex = 0
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}

//
//  VTBaseView.swift
//  Viatori
//
//  Created by Serkut Yegin on 01/11/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class VTBaseView: UIView {

    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    deinit {
        debugPrint("\(NSStringFromClass(self.classForCoder)) deinitialized")
    }
    
    //MARK: Initial
    internal func setupUI() {
        self.setTexts()
        self.setTheme()
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
}

extension VTBaseView {
    
    func setTexts() {
        
    }
    
    func setTheme() {
        
    }
}

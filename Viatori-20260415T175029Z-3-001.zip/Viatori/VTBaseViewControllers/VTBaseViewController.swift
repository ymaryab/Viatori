//
//  VTBaseViewController.swift
//  Viatori
//
//  Created by Serkut Yegin on 31/10/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit
import Marshal
import IQKeyboardManagerSwift

class VTBaseViewController: UIViewController {
    
    internal var firstWillAppear = true
    internal var firstDidAppear = true
    internal var isAppeared = false
    
    //MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        // Do any additional setup after loading the view.
    }
    
    deinit {
        debugPrint("\(NSStringFromClass(self.classForCoder)) deinitialized")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.sharedManager().enable = false
        IQKeyboardManager.sharedManager().enableAutoToolbar = false
        if self.shouldListenKeyboardNotification() {
            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShown(_:)), name: .UIKeyboardWillShow, object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
        }
        self.setup()
        self.firstWillAppear = false
        self.isAppeared = true
        if let vtSliding = self.vtSlidingMenu() {
            vtSliding.showHideSlider(show: !self.hidesBottomBarWhenPushed, animated:true)
        }
        if enableKeyboardManager() {
            IQKeyboardManager.sharedManager().enable = true
            IQKeyboardManager.sharedManager().enableAutoToolbar = true
            IQKeyboardManager.sharedManager().toolbarDoneBarButtonItemText = "TXT_COMMON_COMMON_DONE".localized()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let vtSliding = self.vtSlidingMenu() {
            vtSliding.showHideSlider(show: !self.hidesBottomBarWhenPushed)
        }
        self.firstDidAppear = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if self.shouldListenKeyboardNotification() {
            NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
            NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
        }
        self.isAppeared = false
        if enableKeyboardManager() {
            IQKeyboardManager.sharedManager().enable = false
            IQKeyboardManager.sharedManager().enableAutoToolbar = false
        }
    }
    
    //MARK: Initial
    private func setup() {
        self.setTexts()
        self.setTheme()
    }
    
    //MARK: Keyboard Notif
    
    @objc private func keyboardWillShown(_ notification:Notification) {
        self.handleKeyboardNotif(notification: notification, willShow: true)
    }
    
    @objc private func keyboardWillHide(_ notification:Notification) {
        self.handleKeyboardNotif(notification: notification, willShow: false)
    }
    
    private func handleKeyboardNotif(notification:Notification, willShow:Bool) {
        
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewKeyframeAnimationOptions = UIViewKeyframeAnimationOptions(rawValue: animationCurveRaw)
            self.keyboardNotification(willShow: willShow, endFrame: endFrame!, duration: duration, animationCurve: animationCurve)
        }
    }
}

extension VTBaseViewController {
    
    //Initializers
    
    func setTexts() {
        //fatalError("The method must be overriden")
    }
    
    func setTheme() {
        //fatalError("The method must be overriden")
    }
    
    func setupUI() {
        
    }
    
    func enableKeyboardManager() -> Bool {
        return false
    }
    
    func shouldListenKeyboardNotification() -> Bool {
        return false
    }
    
    func keyboardNotification(willShow:Bool,endFrame:CGRect,duration:TimeInterval,animationCurve:UIViewKeyframeAnimationOptions) {
        
    }
    
}

extension VTBaseViewController {
    
    @discardableResult
    func addBarButtonToLeft(image:UIImage,action:Selector) -> UIBarButtonItem? {
        guard (self.navigationController != nil) else { return nil }
        let barItem = UIBarButtonItem.init(image: image, style: .plain, target: self, action: action)
        self.navigationItem.leftBarButtonItem = barItem
        return barItem
    }
    
    @discardableResult
    func addBarButtonToRight(image:UIImage,action:Selector) -> UIBarButtonItem?{
        guard (self.navigationController != nil) else { return nil }
        let barItem = UIBarButtonItem.init(image: image, style: .plain, target: self, action: action)
        self.navigationItem.rightBarButtonItem = barItem
        return barItem
    }
}

private extension VTBaseViewController {
    
}

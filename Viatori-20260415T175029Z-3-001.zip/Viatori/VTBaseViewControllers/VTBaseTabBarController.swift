//
//  VTBaseTabBarController.swift
//  Viatori
//
//  Created by Serkut Yegin on 31/10/2016.
//  Copyright © 2016 Proaegean Ar-Ge. All rights reserved.
//

import UIKit

class VTBaseTabBarController: UITabBarController {

    internal var firstWillAppear = true
    internal var firstDidAppear = true
    internal var isAppeared = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        // Do any additional setup after loading the view.
    }
    
    deinit {
        debugPrint("\(NSStringFromClass(self.classForCoder)) deinitialized")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setup()
        self.firstWillAppear = false
        self.isAppeared = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.firstDidAppear = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.isAppeared = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func setup() {
        self.setTexts()
        self.setTheme()
    }
}

extension VTBaseTabBarController {
    
    //Initializers
    
    func setTexts() {
        //fatalError("The method must be overriden")
    }
    
    func setTheme() {
        //fatalError("The method must be overriden")
    }
    
    func setupUI() {
        
    }
    
}

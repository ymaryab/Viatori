//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

public func toInt(str:String) -> Int? {
    if let num = NumberFormatter().number(from: str) {
        return num.intValue
    } else {
        return nil
    }
}

public func urlEncoded(str:String) -> String {
    if !(str.contains("http://") && str.contains("https://")) {
        return "http://" + str
    }
    return str.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
}

toInt(str: "0")
toInt(str: "100")

str = "www.youtube.com"
urlEncoded(str: str)

let url = URL.init(string: str)
